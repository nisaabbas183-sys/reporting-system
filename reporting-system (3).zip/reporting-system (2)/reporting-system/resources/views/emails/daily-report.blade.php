<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Daily Employee Report</title>
</head>

<body style="font-family: Arial, sans-serif; background:#F4F6F8; padding:30px;">

    <div style="
        max-width:600px;
        margin:auto;
        background:#ffffff;
        padding:25px;
        border-radius:8px;
        border:1px solid #D9E0E6;
    ">

        <h2 style="color:#2C3E50; margin-top:0;">
            Reporting System
        </h2>

        <h3 style="color:#3498DB;">
            Daily Employee Report
        </h3>

        <p style="color:#5D6D7E;">
            Dear Sir/Madam,
        </p>

        <p style="color:#5D6D7E;">
            Please find attached the daily employee report for
            <strong>
                {{ $dailyReport->employee->name }}
            </strong>.
        </p>

        <table style="width:100%; border-collapse:collapse; margin-top:20px;">
            <tr>
                <td style="
                    padding:10px;
                    background:#F4F6F8;
                    font-weight:bold;
                    color:#2C3E50;
                    border:1px solid #D9E0E6;
                ">
                    Employee
                </td>

                <td style="
                    padding:10px;
                    border:1px solid #D9E0E6;
                    color:#5D6D7E;
                ">
                    {{ $dailyReport->employee->name }}
                </td>
            </tr>

            <tr>
                <td style="
                    padding:10px;
                    background:#F4F6F8;
                    font-weight:bold;
                    color:#2C3E50;
                    border:1px solid #D9E0E6;
                ">
                    Department
                </td>

                <td style="
                    padding:10px;
                    border:1px solid #D9E0E6;
                    color:#5D6D7E;
                ">
                    {{ $dailyReport->employee->department->name ?? 'N/A' }}
                </td>
            </tr>

            <tr>
                <td style="
                    padding:10px;
                    background:#F4F6F8;
                    font-weight:bold;
                    color:#2C3E50;
                    border:1px solid #D9E0E6;
                ">
                    Report Date
                </td>

                <td style="
                    padding:10px;
                    border:1px solid #D9E0E6;
                    color:#5D6D7E;
                ">
                    {{ $dailyReport->report_date->format('d M Y') }}
                </td>
            </tr>
        </table>

        <p style="
            margin-top:25px;
            color:#5D6D7E;
        ">
            The complete report is attached as a PDF.
        </p>

        <p style="color:#5D6D7E;">
            Regards,<br>
            <strong>Reporting System</strong>
        </p>

    </div>

</body>
</html>
