<div style="font-family: Arial, sans-serif; font-size: 14px; color: #222;">
    <p>Dear Sir,</p>
    <p>Please find attached the Daily Report dated
        <strong>{{ $reportDate->format('d/m/Y') }}</strong>.</p>
    <p>Regards,<br>Star Automation</p>
</div>