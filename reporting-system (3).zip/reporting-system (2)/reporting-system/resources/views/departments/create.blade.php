@extends('layouts.app')

@section('content')

    <div class="content-header">

        <div class="content-title">
            <h1>Add Department</h1>
            <p>Create a new department for your organization.</p>
        </div>

        <a href="{{ route('departments.index') }}" class="btn-primary"
           style="background:#2C3E50;">

            ← Back to Departments

        </a>

    </div>


    <div class="card">

        <div class="card-header">

            <div>
                <h3>Department Information</h3>
                <p>Enter the basic information of the department.</p>
            </div>

        </div>


        <form action="{{ route('departments.store') }}" method="POST">

            @csrf

            <div style="padding:25px;">

                <!-- Department Name -->

                <div style="margin-bottom:22px;">

                    <label
                        for="name"
                        style="
                            display:block;
                            color:#2C3E50;
                            font-size:13px;
                            font-weight:600;
                            margin-bottom:8px;
                        "
                    >
                        Department Name
                        <span style="color:#E74C3C;">*</span>
                    </label>

                    <input
                        type="text"
                        name="name"
                        id="name"
                        value="{{ old('name') }}"
                        placeholder="e.g. Finance, Sales, HR"
                        style="
                            width:100%;
                            padding:12px 14px;
                            border:1px solid #D9DEE3;
                            border-radius:7px;
                            font-size:13px;
                            outline:none;
                        "
                    >

                    @error('name')
                        <small style="color:#E74C3C;">
                            {{ $message }}
                        </small>
                    @enderror

                </div>


                <!-- Description -->

                <div style="margin-bottom:22px;">

                    <label
                        for="description"
                        style="
                            display:block;
                            color:#2C3E50;
                            font-size:13px;
                            font-weight:600;
                            margin-bottom:8px;
                        "
                    >
                        Description
                    </label>

                    <textarea
                        name="description"
                        id="description"
                        rows="4"
                        placeholder="Enter department description..."
                        style="
                            width:100%;
                            padding:12px 14px;
                            border:1px solid #D9DEE3;
                            border-radius:7px;
                            font-size:13px;
                            resize:vertical;
                            outline:none;
                        "
                    >{{ old('description') }}</textarea>

                    @error('description')
                        <small style="color:#E74C3C;">
                            {{ $message }}
                        </small>
                    @enderror

                </div>


                <!-- Buttons -->

                <div
                    style="
                        display:flex;
                        justify-content:flex-end;
                        gap:10px;
                        padding-top:10px;
                        border-top:1px solid #EDF0F2;
                    "
                >

                    <a
                        href="{{ route('departments.index') }}"
                        style="
                            padding:11px 18px;
                            border:1px solid #D9DEE3;
                            border-radius:7px;
                            text-decoration:none;
                            color:#5D6D7E;
                            font-size:13px;
                            font-weight:600;
                        "
                    >
                        Cancel
                    </a>


                    <button
                        type="submit"
                        class="btn-primary"
                    >

                        <!-- Save Icon -->

                        <svg
                            class="btn-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        >
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                            <polyline points="17 21 17 13 7 13 7 21"></polyline>
                            <polyline points="7 3 7 8 15 8"></polyline>
                        </svg>

                        Save Department

                    </button>

                </div>

            </div>

        </form>

    </div>

@endsection