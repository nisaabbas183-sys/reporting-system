@extends('layouts.app')

@section('content')

    <div class="content-header">

        <div class="content-title">
            <h1>Departments</h1>
            <p>Manage company departments and their information.</p>
        </div>

        <a href="{{ route('departments.create') }}" class="btn-primary">

            <!-- Plus Icon -->
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>

            Add Department

        </a>

    </div>


    @if(session('success'))

        <div class="alert-success">
            ✓ {{ session('success') }}
        </div>

    @endif


    <div class="card">

        <div class="card-header">

            <div>
                <h3>Department List</h3>
                <p>All departments registered in the system.</p>
            </div>

        </div>


        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>
                        <th>#</th>
                        <th>Department Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                    @forelse($departments as $department)

                        <tr>

                            <td>
                                {{ $department->id }}
                            </td>

                            <td>
                                <strong style="color:#2C3E50;">
                                    {{ $department->name }}
                                </strong>
                            </td>

                            <td>
                                {{ $department->description ?? '—' }}
                            </td>

                            <td>

                                @if($department->status)

                                    <span class="badge badge-success">
                                        ● Active
                                    </span>

                                @else

                                    <span class="badge badge-danger">
                                        ● Inactive
                                    </span>

                                @endif

                            </td>

                            <td>

                                <!-- Edit -->
                                <a
                                    href="{{ route('departments.edit', $department) }}"
                                    class="action-btn action-edit"
                                    title="Edit"
                                >

                                    <svg viewBox="0 0 24 24" fill="none"
                                         stroke="currentColor"
                                         stroke-width="2"
                                         stroke-linecap="round"
                                         stroke-linejoin="round">

                                        <path d="M12 20h9"></path>
                                        <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path>

                                    </svg>

                                </a>


                                <!-- Delete -->

                                <form
                                    action="{{ route('departments.destroy', $department) }}"
                                    method="POST"
                                    style="display:inline;"
                                >

                                    @csrf
                                    @method('DELETE')

                                    <button
                                        type="submit"
                                        class="action-btn action-delete"
                                        title="Delete"
                                        onclick="return confirm('Are you sure you want to delete this department?')"
                                    >

                                        <svg viewBox="0 0 24 24" fill="none"
                                             stroke="currentColor"
                                             stroke-width="2"
                                             stroke-linecap="round"
                                             stroke-linejoin="round">

                                            <polyline points="3 6 5 6 21 6"></polyline>
                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                                            <path d="M10 11v6"></path>
                                            <path d="M14 11v6"></path>
                                            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"></path>

                                        </svg>

                                    </button>

                                </form>

                            </td>

                        </tr>

                    @empty

                        <tr>

                            <td colspan="5" style="text-align:center; padding:40px;">

                                <div style="font-size:35px; margin-bottom:10px;">
                                    🏢
                                </div>

                                <strong style="color:#2C3E50;">
                                    No departments found
                                </strong>

                                <p style="margin-top:5px;">
                                    Add your first department to get started.
                                </p>

                            </td>

                        </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

@endsection