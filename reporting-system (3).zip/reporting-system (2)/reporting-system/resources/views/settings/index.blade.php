@extends('layouts.app')

@section('content')

<div class="content-header">
    <div class="content-title">
        <h1>Settings</h1>
        <p>Manage your reporting system preferences.</p>
    </div>
</div>

@if(session('success'))
    <div class="alert-success">
        {{ session('success') }}
    </div>
@endif

<form action="{{ route('settings.update') }}" method="POST">
    @csrf

    <div class="settings-grid">

        <!-- REPORT SETTINGS -->
        <div class="card settings-card">

            <div class="card-header">
                <div>
                    <h3>
                        <span class="settings-icon">⚙</span>
                        Report Settings
                    </h3>
                    <p>Configure daily report scheduling.</p>
                </div>
            </div>

            <div class="settings-body">

                <!-- DAILY REPORT TIME -->
                <div class="setting-row">

                    <div class="setting-info">
                        <strong>Daily Report Time</strong>
                        <span>
                            Select the time when daily reports should be
                            processed.
                        </span>
                    </div>

                    <div>
                        <input
                            type="time"
                            name="report_time"
                            value="{{ $settings['report_time'] ?? '17:00' }}"
                            class="setting-input"
                        >
                    </div>

                </div>


                <!-- AUTOMATIC REPORT SENDING -->
                <div class="setting-row">

                    <div class="setting-info">
                        <strong>Automatic Report Sending</strong>
                        <span>
                            Automatically send daily reports to concerned
                            personnel.
                        </span>
                    </div>

                    <label class="switch">

                        <input
                            type="checkbox"
                            name="automatic_report_sending"
                            value="1"
                            {{ ($settings['automatic_report_sending'] ?? '0') === '1' ? 'checked' : '' }}
                        >

                        <span class="slider"></span>

                    </label>

                </div>


                <!-- PDF REPORT GENERATION -->
                <div class="setting-row">

                    <div class="setting-info">
                        <strong>PDF Report Generation</strong>
                        <span>
                            Generate a PDF version of each daily report.
                        </span>
                    </div>

                    <label class="switch">

                        <input
                            type="checkbox"
                            name="pdf_report_generation"
                            value="1"
                            {{ ($settings['pdf_report_generation'] ?? '0') === '1' ? 'checked' : '' }}
                        >

                        <span class="slider"></span>

                    </label>

                </div>

            </div>

        </div>


        <!-- NOTIFICATION SETTINGS -->
        <div class="card settings-card">

            <div class="card-header">
                <div>
                    <h3>
                        <span class="settings-icon">✉</span>
                        Notification Settings
                    </h3>

                    <p>
                        Configure report notification channels.
                    </p>
                </div>
            </div>


            <div class="settings-body">

                <!-- EMAIL -->
                <div class="setting-row">

                    <div class="setting-info">
                        <strong>Email Notifications</strong>
                        <span>
                            Send generated reports through email.
                        </span>
                    </div>

                    <label class="switch">

                        <input
                            type="checkbox"
                            name="email_notifications"
                            value="1"
                            {{ ($settings['email_notifications'] ?? '0') === '1' ? 'checked' : '' }}
                        >

                        <span class="slider"></span>

                    </label>

                </div>


                <!-- WHATSAPP -->
                <div class="setting-row">

                    <div class="setting-info">
                        <strong>WhatsApp Notifications</strong>
                        <span>
                            Send report notifications through WhatsApp.
                        </span>
                    </div>

                    <label class="switch">

                        <input
                            type="checkbox"
                            name="whatsapp_notifications"
                            value="1"
                            {{ ($settings['whatsapp_notifications'] ?? '0') === '1' ? 'checked' : '' }}
                        >

                        <span class="slider"></span>

                    </label>

                </div>

            </div>

        </div>


        <!-- SYSTEM INFORMATION -->
        <div class="card settings-card">

            <div class="card-header">

                <div>
                    <h3>
                        <span class="settings-icon">ⓘ</span>
                        System Information
                    </h3>

                    <p>
                        Basic information about the reporting system.
                    </p>
                </div>

            </div>


            <div class="settings-body">

                <div class="info-row">
                    <span>Application</span>
                    <strong>Reporting System</strong>
                </div>

                <div class="info-row">
                    <span>Framework</span>
                    <strong>Laravel</strong>
                </div>

                <div class="info-row">
                    <span>Environment</span>
                    <strong>Local</strong>
                </div>

                <div class="info-row">
                    <span>Report Format</span>
                    <strong>PDF</strong>
                </div>

            </div>

        </div>


        <!-- SAVE -->
        <div class="settings-actions">

            <button type="submit" class="btn-primary">

                <svg
                    class="btn-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                    <polyline points="7 3 7 8 15 8"></polyline>
                </svg>

                Save Settings

            </button>

        </div>

    </div>

</form>


<style>

.settings-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}

.settings-card {
    overflow: hidden;
}

.settings-card .card-header {
    padding: 20px;
}

.settings-card .card-header h3 {
    display: flex;
    align-items: center;
    gap: 10px;
}

.settings-icon {
    width: 32px;
    height: 32px;
    border-radius: 7px;
    background: #EBF5FB;
    color: #3498DB;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
}

.settings-body {
    padding: 5px 20px 10px;
}

.setting-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 18px 0;
    border-bottom: 1px solid #EDF0F2;
}

.setting-row:last-child {
    border-bottom: none;
}

.setting-info {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.setting-info strong {
    color: #2C3E50;
    font-size: 13px;
}

.setting-info span {
    color: #8493A0;
    font-size: 11px;
    line-height: 1.5;
}

.setting-input {
    width: 125px;
    padding: 9px 10px;
    border: 1px solid #D9E0E6;
    border-radius: 6px;
    color: #2C3E50;
    background: white;
    outline: none;
}

.setting-input:focus {
    border-color: #3498DB;
}


/* SWITCH */

.switch {
    position: relative;
    width: 43px;
    height: 23px;
    flex-shrink: 0;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    inset: 0;
    background: #CBD5DC;
    border-radius: 30px;
    transition: 0.2s;
}

.slider:before {
    content: "";
    position: absolute;
    height: 17px;
    width: 17px;
    left: 3px;
    top: 3px;
    background: white;
    border-radius: 50%;
    transition: 0.2s;
}

.switch input:checked + .slider {
    background: #27AE60;
}

.switch input:checked + .slider:before {
    transform: translateX(20px);
}


/* SYSTEM INFO */

.info-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 0;
    border-bottom: 1px solid #EDF0F2;
}

.info-row:last-child {
    border-bottom: none;
}

.info-row span {
    color: #8493A0;
    font-size: 12px;
}

.info-row strong {
    color: #2C3E50;
    font-size: 12px;
}


/* SAVE BUTTON */

.settings-actions {
    grid-column: 1 / -1;
    display: flex;
    justify-content: flex-end;
    margin-top: 2px;
}


/* SUCCESS MESSAGE */

.alert-success {
    margin-bottom: 20px;
    padding: 12px 16px;
    border-radius: 6px;
    background: #EAF8F0;
    color: #27AE60;
    border: 1px solid #C8EBD6;
    font-size: 13px;
}


/* MOBILE */

@media (max-width: 900px) {

    .settings-grid {
        grid-template-columns: 1fr;
    }

    .settings-actions {
        grid-column: auto;
    }

}

</style>

@endsection