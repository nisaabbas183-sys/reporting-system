@extends('layouts.app')

@section('content')

<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .page-header h1 {
        margin: 0;
        color: #2C3E50;
        font-size: 26px;
    }

    .page-header p {
        margin: 6px 0 0;
        color: #5D6D7E;
        font-size: 14px;
    }

    .btn-primary {
        background: #3498DB;
        color: white;
        text-decoration: none;
        padding: 11px 17px;
        border-radius: 7px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-primary:hover {
        background: #2980B9;
    }

    .alert-success {
        background: #E8F8F0;
        color: #27AE60;
        padding: 12px 15px;
        border-radius: 7px;
        margin-bottom: 20px;
        font-size: 14px;
    }

    .table-card {
        background: #ffffff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    }

    .table-wrapper {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        min-width: 850px;
    }

    th {
        background: #F4F6F8;
        color: #2C3E50;
        text-align: left;
        padding: 14px 16px;
        font-size: 13px;
        font-weight: 700;
    }

    td {
        padding: 14px 16px;
        border-top: 1px solid #ECF0F1;
        color: #5D6D7E;
        font-size: 13px;
        vertical-align: middle;
    }

    tr:hover td {
        background: #FAFBFC;
    }

    .employee-name {
        color: #2C3E50;
        font-weight: 600;
    }

    .task-text {
        color: #2C3E50;
        max-width: 280px;
        line-height: 1.5;
    }

    .status-badge {
        border-radius: 20px;
        padding: 6px 11px;
        font-size: 12px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 7px;
    }

    .status-pending {
        background: #FEF5E7;
        color: #F39C12;
    }

    .status-submitted {
        background: #EAF2FF;
        color: #2563EB;
    }

    .status-completed {
        background: #E8F8F0;
        color: #27AE60;
    }

    .status-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: currentColor;
    }

    .approve-btn {
        border: none;
        border-radius: 20px;
        padding: 6px 11px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        background: #27AE60;
        color: white;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        margin-top: 6px;
    }

    .approve-btn:hover {
        background: #229954;
    }

    .actions {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .action-btn {
        width: 34px;
        height: 34px;
        border-radius: 6px;
        border: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        cursor: pointer;
    }

    .edit-btn {
        background: #EBF5FB;
        color: #3498DB;
    }

    .delete-btn {
        background: #FDEDEC;
        color: #E74C3C;
    }

    .empty-state {
        text-align: center;
        padding: 55px 20px;
    }

    .empty-state h3 {
        color: #2C3E50;
        margin: 12px 0 6px;
    }

    .empty-state p {
        color: #5D6D7E;
        margin: 0 0 18px;
    }

    @media (max-width: 768px) {
        .page-header {
            align-items: flex-start;
            gap: 15px;
            flex-direction: column;
        }
    }
</style>

<div class="page-header">
    <div>
        <h1>Tasks</h1>
        <p>Manage employee tasks and their approval status.</p>
    </div>

    <a href="{{ route('tasks.create') }}" class="btn-primary">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2">
            <path d="M12 5v14M5 12h14"/>
        </svg>
        Add Task
    </a>
</div>

@if(session('success'))
    <div class="alert-success">
        {{ session('success') }}
    </div>
@endif

@if(session('error'))
    <div class="alert-success" style="background:#FDEDEC; color:#E74C3C;">
        {{ session('error') }}
    </div>
@endif

<div class="table-card">

    @if($tasks->count() > 0)

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Employee</th>
                        <th>Task</th>
                        <th>Task Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                    @foreach($tasks as $task)

                        <tr>

                            <td>
                                {{ $loop->iteration }}
                            </td>

                            <td>
                                <span class="employee-name">
                                    {{ $task->employee->name }}
                                </span>
                            </td>

                            <td>
                                <div class="task-text">
                                    {{ $task->task }}
                                </div>
                            </td>

                            <td>
                                {{ $task->task_date->format('d M Y') }}
                            </td>

                            <td>
                                @if($task->due_date)
                                    {{ $task->due_date->format('d M Y') }}
                                @else
                                    —
                                @endif
                            </td>

                            <td>

                                <span class="status-badge
                                    @if($task->status === 'approved') status-completed
                                    @elseif($task->status === 'submitted') status-submitted
                                    @else status-pending
                                    @endif
                                ">
                                    <span class="status-dot"></span>
                                    {{ ucfirst($task->status) }}
                                </span>

                                @if($task->status === 'submitted')

                                    <form action="{{ route('tasks.approve', $task->id) }}"
                                          method="POST"
                                          style="margin-top: 6px;">

                                        @csrf

                                        <button type="submit" class="approve-btn">
                                            ✓ Approve
                                        </button>

                                    </form>

                                @endif

                            </td>

                            <td>

                                <div class="actions">

                                    <a href="{{ route('tasks.edit', $task->id) }}"
                                       class="action-btn edit-btn"
                                       title="Edit">

                                        <svg width="16" height="16"
                                             viewBox="0 0 24 24"
                                             fill="none"
                                             stroke="currentColor"
                                             stroke-width="2">

                                            <path d="M12 20h9"/>

                                            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1
                                                     1-4 4L16.5 3.5z"/>

                                        </svg>

                                    </a>

                                    <form action="{{ route('tasks.destroy', $task->id) }}"
                                          method="POST"
                                          onsubmit="return confirm('Are you sure you want to delete this task?');">

                                        @csrf
                                        @method('DELETE')

                                        <button type="submit"
                                                class="action-btn delete-btn"
                                                title="Delete">

                                            <svg width="16" height="16"
                                                 viewBox="0 0 24 24"
                                                 fill="none"
                                                 stroke="currentColor"
                                                 stroke-width="2">

                                                <polyline points="3 6 5 6 21 6"/>

                                                <path d="M19 6v14a2 2 0 0 1-2 2H7
                                                         a2 2 0 0 1-2-2V6m3 0V4
                                                         a2 2 0 0 1 2-2h4
                                                         a2 2 0 0 1 2 2v2"/>

                                            </svg>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    @endforeach

                </tbody>

            </table>
        </div>

    @else

        <div class="empty-state">

            <svg width="55" height="55"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="#3498DB"
                 stroke-width="1.5">

                <path d="M9 11l3 3L22 4"/>

                <path d="M21 12v7a2 2 0 0 1-2 2H5
                         a2 2 0 0 1-2-2V5
                         a2 2 0 0 1 2-2h11"/>

            </svg>

            <h3>No Tasks Found</h3>

            <p>Start by adding a task for an employee.</p>

            <a href="{{ route('tasks.create') }}" class="btn-primary">
                Add First Task
            </a>

        </div>

    @endif

</div>

@endsection