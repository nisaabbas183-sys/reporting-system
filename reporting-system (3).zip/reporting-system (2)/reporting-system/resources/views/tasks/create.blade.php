@extends('layouts.app')

@section('content')

<style>
    .page-header {
        margin-bottom: 25px;
    }

    .page-header h1 {
        margin: 0;
        color: #2C3E50;
        font-size: 26px;
    }

    .page-header p {
        margin: 6px 0 0;
        color: #5D6D7E;
        font-size: 14px;
    }

    .form-card {
        background: #ffffff;
        border-radius: 10px;
        padding: 28px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        max-width: 900px;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
    }

    .form-group.full-width {
        grid-column: 1 / -1;
    }

    .form-label {
        color: #2C3E50;
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .required {
        color: #E74C3C;
    }

    .form-control {
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #D5DBDB;
        border-radius: 7px;
        padding: 11px 13px;
        font-size: 14px;
        color: #2C3E50;
        background: #ffffff;
        outline: none;
        transition: 0.2s;
    }

    .form-control:focus {
        border-color: #3498DB;
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.10);
    }

    textarea.form-control {
        min-height: 130px;
        resize: vertical;
        line-height: 1.5;
    }

    .input-icon {
        position: relative;
    }

    .input-icon svg {
        position: absolute;
        left: 13px;
        top: 50%;
        transform: translateY(-50%);
        color: #7F8C8D;
        pointer-events: none;
    }

    .input-icon .form-control {
        padding-left: 40px;
    }

    .error-message {
        color: #E74C3C;
        font-size: 12px;
        margin-top: 6px;
    }

    .form-note {
        background: #EBF5FB;
        color: #2C3E50;
        border-left: 4px solid #3498DB;
        padding: 12px 14px;
        border-radius: 5px;
        font-size: 13px;
        line-height: 1.5;
        margin-bottom: 22px;
    }

    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #ECF0F1;
    }

    .btn {
        border: none;
        border-radius: 7px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-primary {
        background: #3498DB;
        color: #ffffff;
    }

    .btn-primary:hover {
        background: #2980B9;
    }

    .btn-secondary {
        background: #ECF0F1;
        color: #2C3E50;
    }

    .btn-secondary:hover {
        background: #D5DBDB;
    }

    /* Selected employee chips (group assign mode) */
    .chip-box {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        border: 1px solid #D5DBDB;
        border-radius: 7px;
        padding: 10px 12px;
        background: #F8FAFB;
        min-height: 46px;
        align-items: center;
    }

    .chip {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: #2C3E50;
        color: #ffffff;
        padding: 6px 10px 6px 6px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }

    .chip .chip-avatar {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #3498DB;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
    }

    .chip-count {
        font-size: 12px;
        color: #5D6D7E;
        font-weight: 600;
        margin-left: 4px;
    }

    @media (max-width: 700px) {
        .form-grid {
            grid-template-columns: 1fr;
        }

        .form-group.full-width {
            grid-column: auto;
        }

        .form-card {
            padding: 20px;
        }

        .form-actions {
            flex-direction: column;
        }

        .btn {
            justify-content: center;
        }
    }
</style>

<div class="page-header">
    <div>
        <h1>Add Task</h1>
        <p>
            @if(isset($selectedEmployees) && $selectedEmployees->count() > 0)
                Assign this task to {{ $selectedEmployees->count() }} selected employee(s).
            @else
                Create a new task for an employee.
            @endif
        </p>
    </div>
</div>

<div class="form-card">

    <div class="form-note">
        <strong>Task Management:</strong>
        Add the task and set a due date. Tasks that remain pending
        can be carried forward to the next report.
    </div>

    <form action="{{ route('tasks.store') }}" method="POST">

        @csrf

        <div class="form-grid">

            {{-- Employee(s) --}}
            <div class="form-group {{ isset($selectedEmployees) && $selectedEmployees->count() > 0 ? 'full-width' : '' }}">

                @if(isset($selectedEmployees) && $selectedEmployees->count() > 0)

                    {{-- GROUP / PRESELECTED MODE --}}

                    <label class="form-label">
                        Assigned To <span class="required">*</span>
                        <span class="chip-count">
                            ({{ $selectedEmployees->count() }} selected)
                        </span>
                    </label>

                    <div class="chip-box">

                        @foreach($selectedEmployees as $employee)

                            <span class="chip">
                                <span class="chip-avatar">
                                    {{ strtoupper(substr($employee->name, 0, 1)) }}
                                </span>
                                {{ $employee->name }}
                            </span>

                            <input type="hidden"
                                   name="employee_ids[]"
                                   value="{{ $employee->id }}">

                        @endforeach

                    </div>

                    <a href="{{ route('tasks.create') }}"
                       style="font-size:12px; color:#3498DB; margin-top:8px; text-decoration:none;">
                        Change selection / pick individually
                    </a>

                @else

                    {{-- SINGLE / INDIVIDUAL MODE --}}

                    <label class="form-label">
                        Employee <span class="required">*</span>
                    </label>

                    <div class="input-icon">

                        <svg width="17" height="17"
                             viewBox="0 0 24 24"
                             fill="none"
                             stroke="currentColor"
                             stroke-width="2">

                            <path d="M20 21v-2a4 4 0 0 0-4-4H8
                                     a4 4 0 0 0-4 4v2"/>

                            <circle cx="12" cy="7" r="4"/>

                        </svg>

                        <select name="employee_ids[]"
                                class="form-control"
                                required>

                            <option value="">Select Employee</option>

                            @foreach($employees as $employee)

                                <option value="{{ $employee->id }}"
                                    {{ old('employee_ids.0') == $employee->id ? 'selected' : '' }}>

                                    {{ $employee->name }}

                                </option>

                            @endforeach

                        </select>

                    </div>

                @endif

                @error('employee_ids')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Task Date --}}
            <div class="form-group">

                <label class="form-label">
                    Task Date <span class="required">*</span>
                </label>

                <div class="input-icon">

                    <svg width="17" height="17"
                         viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor"
                         stroke-width="2">

                        <rect x="3" y="4" width="18" height="18"
                              rx="2" ry="2"/>

                        <line x1="16" y1="2" x2="16" y2="6"/>
                        <line x1="8" y1="2" x2="8" y2="6"/>
                        <line x1="3" y1="10" x2="21" y2="10"/>

                    </svg>

                    <input type="date"
                           name="task_date"
                           class="form-control"
                           value="{{ old('task_date', date('Y-m-d')) }}"
                           required>

                </div>

                @error('task_date')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Task --}}
            <div class="form-group full-width">

                <label class="form-label">
                    Task <span class="required">*</span>
                </label>

                <textarea name="task"
                          class="form-control"
                          placeholder="Enter employee task..."
                          required>{{ old('task') }}</textarea>

                @error('task')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Due Date --}}
            <div class="form-group">

                <label class="form-label">
                    Due Date
                </label>

                <div class="input-icon">

                    <svg width="17" height="17"
                         viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor"
                         stroke-width="2">

                        <rect x="3" y="4" width="18" height="18"
                              rx="2" ry="2"/>

                        <line x1="16" y1="2" x2="16" y2="6"/>
                        <line x1="8" y1="2" x2="8" y2="6"/>
                        <line x1="3" y1="10" x2="21" y2="10"/>

                    </svg>

                    <input type="date"
                           name="due_date"
                           class="form-control"
                           value="{{ old('due_date') }}">

                </div>

                @error('due_date')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="form-actions">

            <a href="{{ route('tasks.index') }}"
               class="btn btn-secondary">

                Cancel

            </a>

            <button type="submit"
                    class="btn btn-primary">

                <svg width="17" height="17"
                     viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2">

                    <path d="M19 21H5
                             a2 2 0 0 1-2-2V5
                             a2 2 0 0 1 2-2h11
                             l5 5v11
                             a2 2 0 0 1-2 2z"/>

                    <polyline points="17 21 17 13 7 13 7 21"/>

                    <polyline points="7 3 7 8 15 8"/>

                </svg>

                Save Task

            </button>

        </div>

    </form>

</div>

@endsection