@extends('layouts.app')

@section('content')

<style>
    .page-header {
        margin-bottom: 25px;
    }

    .page-header h1 {
        margin: 0;
        color: #2C3E50;
        font-size: 26px;
    }

    .page-header p {
        margin: 6px 0 0;
        color: #5D6D7E;
        font-size: 14px;
    }

    .form-card {
        background: #ffffff;
        border-radius: 10px;
        padding: 28px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        max-width: 900px;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
    }

    .full-width {
        grid-column: 1 / -1;
    }

    .form-label {
        color: #2C3E50;
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .required {
        color: #E74C3C;
    }

    .form-control {
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #D5DBDB;
        border-radius: 7px;
        padding: 11px 13px;
        font-size: 14px;
        color: #2C3E50;
        background: #fff;
        outline: none;
    }

    .form-control:focus {
        border-color: #3498DB;
        box-shadow: 0 0 0 3px rgba(52,152,219,0.10);
    }

    textarea.form-control {
        min-height: 130px;
        resize: vertical;
        line-height: 1.5;
    }

    .input-icon {
        position: relative;
    }

    .input-icon svg {
        position: absolute;
        left: 13px;
        top: 50%;
        transform: translateY(-50%);
        color: #7F8C8D;
        pointer-events: none;
    }

    .input-icon .form-control {
        padding-left: 40px;
    }

    .error-message {
        color: #E74C3C;
        font-size: 12px;
        margin-top: 6px;
    }

    .form-note {
        background: #EBF5FB;
        color: #2C3E50;
        border-left: 4px solid #3498DB;
        padding: 12px 14px;
        border-radius: 5px;
        font-size: 13px;
        margin-bottom: 22px;
    }

    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #ECF0F1;
    }

    .btn {
        border: none;
        border-radius: 7px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
    }

    .btn-primary {
        background: #3498DB;
        color: white;
    }

    .btn-secondary {
        background: #ECF0F1;
        color: #2C3E50;
    }

    @media (max-width: 700px) {
        .form-grid {
            grid-template-columns: 1fr;
        }

        .full-width {
            grid-column: auto;
        }

        .form-card {
            padding: 20px;
        }

        .form-actions {
            flex-direction: column;
        }
    }
</style>

<div class="page-header">
    <h1>Edit Task</h1>
    <p>Update employee task information.</p>
</div>

<div class="form-card">

    <div class="form-note">
        Update the task details and its current completion status.
    </div>

    <form action="{{ route('tasks.update', $task->id) }}" method="POST">

        @csrf
        @method('PUT')

        <div class="form-grid">

            {{-- Employee --}}
            <div class="form-group">

                <label class="form-label">
                    Employee <span class="required">*</span>
                </label>

                <select name="employee_id" class="form-control" required>

                    <option value="">Select Employee</option>

                    @foreach($employees as $employee)

                        <option value="{{ $employee->id }}"
                            {{ old('employee_id', $task->employee_id) == $employee->id ? 'selected' : '' }}>

                            {{ $employee->name }}

                        </option>

                    @endforeach

                </select>

                @error('employee_id')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="form-group">

                <label class="form-label">
                    Status <span class="required">*</span>
                </label>

                <select name="status" class="form-control" required>

                    <option value="pending"
                        {{ old('status', $task->status) === 'pending' ? 'selected' : '' }}>
                        Pending
                    </option>

                    <option value="completed"
                        {{ old('status', $task->status) === 'completed' ? 'selected' : '' }}>
                        Completed
                    </option>

                </select>

                @error('status')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Task --}}
            <div class="form-group full-width">

                <label class="form-label">
                    Task <span class="required">*</span>
                </label>

                <textarea name="task"
                          class="form-control"
                          placeholder="Enter employee task..."
                          required>{{ old('task', $task->task) }}</textarea>

                @error('task')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Task Date --}}
            <div class="form-group">

                <label class="form-label">
                    Task Date <span class="required">*</span>
                </label>

                <input type="date"
                       name="task_date"
                       class="form-control"
                       value="{{ old('task_date', $task->task_date?->format('Y-m-d')) }}"
                       required>

                @error('task_date')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>


            {{-- Due Date --}}
            <div class="form-group">

                <label class="form-label">
                    Due Date
                </label>

                <input type="date"
                       name="due_date"
                       class="form-control"
                       value="{{ old('due_date', $task->due_date?->format('Y-m-d')) }}">

                @error('due_date')
                    <div class="error-message">{{ $message }}</div>
                @enderror

            </div>

        </div>


        <div class="form-actions">

            <a href="{{ route('tasks.index') }}"
               class="btn btn-secondary">
                Cancel
            </a>

            <button type="submit"
                    class="btn btn-primary">
                Update Task
            </button>

        </div>

    </form>

</div>

@endsection