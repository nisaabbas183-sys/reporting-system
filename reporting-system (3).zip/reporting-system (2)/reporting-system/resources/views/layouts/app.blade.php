<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>{{ $title ?? 'Reporting System' }}</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #F4F6F8;
            color: #5D6D7E;
        }

        /* =========================
           SIDEBAR
        ========================= */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: #1A252F;
            color: white;
            padding: 22px 15px;
            z-index: 1000;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 12px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.10);
            margin-bottom: 20px;
        }

        .logo-icon {
            width: 42px;
            height: 42px;
            background: #3498DB;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-icon svg {
            width: 24px;
            height: 24px;
        }

        .logo-text {
            font-size: 17px;
            font-weight: 700;
            color: white;
        }

        .logo-subtitle {
            font-size: 11px;
            color: #9BA8B4;
            margin-top: 3px;
        }

        .menu-title {
            font-size: 11px;
            text-transform: uppercase;
            color: #8493A0;
            padding: 0 12px;
            margin: 20px 0 8px;
            letter-spacing: 0.8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #CBD5DC;
            text-decoration: none;
            padding: 12px;
            margin: 4px 0;
            border-radius: 7px;
            font-size: 14px;
            transition: 0.2s;
        }

        .nav-link:hover {
            background: rgba(52, 152, 219, 0.15);
            color: white;
        }

        .nav-link.active {
            background: #3498DB;
            color: white;
        }

        .nav-icon {
            width: 19px;
            height: 19px;
            flex-shrink: 0;
        }

        /* =========================
           MAIN AREA
        ========================= */

        .main {
            margin-left: 250px;
            min-height: 100vh;
        }

        /* =========================
           TOPBAR
        ========================= */

        .topbar {
            height: 72px;
            background: #FFFFFF;
            border-bottom: 1px solid #E4E8EC;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        /* Reporting System in Topbar */

        .topbar-brand {
            display: flex;
            align-items: center;
        }

        .topbar-brand span {
            color: #2C3E50;
            font-size: 21px;
            font-weight: 700;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 11px;
        }

        .admin-avatar {
            width: 39px;
            height: 39px;
            border-radius: 50%;
            background: #2C3E50;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }

        .admin-info strong {
            display: block;
            color: #2C3E50;
            font-size: 13px;
        }

        .admin-info span {
            font-size: 11px;
            color: #8493A0;
        }

        /* =========================
           CONTENT
        ========================= */

        .content {
            padding: 30px;
        }

        .content-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }

        .content-title h1 {
            color: #2C3E50;
            font-size: 25px;
            margin-bottom: 6px;
        }

        .content-title p {
            color: #5D6D7E;
            font-size: 14px;
        }

        /* =========================
           BUTTON
        ========================= */

        .btn-primary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #3498DB;
            color: white;
            text-decoration: none;
            border: none;
            padding: 11px 17px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-primary:hover {
            background: #2980B9;
        }

        .btn-icon {
            width: 17px;
            height: 17px;
        }

        /* =========================
           CARD
        ========================= */

        .card {
            background: white;
            border-radius: 10px;
            border: 1px solid #E5E9ED;
            box-shadow: 0 2px 8px rgba(44, 62, 80, 0.04);
            overflow: hidden;
        }

        .card-header {
            padding: 18px 20px;
            border-bottom: 1px solid #E9ECEF;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-header h3 {
            color: #2C3E50;
            font-size: 16px;
        }

        .card-header p {
            color: #8493A0;
            font-size: 12px;
            margin-top: 4px;
        }

        /* =========================
           TABLE
        ========================= */

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #F4F6F8;
            color: #2C3E50;
            font-size: 12px;
            font-weight: 700;
            text-align: left;
            padding: 14px 20px;
            border-bottom: 1px solid #E3E7EB;
        }

        td {
            padding: 15px 20px;
            font-size: 13px;
            color: #5D6D7E;
            border-bottom: 1px solid #EDF0F2;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background: #FAFBFC;
        }

        /* =========================
           STATUS BADGES
        ========================= */

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-success {
            color: #27AE60;
            background: #EAF8F0;
        }

        .badge-warning {
            color: #F39C12;
            background: #FEF5E7;
        }

        .badge-danger {
            color: #E74C3C;
            background: #FDEDEC;
        }

        /* =========================
           ACTIONS
        ========================= */

        .action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            margin-right: 4px;
        }

        .action-edit {
            background: #EBF5FB;
            color: #3498DB;
        }

        .action-delete {
            background: #FDEDEC;
            color: #E74C3C;
        }

        .action-btn svg {
            width: 15px;
            height: 15px;
        }

        /* =========================
           ALERT
        ========================= */

        .alert-success {
            background: #EAF8F0;
            color: #27AE60;
            border: 1px solid #C8EBD7;
            padding: 12px 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 800px) {

            .sidebar {
                width: 70px;
                padding: 15px 10px;
            }

            .logo-text,
            .logo-subtitle,
            .menu-title,
            .nav-link span {
                display: none;
            }

            .logo {
                justify-content: center;
                padding: 5px 0 20px;
            }

            .nav-link {
                justify-content: center;
            }

            .main {
                margin-left: 70px;
            }

            .content {
                padding: 20px;
            }

            .topbar {
                padding: 0 20px;
            }

            .admin-info {
                display: none;
            }
        }
    </style>

    @stack('styles')
</head>

<body>

    <!-- =========================
         SIDEBAR
    ========================= -->

    <aside class="sidebar">

        <!-- LOGO -->

        <div class="logo">

            <div class="logo-icon">

                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round">

                    <rect x="5" y="4" width="14" height="17" rx="2"></rect>
                    <path d="M9 4V2h6v2"></path>
                    <path d="M9 10h6"></path>
                    <path d="M9 14h6"></path>
                    <path d="M9 18h4"></path>

                </svg>

            </div>

            <div>

                <div class="logo-text">
                    Reporting System
                </div>

                <div class="logo-subtitle">
                    Employee Management
                </div>

            </div>

        </div>


        <!-- MAIN MENU -->

        <div class="menu-title">
            Main Menu
        </div>


        <!-- DASHBOARD -->

       <a
    href="{{ route('dashboard') }}"
    class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"
>

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>

            </svg>

            <span>Dashboard</span>

        </a>


        <!-- EMPLOYEES -->

       <a
    href="{{ route('employees.index') }}"
    class="nav-link {{ request()->routeIs('employees.*') ? 'active' : '' }}"
>
            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>

                <circle cx="9" cy="7" r="4"></circle>

                <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>

                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>

            </svg>

           <span>User Creation</span>

        </a>


        <!-- DEPARTMENTS -->

        <a
            href="{{ route('departments.index') }}"
            class="nav-link {{ request()->routeIs('departments.*') ? 'active' : '' }}"
        >

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <path d="M3 21h18"></path>

                <path d="M5 21V5l7-3 7 3v16"></path>

                <path d="M9 21v-4h6v4"></path>

                <path d="M8 9h1"></path>
                <path d="M15 9h1"></path>

                <path d="M8 13h1"></path>
                <path d="M15 13h1"></path>

            </svg>

            <span>Departments</span>

        </a>


        <!-- REPORTING -->

        <div class="menu-title">
            Reporting
        </div>


        <!-- DAILY REPORTS -->

        <a
            href="{{ route('daily-reports.index') }}"
            class="nav-link {{ request()->routeIs('daily-reports.*') ? 'active' : '' }}"
        >

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>

                <polyline points="14 2 14 8 20 8"></polyline>

                <line x1="8" y1="13" x2="16" y2="13"></line>

                <line x1="8" y1="17" x2="16" y2="17"></line>

                <line x1="8" y1="9" x2="10" y2="9"></line>

            </svg>

            <span>Daily Reports</span>

        </a>


        <!-- TASKS -->

       <a
    href="{{ route('tasks.index') }}"
    class="nav-link {{ request()->routeIs('tasks.*') ? 'active' : '' }}"
>

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <rect x="3" y="4" width="18" height="17" rx="2"></rect>

                <path d="M8 2v4"></path>

                <path d="M16 2v4"></path>

                <path d="M3 10h18"></path>

                <path d="M8 15l2 2 2 2 5-5"></path>

            </svg>

            <span>Tasks</span>

        </a>


        <!-- SYSTEM -->

        <div class="menu-title">
            System
        </div>

        <!-- EMAIL SETTINGS -->

        
           <a href="{{ route('email-settings.edit') }}"
            class="nav-link {{ request()->routeIs('email-settings.*') ? 'active' : '' }}"
        >

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <rect x="3" y="5" width="18" height="14" rx="2"></rect>
                <polyline points="3 7 12 13 21 7"></polyline>

            </svg>

            <span>Email Settings</span>

        </a>
        <!-- SETTINGS -->


<a
    href="{{ url('/settings') }}"
    class="nav-link {{ request()->is('settings*') ? 'active' : '' }}"
>

            <svg class="nav-icon"
                 viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">

                <circle cx="12" cy="12" r="3"></circle>

                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06-1.42 1.42-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V20h-2v-.08a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1 1.51V20H8v-.08a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06-1.42-1.42.06-.06A1.65 1.65 0 0 0 6.6 15a1.65 1.65 0 0 0-1.51-1H5v-2h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06 1.42-1.42.06.06A1.65 1.65 0 0 0 8.6 9a1.65 1.65 0 0 0 1-1.51V7h2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1-1.51V7h2v.09a1.65 1.65 0 0 0 1.51 1.51 1.65 1.65 0 0 0 1.51 1.51 1.65 1.65 0 0 0-.33 1.82l.06.06 1.42 1.42-.06.06A1.65 1.65 0 0 0 19.4 15z"></path>

            </svg>

            <span>Settings</span>

        </a>


        <!-- LOGOUT -->

       <form action="{{ route('logout') }}" method="POST" style="margin: 0;">
    @csrf

    <button
        type="submit"
        class="nav-link"
        style="width: 100%; border: 0; cursor: pointer; background: transparent; text-align: left;"
    >

        <svg class="nav-icon"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">

            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
            <polyline points="16 17 21 12 16 7"></polyline>
            <line x1="21" y1="12" x2="9" y2="12"></line>

        </svg>

        <span>Logout</span>

    </button>
</form>

    </aside>


    <!-- =========================
         MAIN
    ========================= -->

    <main class="main">

        <!-- TOPBAR -->

        <header class="topbar">

            <!-- ONLY SYSTEM NAME -->

            <div class="topbar-brand">
                <span>Reporting System</span>
            </div>


            <!-- ADMIN -->

            <div class="admin-profile">

                <div class="admin-avatar">
                    A
                </div>

                <div class="admin-info">

                    <strong>
                        Admin
                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>

            </div>

        </header>


        <!-- PAGE CONTENT -->

        <section class="content">

            @yield('content')

        </section>

    </main>


    @stack('scripts')

</body>
</html>