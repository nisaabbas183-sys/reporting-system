@extends('layouts.app')

@section('content')

<div class="page-header">
    <div>
        <h1>Email Settings</h1>
        <p>Configure the daily report email, recipient and sending time.</p>
    </div>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

@if($errors->any())
    <div class="alert alert-danger">
        <strong>Please fix the following errors:</strong>
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('email-settings.update') }}" method="POST">
    @csrf
    @method('PUT')

    <div class="card">

        <div class="card-header">
            <h3>Schedule</h3>
            <p>The PDF of that day's report is emailed once daily at this time.</p>
        </div>

        <div class="card-body grid">

            <div class="form-group">
                <label>Sending Time <span>*</span></label>
                <input type="time" name="send_time"
                       value="{{ old('send_time', $setting->send_time) }}" required>
            </div>

            <div class="form-group">
                <label>Automatic Sending</label>
                <label class="switch-row">
                    <input type="checkbox" name="is_enabled" value="1"
                           {{ old('is_enabled', $setting->is_enabled) ? 'checked' : '' }}>
                    <span>Enable daily email</span>
                </label>
            </div>

            <div class="form-group full">
                <label>Recipient Email(s) <span>*</span></label>
                <input type="text" name="recipients"
                       value="{{ old('recipients', $setting->recipients) }}"
                       placeholder="sir@company.com, manager@company.com" required>
                <small>Separate multiple emails with a comma.</small>
            </div>

        </div>
    </div>

    <div class="card">

        <div class="card-header">
            <h3>SMTP Server</h3>
            <p>The email account the report is sent from.</p>
        </div>

        <div class="card-body grid">

            <div class="form-group">
                <label>SMTP Host <span>*</span></label>
                <input type="text" name="smtp_host"
                       value="{{ old('smtp_host', $setting->smtp_host) }}"
                       placeholder="smtp.gmail.com" required>
            </div>

            <div class="form-group">
                <label>SMTP Port <span>*</span></label>
                <input type="number" name="smtp_port"
                       value="{{ old('smtp_port', $setting->smtp_port) }}" required>
            </div>

            <div class="form-group">
                <label>Username <span>*</span></label>
                <input type="text" name="smtp_username"
                       value="{{ old('smtp_username', $setting->smtp_username) }}" required>
            </div>

            <div class="form-group">
                <label>Password / App Password</label>
                <input type="password" name="smtp_password" autocomplete="new-password"
                       placeholder="{{ $setting->smtp_password ? '•••••••• (leave blank to keep current)' : 'Enter password' }}">
            </div>

            <div class="form-group">
                <label>Encryption <span>*</span></label>
                <select name="smtp_encryption" required>
                    <option value="tls" {{ old('smtp_encryption', $setting->smtp_encryption) === 'tls' ? 'selected' : '' }}>
                        TLS (port 587)
                    </option>
                    <option value="ssl" {{ old('smtp_encryption', $setting->smtp_encryption) === 'ssl' ? 'selected' : '' }}>
                        SSL (port 465)
                    </option>
                </select>
            </div>

            <div class="form-group"></div>

            <div class="form-group">
                <label>From Email <span>*</span></label>
                <input type="email" name="from_email"
                       value="{{ old('from_email', $setting->from_email) }}" required>
            </div>

            <div class="form-group">
                <label>From Name <span>*</span></label>
                <input type="text" name="from_name"
                       value="{{ old('from_name', $setting->from_name ?: 'Star Automation') }}" required>
            </div>

        </div>
    </div>

    <div class="actions">
        <button type="submit" class="btn btn-primary">Save Settings</button>
    </div>
</form>

<form action="{{ route('email-settings.test') }}" method="POST" class="test-form">
    @csrf
    <button type="submit" class="btn btn-secondary">Send Test Email (today's report)</button>
    <small>Save the settings first, then send a test.</small>
</form>

@if($setting->last_sent_date)
    <p class="last-sent">Last automatic email sent on: {{ $setting->last_sent_date->format('d M Y') }}</p>
@endif


<style>
.page-header { margin-bottom: 24px; }
.page-header h1 { margin: 0 0 6px; color: #2C3E50; font-size: 28px; }
.page-header p { margin: 0; color: #5D6D7E; }

.card { background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,.05); margin-bottom: 22px; overflow: hidden; }
.card-header { padding: 18px 24px; border-bottom: 1px solid #EAECEE; }
.card-header h3 { margin: 0 0 4px; color: #2C3E50; font-size: 16px; }
.card-header p { margin: 0; color: #8493A0; font-size: 12px; }
.card-body { padding: 24px; }
.grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.full { grid-column: 1 / -1; }

.form-group label { display: block; color: #2C3E50; font-size: 13px; font-weight: 600; margin-bottom: 7px; }
.form-group label span { color: #E74C3C; }
.form-group input[type=text], .form-group input[type=email], .form-group input[type=password],
.form-group input[type=number], .form-group input[type=time], .form-group select {
    width: 100%; box-sizing: border-box; border: 1px solid #D5DBDB; border-radius: 7px;
    padding: 11px 13px; font-size: 14px; color: #2C3E50; background: #fff; outline: none;
}
.form-group input:focus, .form-group select:focus { border-color: #3498DB; box-shadow: 0 0 0 3px rgba(52,152,219,.1); }
.form-group small { display: block; margin-top: 6px; color: #8493A0; font-size: 12px; }

.switch-row { display: flex !important; align-items: center; gap: 10px; font-weight: 500 !important; padding-top: 10px; }
.switch-row input { width: 18px; height: 18px; }

.alert { padding: 13px 16px; border-radius: 7px; margin-bottom: 20px; font-size: 14px; }
.alert-success { background: #E8F8F0; color: #27AE60; }
.alert-danger { background: #FDEDEC; color: #C0392B; }
.alert-danger ul { margin: 8px 0 0 20px; }

.actions { margin-bottom: 18px; }
.btn { border: none; border-radius: 7px; padding: 11px 20px; font-size: 14px; font-weight: 600; cursor: pointer; }
.btn-primary { background: #3498DB; color: #fff; }
.btn-secondary { background: #ECF0F1; color: #2C3E50; }
.test-form small { margin-left: 10px; color: #8493A0; font-size: 12px; }
.last-sent { margin-top: 18px; color: #5D6D7E; font-size: 13px; }

@media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
</style>

@endsection