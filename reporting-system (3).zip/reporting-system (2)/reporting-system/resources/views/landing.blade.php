<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Reporting System</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(
                135deg,
                #e8eef7 0%,
                #dce6f2 50%,
                #eef3f8 100%
            );
            color: #1e293b;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .page {
            width: 100%;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .card {
            width: 100%;
            max-width: 620px;
            background: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.8);
            border-radius: 18px;
            padding: 55px 50px;
            text-align: center;
            box-shadow:
                0 20px 50px rgba(15, 23, 42, 0.10),
                0 4px 12px rgba(15, 23, 42, 0.05);
        }

        .icon {
            width: 68px;
            height: 68px;
            margin: 0 auto 24px;
            border-radius: 14px;
            background: #1e293b;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 700;
        }

        h1 {
            font-size: 34px;
            font-weight: 700;
            letter-spacing: -0.5px;
            margin-bottom: 12px;
            color: #0f172a;
        }

        .subtitle {
            font-size: 16px;
            line-height: 1.7;
            color: #64748b;
            margin-bottom: 30px;
        }

        /* Loading Area */
        .loading-area {
            width: 100%;
            max-width: 360px;
            margin: 0 auto;
        }

        .loading-text {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 10px;
        }

        .progress-track {
            width: 100%;
            height: 6px;
            background: #e5e7eb;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            width: 0%;
            background: #3498DB;
            border-radius: 10px;
            animation: loading 3s linear forwards;
        }

        @keyframes loading {
            0% {
                width: 0%;
            }

            100% {
                width: 100%;
            }
        }

        .loading-percent {
            margin-top: 9px;
            font-size: 11px;
            color: #94a3b8;
        }

        .footer {
            margin-top: 30px;
            font-size: 13px;
            color: #94a3b8;
        }

        @media (max-width: 600px) {
            .card {
                padding: 40px 25px;
            }

            h1 {
                font-size: 28px;
            }
        }
    </style>
</head>

<body>

<div class="page">

    <div class="card">

        <div class="icon">
            RS
        </div>

        <h1>Reporting System</h1>

        <p class="subtitle">
            Employee Daily Reporting Management System
        </p>

        <div class="loading-area">

            <div class="loading-text">
                Loading Reporting System...
            </div>

            <div class="progress-track">
                <div class="progress-bar"></div>
            </div>

            <div class="loading-percent">
                Please wait...
            </div>

        </div>

        <div class="footer">
            Secure Reporting &amp; Management Portal
        </div>

    </div>

</div>

<script>
    setTimeout(function () {
        window.location.href = "{{ route('login') }}";
    }, 3000);
</script>

</body>
</html>