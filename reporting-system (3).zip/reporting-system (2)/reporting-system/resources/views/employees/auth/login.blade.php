<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Employee Login - Reporting System</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;

            background: linear-gradient(
                135deg,
                #e8eef7 0%,
                #dce6f2 50%,
                #eef3f8 100%
            );

            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            width: 100%;
            max-width: 430px;

            background: #ffffff;

            border-radius: 18px;
            padding: 42px;

            box-shadow:
                0 20px 50px rgba(15, 23, 42, 0.10),
                0 4px 12px rgba(15, 23, 42, 0.05);

            border: 1px solid #e2e8f0;
        }

        .logo {
            width: 62px;
            height: 62px;

            margin: 0 auto 22px;

            background: #1e293b;
            color: #ffffff;

            border-radius: 14px;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 22px;
            font-weight: 700;
        }

        h1 {
            text-align: center;

            color: #0f172a;

            font-size: 27px;

            margin-bottom: 8px;
        }

        .subtitle {
            text-align: center;

            color: #64748b;

            font-size: 14px;

            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;

            margin-bottom: 8px;

            color: #334155;

            font-size: 14px;
            font-weight: 600;
        }

        input {
            width: 100%;

            padding: 13px 14px;

            border: 1px solid #cbd5e1;

            border-radius: 8px;

            font-size: 14px;

            outline: none;

            transition: 0.2s;
        }

        input:focus {
            border-color: #64748b;

            box-shadow:
                0 0 0 3px rgba(100, 116, 139, 0.12);
        }

        .login-btn {
            width: 100%;

            border: none;

            padding: 14px;

            border-radius: 8px;

            background: #1e293b;

            color: #ffffff;

            font-size: 15px;
            font-weight: 600;

            cursor: pointer;

            transition: 0.2s;
        }

        .login-btn:hover {
            background: #0f172a;

            transform: translateY(-1px);
        }

        .error {
            background: #fef2f2;

            border: 1px solid #fecaca;

            color: #b91c1c;

            padding: 11px 13px;

            border-radius: 8px;

            margin-bottom: 20px;

            font-size: 13px;
        }

        .back-link {
            display: block;

            text-align: center;

            margin-top: 22px;

            color: #64748b;

            text-decoration: none;

            font-size: 13px;
        }

        .back-link:hover {
            color: #1e293b;
        }
    </style>
</head>

<body>

<div class="login-card">

    <div class="logo">
        RS
    </div>

    <h1>Employee Login</h1>

    <p class="subtitle">
        Sign in to access your Employee Dashboard
    </p>

    @if ($errors->any())
        <div class="error">
            {{ $errors->first() }}
        </div>
    @endif

    <form method="POST" action="{{ route('employee.login.submit') }}">
        @csrf

        <div class="form-group">

            <label for="email">
                Email Address
            </label>

            <input
                type="email"
                id="email"
                name="email"
                value="{{ old('email') }}"
                placeholder="Enter employee email"
                required
                autofocus
            >

        </div>

        <div class="form-group">

            <label for="password">
                Password
            </label>

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter employee password"
                required
            >

        </div>

        <button
            type="submit"
            class="login-btn"
        >
            Sign In
        </button>

    </form>

    <a
        href="{{ route('home') }}"
        class="back-link"
    >
        ← Back to Starting Page
    </a>

</div>

</body>
</html>