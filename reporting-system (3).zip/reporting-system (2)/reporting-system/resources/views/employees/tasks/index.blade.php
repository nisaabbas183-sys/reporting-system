<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tasks - Reporting System</title>

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #1e293b;
        }

        .layout { min-height: 100vh; display: flex; }

        .sidebar {
            width: 250px;
            background: #0f172a;
            color: white;
            position: fixed;
            top: 0; bottom: 0; left: 0;
        }

        .brand { padding: 25px 22px; border-bottom: 1px solid rgba(255,255,255,.08); }
        .brand-title { font-size: 20px; font-weight: 700; }
        .brand-subtitle { color: #94a3b8; font-size: 12px; margin-top: 5px; }

        .nav { padding: 20px 14px; }
        .nav-label {
            color: #64748b; font-size: 11px; text-transform: uppercase;
            letter-spacing: 1px; padding: 0 12px; margin-bottom: 10px; font-weight: 700;
        }

        .nav-link {
            display: flex; gap: 12px; align-items: center; padding: 12px 13px;
            margin-bottom: 5px; color: #cbd5e1; text-decoration: none;
            border-radius: 8px; font-size: 14px;
        }

        .nav-link:hover, .nav-link.active { background: #1e293b; color: white; }

        .sidebar-bottom {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 18px 14px; border-top: 1px solid rgba(255,255,255,.08);
        }

        .logout {
            width: 100%; padding: 10px; background: transparent;
            border: 1px solid rgba(255,255,255,.1); border-radius: 7px;
            color: #cbd5e1; cursor: pointer;
        }

        .logout:hover { background: #1e293b; color: white; }

        .main { margin-left: 250px; width: calc(100% - 250px); }

        .topbar {
            height: 72px; background: white; border-bottom: 1px solid #e2e8f0;
            display: flex; align-items: center; padding: 0 32px;
        }

        .topbar-title { font-size: 18px; font-weight: 700; color: #0f172a; }

        .content { padding: 32px; max-width: 1100px; }

        .page-header { margin-bottom: 25px; }
        .page-header h1 { font-size: 25px; margin-bottom: 7px; }
        .page-header p { color: #64748b; font-size: 14px; }

        .alert {
            padding: 13px 15px; border-radius: 8px; margin-bottom: 20px; font-size: 13px;
        }

        .success {
            background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d;
        }

        .error {
            background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c;
        }

        .card {
            background: white; border: 1px solid #e2e8f0; border-radius: 12px;
            padding: 25px; margin-bottom: 22px; box-shadow: 0 2px 7px rgba(15,23,42,.03);
        }

        .card-title { font-size: 16px; font-weight: 700; margin-bottom: 5px; color: #0f172a; }
        .card-subtitle { color: #94a3b8; font-size: 12px; margin-bottom: 22px; }

        .task-item {
            display: flex; align-items: flex-start; justify-content: space-between;
            gap: 13px; padding: 14px; border: 1px solid #e2e8f0; border-radius: 8px;
            margin-bottom: 10px; background: #fafbfc;
        }

        .task-text { font-size: 14px; font-weight: 600; color: #334155; }
        .task-date { font-size: 11px; color: #94a3b8; margin-top: 5px; }

        .task-right {
            display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
        }

        .badge {
            padding: 4px 10px; border-radius: 12px; font-size: 11px;
            font-weight: 600; white-space: nowrap;
        }

        .badge-pending { background: #fef3e7; color: #f39c12; }
        .badge-submitted { background: #eaf2ff; color: #2563eb; }
        .badge-completed { background: #eafaf0; color: #27ae60; }

        .submit-btn {
            padding: 6px 12px; background: #0f172a; color: white; border: none;
            border-radius: 6px; font-size: 12px; cursor: pointer; white-space: nowrap;
        }

        .submit-btn:hover { background: #1e293b; }

        .no-tasks { color: #94a3b8; font-size: 13px; padding: 10px 0; }

        @media (max-width: 850px) {
            .sidebar { width: 70px; }
            .brand-title, .brand-subtitle, .nav-label,
            .nav-link span:not(.nav-icon) { display: none; }
            .main { margin-left: 70px; width: calc(100% - 70px); }
            .content { padding: 20px; }
        }
    </style>
</head>

<body>

<div class="layout">

    <aside class="sidebar">

        <div class="brand">
            <div class="brand-title">Reporting System</div>
            <div class="brand-subtitle">Employee Management</div>
        </div>

        <nav class="nav">

            <div class="nav-label">Employee Portal</div>

            <a href="{{ route('employee.dashboard') }}" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a href="{{ route('employee.daily-reports.create') }}" class="nav-link">
                <span class="nav-icon">▤</span>
                <span>Daily Report</span>
            </a>

            <a href="{{ route('employee.tasks.index') }}" class="nav-link active">
                <span class="nav-icon">☑</span>
                <span>My Tasks</span>
            </a>

            <div class="nav-label" style="margin-top: 20px;">Account</div>

            <a href="{{ route('employee.profile.index') }}" class="nav-link">
                <span class="nav-icon">👤</span>
                <span>My Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">
            <form method="POST" action="{{ route('employee.logout') }}">
                @csrf
                <button type="submit" class="logout">Logout</button>
            </form>
        </div>

    </aside>


    <main class="main">

        <header class="topbar">
            <div class="topbar-title">My Tasks</div>
        </header>

        <section class="content">

            <div class="page-header">
                <h1>My Tasks</h1>
                <p>View your pending, submitted and approved tasks.</p>
            </div>

            @if (session('success'))
                <div class="alert success">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="alert error">
                    {{ session('error') }}
                </div>
            @endif


            <!-- PENDING TASKS -->
            <div class="card">

                <div class="card-title">Pending Tasks</div>
                <div class="card-subtitle">
                    {{ $pendingTasks->count() }} task(s) awaiting completion.
                </div>

                @forelse ($pendingTasks as $task)

                    <div class="task-item">

                        <div>
                            <div class="task-text">{{ $task->task }}</div>
                            <div class="task-date">
                                Task Date: {{ $task->task_date->format('d M Y') }}
                            </div>
                        </div>

                        <div class="task-right">
                            <span class="badge badge-pending">Pending</span>

                            <form method="POST" action="{{ route('employee.tasks.submit', $task->id) }}">
                                @csrf
                                <button type="submit" class="submit-btn">
                                    Submit for Approval
                                </button>
                            </form>
                        </div>

                    </div>

                @empty

                    <div class="no-tasks">🎉 No pending tasks.</div>

                @endforelse

            </div>


            <!-- SUBMITTED TASKS -->
            <div class="card">

                <div class="card-title">Submitted Tasks</div>
                <div class="card-subtitle">
                    {{ $submittedTasks->count() }} task(s) awaiting admin approval.
                </div>

                @forelse ($submittedTasks as $task)

                    <div class="task-item">

                        <div>
                            <div class="task-text">{{ $task->task }}</div>
                            <div class="task-date">
                                Task Date: {{ $task->task_date->format('d M Y') }}
                            </div>
                        </div>

                        <span class="badge badge-submitted">Awaiting Approval</span>

                    </div>

                @empty

                    <div class="no-tasks">No tasks submitted for approval.</div>

                @endforelse

            </div>


            <!-- APPROVED TASKS -->
            <div class="card">

                <div class="card-title">Approved Tasks</div>
                <div class="card-subtitle">
                    {{ $approvedTasks->count() }} task(s) approved.
                </div>

                @forelse ($approvedTasks as $task)

                    <div class="task-item">

                        <div>
                            <div class="task-text">{{ $task->task }}</div>
                            <div class="task-date">
                                Approved:
                                {{ $task->completed_at ? $task->completed_at->format('d M Y') : 'N/A' }}
                            </div>
                        </div>

                        <span class="badge badge-completed">Approved</span>

                    </div>

                @empty

                    <div class="no-tasks">No approved tasks yet.</div>

                @endforelse

            </div>

        </section>

    </main>

</div>

</body>

</html>