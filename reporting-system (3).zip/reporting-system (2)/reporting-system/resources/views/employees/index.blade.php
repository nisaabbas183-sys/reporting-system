@extends('layouts.app')

@section('content')

<div class="page-header">
    <div>
        <h1>User Creation</h1>
        <p>Manage employees and their information.</p>
    </div>

    <a href="{{ route('employees.create') }}" class="btn btn-primary">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2" stroke-linecap="round"
             stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
        </svg>
        Add Employee
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2" stroke-linecap="round"
             stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
        </svg>

        {{ session('success') }}
    </div>
@endif

<div class="card">

    <div class="card-header">
        <div>
            <h3>Employee List</h3>
            <p>{{ $employees->count() }} employees found</p>
        </div>
    </div>

    <form id="assignTaskForm" action="{{ route('tasks.create') }}" method="GET">

    <div class="table-responsive">

        <table class="data-table">

            <thead>
                <tr>
                    <th style="width: 40px;">
                        <input type="checkbox" id="selectAll" class="row-checkbox">
                    </th>
                    <th>#</th>
                    <th>Employee</th>
                    <th>Department</th>
                    <th>Report Section Head</th>
                    <th>Email</th>
                    <th>Cell Number</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

                @forelse($employees as $employee)

                    <tr>

                        <td>
                            <input type="checkbox"
                                   name="employee_ids[]"
                                   value="{{ $employee->id }}"
                                   data-name="{{ $employee->name }}"
                                   class="row-checkbox employee-checkbox">
                        </td>

                        <td>
                            {{ $loop->iteration }}
                        </td>

                        <td>
                            <div class="employee-info">

                                <div class="employee-avatar">
                                    {{ strtoupper(substr($employee->name, 0, 1)) }}
                                </div>

                                <div>
                                    <strong>{{ $employee->name }}</strong>
                                </div>

                            </div>
                        </td>

                        <td>
                            {{ $employee->department->name ?? 'N/A' }}
                        </td>

                        <td>
                            {{ $employee->report_section_head }}
                        </td>

                        <td>
                            {{ $employee->email }}
                        </td>

                        <td>
                            {{ $employee->cell_number }}
                        </td>

                       <td>

    <form action="{{ route('employees.toggle-status', $employee->id) }}"
          method="POST">

        @csrf
        @method('PATCH')

        <button type="submit"
                class="status-btn {{ $employee->status ? 'status-active' : 'status-inactive' }}"
                title="Click to change status">

            <span class="status-dot"></span>

            {{ $employee->status ? 'Active' : 'Inactive' }}

        </button>

    </form>

</td>

                        <td>

                            <div class="action-buttons">

                                <a href="{{ route('tasks.create', ['employee_ids' => [$employee->id]]) }}"
                                   class="action-btn assign-btn"
                                   title="Assign Task">

                                    <svg width="17" height="17"
                                         viewBox="0 0 24 24"
                                         fill="none"
                                         stroke="currentColor"
                                         stroke-width="2"
                                         stroke-linecap="round"
                                         stroke-linejoin="round">

                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                        <path d="M9 16l2 2 4-4"></path>

                                    </svg>

                                </a>

                                <a href="{{ route('employees.edit', $employee->id) }}"
                                   class="action-btn edit-btn"
                                   title="Edit Employee">

                                    <svg width="17" height="17"
                                         viewBox="0 0 24 24"
                                         fill="none"
                                         stroke="currentColor"
                                         stroke-width="2"
                                         stroke-linecap="round"
                                         stroke-linejoin="round">

                                        <path d="M12 20h9"></path>
                                        <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"></path>

                                    </svg>

                                </a>

                                <form action="{{ route('employees.destroy', $employee->id) }}"
                                      method="POST"
                                      onsubmit="return confirm('Are you sure you want to delete this employee?');">

                                    @csrf
                                    @method('DELETE')

                                    <button type="submit"
                                            class="action-btn delete-btn"
                                            title="Delete Employee">

                                        <svg width="17" height="17"
                                             viewBox="0 0 24 24"
                                             fill="none"
                                             stroke="currentColor"
                                             stroke-width="2"
                                             stroke-linecap="round"
                                             stroke-linejoin="round">

                                            <polyline points="3 6 5 6 21 6"></polyline>
                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                                            <path d="M10 11v6"></path>
                                            <path d="M14 11v6"></path>

                                        </svg>

                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td colspan="9" class="empty-state">

                            <div class="empty-icon">

                                <svg width="42" height="42"
                                     viewBox="0 0 24 24"
                                     fill="none"
                                     stroke="currentColor"
                                     stroke-width="1.5"
                                     stroke-linecap="round"
                                     stroke-linejoin="round">

                                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="9" cy="7" r="4"></circle>
                                    <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>

                                </svg>

                            </div>

                            <h3>No Employees Found</h3>

                            <p>Add your first employee to get started.</p>

                            <a href="{{ route('employees.create') }}"
                               class="btn btn-primary">
                                Add Employee
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>

    </form>

</div>


<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.page-header h1 {
    margin: 0 0 6px;
    color: #2C3E50;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #5D6D7E;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 18px;
    border-radius: 7px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
}

.btn-primary {
    background: #3498DB;
    color: white;
}

.btn-primary:hover {
    opacity: 0.9;
}

.card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}

.card-header {
    padding: 20px 24px;
    border-bottom: 1px solid #EAECEE;
}

.card-header h3 {
    margin: 0 0 5px;
    color: #2C3E50;
}

.card-header p {
    margin: 0;
    color: #5D6D7E;
    font-size: 13px;
}

.table-responsive {
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
}

.data-table th {
    background: #F4F6F8;
    color: #5D6D7E;
    font-size: 12px;
    font-weight: 700;
    text-align: left;
    padding: 14px 18px;
    white-space: nowrap;
}

.data-table td {
    padding: 16px 18px;
    border-bottom: 1px solid #F0F2F3;
    color: #5D6D7E;
    font-size: 14px;
    white-space: nowrap;
}

.data-table tbody tr:hover {
    background: #FAFBFC;
}

.employee-info {
    display: flex;
    align-items: center;
    gap: 11px;
}

.employee-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: #2C3E50;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    flex-shrink: 0;
}

.employee-info strong {
    color: #2C3E50;
}

.action-buttons {
    display: flex;
    align-items: center;
    gap: 7px;
}

.action-btn {
    width: 34px;
    height: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    text-decoration: none;
}

.assign-btn {
    background: #EAF6EE;
    color: #27AE60;
}

.assign-btn:hover {
    background: #D5F1DE;
}

.edit-btn {
    background: #EBF5FB;
    color: #3498DB;
}

.delete-btn {
    background: #FDEDEC;
    color: #E74C3C;
}

.alert {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 13px 16px;
    margin-bottom: 20px;
    border-radius: 7px;
}

.alert-success {
    background: #E8F8F0;
    color: #27AE60;
}

.empty-state {
    text-align: center;
    padding: 60px 20px !important;
}

.empty-icon {
    color: #5D6D7E;
    margin-bottom: 15px;
}

.empty-state h3 {
    margin: 0 0 7px;
    color: #2C3E50;
}

.empty-state p {
    color: #5D6D7E;
    margin-bottom: 18px;
}
.status-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    border: none;
    border-radius: 20px;
    padding: 6px 11px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
}

.status-active {
    background: #E8F8F0;
    color: #27AE60;
}

.status-inactive {
    background: #FDEDEC;
    color: #E74C3C;
}

.status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: currentColor;
}

@media (max-width: 768px) {

    .page-header {
        align-items: flex-start;
        gap: 15px;
        flex-direction: column;
    }

    .page-header .btn {
        width: 100%;
        justify-content: center;
    }
}

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    const bar = document.createElement('div');
    bar.id = 'assignTaskBar';
    bar.innerHTML = `
        <div class="atb-avatars" id="atbAvatars"></div>
        <span class="atb-text" id="atbText">0 selected</span>
        <button type="submit" form="assignTaskForm" class="atb-btn">
            Assign Task
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round"
                 stroke-linejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
        </button>
    `;

    document.body.appendChild(bar);

    const style = document.createElement('style');
    style.innerHTML = `
        #assignTaskBar {
            position: fixed;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%) translateY(120%);
            background: #ffffff;
            border: 1px solid #E2E8F0;
            padding: 12px 14px 12px 18px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 12px 32px rgba(15, 23, 42, 0.18);
            z-index: 99999;
            opacity: 0;
            transition: transform 0.25s ease, opacity 0.25s ease;
            pointer-events: none;
        }

        #assignTaskBar.visible {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
            pointer-events: auto;
        }

        .atb-avatars {
            display: flex;
        }

        .atb-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #2C3E50;
            color: white;
            font-size: 12px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
            margin-left: -8px;
        }

        .atb-avatar:first-child {
            margin-left: 0;
        }

        .atb-avatar.more {
            background: #64748B;
        }

        .atb-text {
            font-size: 13px;
            font-weight: 600;
            color: #2C3E50;
            white-space: nowrap;
        }

        .atb-btn {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            background: #3498DB;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
        }

        .atb-btn:hover {
            background: #2980B9;
        }

        @media (max-width: 600px) {
            #assignTaskBar {
                left: 12px;
                right: 12px;
                transform: translateY(120%);
                width: auto;
            }
            #assignTaskBar.visible {
                transform: translateY(0);
            }
        }
    `;
    document.head.appendChild(style);


    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.employee-checkbox');
    const avatarsBox = document.getElementById('atbAvatars');
    const textEl = document.getElementById('atbText');

    function updateBar() {

        const checked = Array.from(
            document.querySelectorAll('.employee-checkbox:checked')
        );

        if (checked.length > 0) {
            bar.classList.add('visible');
        } else {
            bar.classList.remove('visible');
        }

        textEl.textContent = checked.length + ' employee' +
            (checked.length > 1 ? 's' : '') + ' selected';

        avatarsBox.innerHTML = '';

        checked.slice(0, 4).forEach(cb => {
            const name = cb.getAttribute('data-name') || '?';
            const initial = name.trim().charAt(0).toUpperCase();
            const avatar = document.createElement('div');
            avatar.className = 'atb-avatar';
            avatar.textContent = initial;
            avatarsBox.appendChild(avatar);
        });

        if (checked.length > 4) {
            const more = document.createElement('div');
            more.className = 'atb-avatar more';
            more.textContent = '+' + (checked.length - 4);
            avatarsBox.appendChild(more);
        }

        selectAll.checked = checked.length === checkboxes.length && checkboxes.length > 0;
    }

    selectAll.addEventListener('change', function () {
        checkboxes.forEach(cb => cb.checked = selectAll.checked);
        updateBar();
    });

    checkboxes.forEach(cb => {
        cb.addEventListener('change', updateBar);
    });

});

</script>

@endsection