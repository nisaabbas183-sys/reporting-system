<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Employee Dashboard - Reporting System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #F4F6F8;
            color: #5D6D7E;
        }

        /* =========================
           SIDEBAR
        ========================= */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: #1A252F;
            color: white;
            padding: 22px 14px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px 28px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            margin-bottom: 20px;
        }

        .brand-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #3498DB;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .brand-text strong {
            display: block;
            font-size: 16px;
            color: white;
        }

        .brand-text span {
            display: block;
            font-size: 11px;
            color: #9AA7B2;
            margin-top: 3px;
        }

        .menu-title {
            color: #7F8C8D;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            padding: 0 12px;
            margin: 20px 0 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 13px;
            margin-bottom: 5px;
            border-radius: 8px;
            color: #BDC3C7;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .nav-link:hover,
        .nav-link.active {
            background: #2C3E50;
            color: white;
        }

        .nav-icon {
            width: 19px;
            height: 19px;
            flex-shrink: 0;
        }

        /* =========================
           MAIN
        ========================= */

        .main {
            margin-left: 250px;
            min-height: 100vh;
        }

        /* =========================
           TOPBAR
        ========================= */

        .topbar {
            height: 70px;
            background: white;
            border-bottom: 1px solid #E5E7EB;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        .topbar-title {
            color: #2C3E50;
            font-size: 18px;
            font-weight: 700;
        }

        .topbar-subtitle {
            font-size: 12px;
            color: #95A5A6;
            margin-top: 3px;
        }

        .employee-user {
            display: flex;
            align-items: center;
            gap: 11px;
        }

        /* =========================
           PROFILE IMAGE
        ========================= */

        .avatar {
            width: 42px;
            height: 42px;
            min-width: 42px;
            border-radius: 50%;
            background: #3498DB;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 15px;
            overflow: hidden;
            border: 2px solid #EAF4FB;
        }

        .avatar img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
            border-radius: 50%;
        }

        .employee-user-info strong {
            display: block;
            font-size: 13px;
            color: #2C3E50;
        }

        .employee-user-info span {
            display: block;
            font-size: 11px;
            color: #95A5A6;
            margin-top: 2px;
        }

        /* =========================
           CONTENT
        ========================= */

        .content {
            padding: 30px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h1 {
            margin: 0;
            font-size: 26px;
            color: #2C3E50;
        }

        .welcome p {
            margin: 7px 0 0;
            color: #7F8C8D;
            font-size: 14px;
        }

        /* =========================
           STATS
        ========================= */

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
        }

        .blue {
            background: #EAF4FB;
            color: #3498DB;
        }

        .orange {
            background: #FEF3E7;
            color: #F39C12;
        }

        .green {
            background: #EAF8F0;
            color: #27AE60;
        }

        .stat-info span {
            display: block;
            font-size: 12px;
            color: #95A5A6;
            margin-bottom: 5px;
        }

        .stat-info strong {
            font-size: 24px;
            color: #2C3E50;
        }

        /* =========================
           GRID
        ========================= */

        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
        }

        .card {
            background: white;
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 20px;
        }

        .card-header {
            padding: 18px 20px;
            border-bottom: 1px solid #EAECEF;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-header h2 {
            margin: 0;
            color: #2C3E50;
            font-size: 16px;
        }

        .card-header span {
            font-size: 12px;
            color: #95A5A6;
        }

        .card-body {
            padding: 20px;
        }

        /* =========================
           DEPARTMENT
        ========================= */

        .department-box {
            display: flex;
            align-items: center;
            gap: 15px;
            background: #F8FAFC;
            border: 1px solid #E5E7EB;
            border-radius: 10px;
            padding: 18px;
        }

        .department-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: #EAF4FB;
            color: #3498DB;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }

        .department-box small {
            display: block;
            color: #95A5A6;
            font-size: 11px;
            margin-bottom: 5px;
        }

        .department-box strong {
            color: #2C3E50;
            font-size: 18px;
        }

        /* =========================
           TASKS
        ========================= */

        .task {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 13px 0;
            border-bottom: 1px solid #EEF1F4;
        }

        .task:last-child {
            border-bottom: none;
        }

        .task-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: #FEF3E7;
            color: #F39C12;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 14px;
        }

        .task-content {
            flex: 1;
        }

        .task-content strong {
            display: block;
            color: #2C3E50;
            font-size: 13px;
            line-height: 1.5;
        }

        .task-content small {
            display: block;
            margin-top: 5px;
            color: #95A5A6;
            font-size: 11px;
        }

        .pending-badge {
            background: #FEF3E7;
            color: #F39C12;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
        }

        /* =========================
           COMPLETED
        ========================= */

        .completed-task {
            padding: 11px 0;
            border-bottom: 1px solid #EEF1F4;
            display: flex;
            gap: 10px;
        }

        .completed-task:last-child {
            border-bottom: none;
        }

        .check {
            color: #27AE60;
            font-size: 15px;
        }

        .completed-task span {
            font-size: 12px;
            color: #5D6D7E;
        }

        /* =========================
           REPORTS
        ========================= */

        .report-item {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 14px 0;
            border-bottom: 1px solid #EEF1F4;
        }

        .report-item:last-child {
            border-bottom: none;
        }

        .report-icon {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            background: #EAF4FB;
            color: #3498DB;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .report-info {
            flex: 1;
        }

        .report-info strong {
            display: block;
            color: #2C3E50;
            font-size: 13px;
        }

        .report-info small {
            display: block;
            color: #95A5A6;
            font-size: 11px;
            margin-top: 4px;
        }

        .submitted-badge {
            background: #EAF8F0;
            color: #27AE60;
            padding: 5px 9px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
        }

        /* =========================
           PROFILE
        ========================= */

        .profile-item {
            padding: 12px 0;
            border-bottom: 1px solid #EEF1F4;
        }

        .profile-item:last-child {
            border-bottom: none;
        }

        .profile-item label {
            display: block;
            font-size: 11px;
            color: #95A5A6;
            margin-bottom: 5px;
        }

        .profile-item strong {
            color: #2C3E50;
            font-size: 13px;
        }

        /* =========================
           EMPTY
        ========================= */

        .empty {
            text-align: center;
            padding: 25px 10px;
            color: #95A5A6;
            font-size: 13px;
        }

        /* =========================
           LOGOUT
        ========================= */

        .logout-form {
            margin-top: auto;
            padding-top: 20px;
        }

        .logout-btn {
            width: 100%;
            border: none;
            cursor: pointer;
            background: transparent;
            color: #BDC3C7;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 13px;
            border-radius: 8px;
            font-size: 14px;
            text-align: left;
        }

        .logout-btn:hover {
            background: #2C3E50;
            color: white;
        }

        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 1000px) {
            .sidebar {
                width: 210px;
            }

            .main {
                margin-left: 210px;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 700px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
            }

            .topbar {
                padding: 0 18px;
            }

            .content {
                padding: 18px;
            }

            .employee-user-info {
                display: none;
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <div class="brand">
            <div class="brand-icon">
                📊
            </div>

            <div class="brand-text">
                <strong>Reporting System</strong>
                <span>Employee Portal</span>
            </div>
        </div>

        <div class="menu-title">
            Main Menu
        </div>

        <a href="{{ route('employee.dashboard') }}" class="nav-link active">

            <svg class="nav-icon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2">

                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>

            </svg>

            Dashboard
        </a>

        <div class="menu-title">
            Reporting
        </div>

        <a href="{{ route('employee.daily-reports.create') }}" class="nav-link">

            <svg class="nav-icon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2">

                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="8" y1="13" x2="16" y2="13"></line>
                <line x1="8" y1="17" x2="14" y2="17"></line>

            </svg>

            Daily Report

        </a>

        <a href="{{ route('employee.tasks.index') }}" class="nav-link">

            <svg class="nav-icon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2">

                <path d="M9 11l3 3L22 4"></path>
                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>

            </svg>

            My Tasks

        </a>

        <div class="menu-title">
            Account
        </div>

        <a href="{{ route('employee.profile.index') }}" class="nav-link">

            <svg class="nav-icon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2">

                <path d="M20 21a8 8 0 0 0-16 0"></path>
                <circle cx="12" cy="7" r="4"></circle>

            </svg>

            My Profile

        </a>

        <div class="logout-form">

            <form method="POST" action="{{ route('employee.logout') }}">
                @csrf

                <button type="submit" class="logout-btn">

                    <svg class="nav-icon"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2">

                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                        <polyline points="16 17 21 12 16 7"></polyline>
                        <line x1="21" y1="12" x2="9" y2="12"></line>

                    </svg>

                    Logout

                </button>

            </form>

        </div>

    </aside>


    <!-- MAIN -->
    <main class="main">

        <!-- TOPBAR -->
        <header class="topbar">

            <div>
                <div class="topbar-title">
                    Employee Dashboard
                </div>

                <div class="topbar-subtitle">
                    Reporting System
                </div>
            </div>

            <div class="employee-user">

                <div class="avatar">

                    @if($employee->photo)

                        <img
                            src="{{ asset('storage/' . $employee->photo) }}"
                            alt="{{ $employee->name }}"
                        >

                    @else

                        {{ strtoupper(substr($employee->name, 0, 1)) }}

                    @endif

                </div>

                <div class="employee-user-info">

                    <strong>
                        {{ $employee->name }}
                    </strong>

                    <span>
                        {{ $employee->department->name ?? 'Employee' }}
                    </span>

                </div>

            </div>

        </header>


        <!-- CONTENT -->
        <section class="content">

            <!-- WELCOME -->
            <div class="welcome">

                <h1>
                    Welcome, {{ $employee->name }} 👋
                </h1>

                <p>
                    View your department, tasks and reporting information.
                </p>

            </div>


            <!-- STATS -->
            <div class="stats">

                <div class="stat-card">

                    <div class="stat-icon blue">
                        🏢
                    </div>

                    <div class="stat-info">

                        <span>
                            Department
                        </span>

                        <strong style="font-size:18px;">
                            {{ $employee->department->name ?? 'N/A' }}
                        </strong>

                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-icon orange">
                        ⏳
                    </div>

                    <div class="stat-info">

                        <span>
                            Pending Tasks
                        </span>

                        <strong>
                            {{ $pendingTasks->count() }}
                        </strong>

                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-icon green">
                        ✓
                    </div>

                    <div class="stat-info">

                        <span>
                            Completed Tasks
                        </span>

                        <strong>
                            {{ $completedTasks->count() }}
                        </strong>

                    </div>

                </div>

            </div>


            <!-- MAIN GRID -->
            <div class="dashboard-grid">

                <!-- LEFT -->
                <div>

                    <!-- DEPARTMENT -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                My Department
                            </h2>

                        </div>

                        <div class="card-body">

                            <div class="department-box">

                                <div class="department-icon">
                                    🏢
                                </div>

                                <div>

                                    <small>
                                        Assigned Department
                                    </small>

                                    <strong>
                                        {{ $employee->department->name ?? 'N/A' }}
                                    </strong>

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- PENDING TASKS -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                Pending Tasks
                            </h2>

                            <span>
                                {{ $pendingTasks->count() }} pending
                            </span>

                        </div>

                        <div class="card-body">

                            @forelse ($pendingTasks as $task)

                                <div class="task">

                                    <div class="task-icon">
                                        ⏳
                                    </div>

                                    <div class="task-content">

                                        <strong>
                                            {{ $task->task }}
                                        </strong>

                                        <small>
                                            Task Date:
                                            {{ $task->task_date->format('d/m/Y') }}

                                            @if($task->due_date)
                                                | Due:
                                                {{ $task->due_date->format('d/m/Y') }}
                                            @endif
                                        </small>

                                    </div>

                                    <span class="pending-badge">
                                        Pending
                                    </span>

                                </div>

                            @empty

                                <div class="empty">
                                    🎉 No pending tasks.
                                </div>

                            @endforelse

                        </div>

                    </div>


                    <!-- COMPLETED TASKS -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                Recently Completed Tasks
                            </h2>

                        </div>

                        <div class="card-body">

                            @forelse ($completedTasks as $task)

                                <div class="completed-task">

                                    <div class="check">
                                        ✓
                                    </div>

                                    <span>
                                        {{ $task->task }}
                                    </span>

                                </div>

                            @empty

                                <div class="empty">
                                    No completed tasks yet.
                                </div>

                            @endforelse

                        </div>

                    </div>


                    <!-- REPORTS -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                My Reports
                            </h2>

                            <span>
                                Recent Reports
                            </span>

                        </div>

                        <div class="card-body">

                            @forelse ($recentReports as $report)

                                <div class="report-item">

                                    <div class="report-icon">
                                        📄
                                    </div>

                                    <div class="report-info">

                                        <strong>
                                            Daily Report
                                        </strong>

                                        <small>
                                            Report Date:
                                            {{ $report->report_date->format('d/m/Y') }}
                                        </small>

                                    </div>

                                    <span class="submitted-badge">
                                        Submitted
                                    </span>

                                </div>

                            @empty

                                <div class="empty">
                                    No reports submitted yet.
                                </div>

                            @endforelse

                        </div>

                    </div>

                </div>


                <!-- RIGHT -->
                <div>

                    <!-- PROFILE -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                My Profile
                            </h2>

                        </div>

                        <div class="card-body">

                            <div class="profile-item">

                                <label>
                                    Employee Name
                                </label>

                                <strong>
                                    {{ $employee->name }}
                                </strong>

                            </div>


                            <div class="profile-item">

                                <label>
                                    Department
                                </label>

                                <strong>
                                    {{ $employee->department->name ?? 'N/A' }}
                                </strong>

                            </div>


                            <div class="profile-item">

                                <label>
                                    Report Section Head
                                </label>

                                <strong>
                                    {{ $employee->report_section_head ?? 'N/A' }}
                                </strong>

                            </div>


                            <div class="profile-item">

                                <label>
                                    Email
                                </label>

                                <strong>
                                    {{ $employee->email ?? 'N/A' }}
                                </strong>

                            </div>


                            <div class="profile-item">

                                <label>
                                    Cell Number
                                </label>

                                <strong>
                                    {{ $employee->cell_number ?? 'N/A' }}
                                </strong>

                            </div>

                        </div>

                    </div>


                    <!-- REPORT STATUS -->
                    <div class="card">

                        <div class="card-header">

                            <h2>
                                Report Status
                            </h2>

                        </div>

                        <div class="card-body">

                            @if ($todayReport)

                                <div class="empty" style="color:#27AE60;">
                                    ✓ Today's report has been submitted.
                                </div>

                            @else

                                <div class="empty" style="color:#F39C12;">
                                    ⚠ Today's report is not submitted yet.
                                </div>

                            @endif

                        </div>

                    </div>

                </div>

            </div>

        </section>

    </main>

</body>

</html>