<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Daily Report - Reporting System</title>

    <style>

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #1e293b;
        }

        .layout { min-height: 100vh; display: flex; }

        .sidebar {
            width: 250px;
            background: #0f172a;
            color: white;
            position: fixed;
            top: 0; bottom: 0; left: 0;
        }

        .brand { padding: 25px 22px; border-bottom: 1px solid rgba(255,255,255,.08); }
        .brand-title { font-size: 20px; font-weight: 700; }
        .brand-subtitle { color: #94a3b8; font-size: 12px; margin-top: 5px; }

        .nav { padding: 20px 14px; }
        .nav-label {
            color: #64748b; font-size: 11px; text-transform: uppercase;
            letter-spacing: 1px; padding: 0 12px; margin-bottom: 10px; font-weight: 700;
        }

        .nav-link {
            display: flex; gap: 12px; align-items: center; padding: 12px 13px;
            margin-bottom: 5px; color: #cbd5e1; text-decoration: none;
            border-radius: 8px; font-size: 14px;
        }

        .nav-link:hover, .nav-link.active { background: #1e293b; color: white; }

        .sidebar-bottom {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 18px 14px; border-top: 1px solid rgba(255,255,255,.08);
        }

        .logout {
            width: 100%; padding: 10px; background: transparent;
            border: 1px solid rgba(255,255,255,.1); border-radius: 7px;
            color: #cbd5e1; cursor: pointer;
        }

        .logout:hover { background: #1e293b; color: white; }

        .main { margin-left: 250px; width: calc(100% - 250px); }

        .topbar {
            height: 72px; background: white; border-bottom: 1px solid #e2e8f0;
            display: flex; align-items: center; padding: 0 32px;
        }

        .topbar-title { font-size: 18px; font-weight: 700; color: #0f172a; }

        .content { padding: 32px; max-width: 950px; }

        .page-header { margin-bottom: 25px; }
        .page-header h1 { font-size: 28px; margin-bottom: 5px; color: #2C3E50; font-weight: 700; }
        .page-header p { color: #5D6D7E; font-size: 14px; }

        .alert {
            padding: 13px 15px; border-radius: 8px; margin-bottom: 20px; font-size: 13px;
        }

        .error { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }

        .report-card {
            background: #FFFFFF;
            border: 1px solid #E1E5E8;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 22px;
        }

        .card-header {
            padding: 18px 24px;
            border-bottom: 1px solid #E5E7E9;
        }

        .card-header h3 { margin: 0; color: #2C3E50; font-size: 17px; }
        .card-header span { color: #5D6D7E; font-size: 13px; }

        .card-body { padding: 24px; }

        .form-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .info-box {
            background: #F8FAFC;
            border: 1px solid #D5DBDB;
            border-radius: 7px;
            padding: 12px 14px;
        }

        .info-box label {
            display: block;
            color: #7F8C8D;
            font-size: 11px;
            font-weight: 600;
            margin-bottom: 5px;
            text-transform: uppercase;
        }

        .info-box strong {
            color: #2C3E50;
            font-size: 14px;
        }

        /* PENDING TASKS */

        .pending-section {
            background: #F8FBFD;
            border: 1px solid #DCEAF3;
            border-radius: 9px;
            overflow: hidden;
        }

        .pending-header {
            padding: 15px 18px;
            border-bottom: 1px solid #DCEAF3;
            background: #F1F8FC;
        }

        .pending-header h3 {
            margin: 0;
            color: #2C3E50;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .pending-header p {
            margin: 5px 0 0 31px;
            color: #5D6D7E;
            font-size: 12px;
        }

        .task-icon {
            width: 23px; height: 23px; border-radius: 50%;
            background: #3498DB; color: #FFFFFF;
            display: inline-flex; align-items: center; justify-content: center;
            font-size: 13px;
        }

        .task-list { padding: 10px; }

        .pending-task {
            display: flex; align-items: center; gap: 13px;
            padding: 13px 12px; border-bottom: 1px solid #E8EEF2;
            cursor: pointer; transition: background 0.2s;
        }

        .pending-task:last-child { border-bottom: none; }
        .pending-task:hover { background: #FFFFFF; }

        .pending-task input { width: 18px; height: 18px; accent-color: #27AE60; }

        .task-content { flex: 1; }
        .task-title { color: #2C3E50; font-size: 14px; font-weight: 600; }
        .task-meta { color: #7F8C8D; font-size: 11px; margin-top: 3px; }

        .no-pending {
            padding: 14px 18px; color: #27AE60; background: #E8F8F0;
            font-size: 13px; font-weight: 600;
        }

        /* DEPARTMENT SECTION */

        .department-section {
            padding: 20px;
            border: 1px solid #E1E5E8;
            border-radius: 9px;
            background: #FFFFFF;
            margin-bottom: 18px;
        }

        .section-heading {
            display: flex; align-items: center; gap: 12px;
            margin-bottom: 18px; padding-bottom: 14px;
            border-bottom: 1px solid #E9ECEF;
        }

        .section-heading h3 { margin: 0; color: #2C3E50; font-size: 17px; }
        .section-heading p { margin: 4px 0 0; color: #7F8C8D; font-size: 12px; }

        .section-icon {
            width: 38px; height: 38px; border-radius: 8px;
            color: #FFFFFF; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 700; flex-shrink: 0;
        }

        .icon-finance { background: #8E44AD; }
        .icon-sales { background: #E67E22; }
        .icon-purchase { background: #16A085; }
        .icon-project { background: #2980B9; }
        .icon-hr { background: #C0392B; }
        .icon-misc { background: #7F8C8D; }
        .icon-tomorrow { background: #F39C12; }

        .form-group { margin-bottom: 18px; }
        .form-group:last-child { margin-bottom: 0; }

        .form-group label {
            display: block; color: #2C3E50; font-size: 14px;
            font-weight: 600; margin-bottom: 8px;
        }

        .form-group textarea {
            width: 100%; border: 1px solid #D5DADF; border-radius: 7px;
            padding: 11px 13px; font-size: 14px; color: #2C3E50;
            background: #FFFFFF; outline: none; font-family: inherit;
            resize: vertical; min-height: 100px;
        }

        .form-group textarea:focus {
            border-color: #3498DB; box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.10);
        }

        .field-help { margin-top: 7px; color: #7F8C8D; font-size: 12px; }

        .form-footer {
            display: flex; justify-content: flex-end; gap: 10px;
            padding: 18px 24px; border-top: 1px solid #E5E7E9; background: #FAFBFC;
        }

        .submit-btn {
            background: #0f172a; color: white; border: none; border-radius: 8px;
            padding: 12px 22px; font-size: 14px; font-weight: 600; cursor: pointer;
        }

        .submit-btn:hover { background: #1e293b; }

        @media (max-width: 850px) {

            .form-row { grid-template-columns: 1fr; }

            .sidebar { width: 70px; }
            .brand-title, .brand-subtitle, .nav-label,
            .nav-link span:not(.nav-icon) { display: none; }
            .main { margin-left: 70px; width: calc(100% - 70px); }
            .content { padding: 20px; }
        }

    </style>

</head>

<body>

<div class="layout">

    <aside class="sidebar">

        <div class="brand">
            <div class="brand-title">Reporting System</div>
            <div class="brand-subtitle">Employee Management</div>
        </div>

        <nav class="nav">

            <div class="nav-label">Employee Portal</div>

            <a href="{{ route('employee.dashboard') }}" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a href="{{ route('employee.daily-reports.create') }}" class="nav-link active">
                <span class="nav-icon">▤</span>
                <span>Daily Report</span>
            </a>

            <a href="{{ route('employee.tasks.index') }}" class="nav-link">
                <span class="nav-icon">☑</span>
                <span>My Tasks</span>
            </a>

            <div class="nav-label" style="margin-top: 20px;">Account</div>

            <a href="{{ route('employee.profile.index') }}" class="nav-link">
                <span class="nav-icon">👤</span>
                <span>My Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">
            <form method="POST" action="{{ route('employee.logout') }}">
                @csrf
                <button type="submit" class="logout">Logout</button>
            </form>
        </div>

    </aside>


    <main class="main">

        <header class="topbar">
            <div class="topbar-title">Submit Daily Report</div>
        </header>


        <section class="content">

            <div class="page-header">
                <h1>Daily Report</h1>
                <p>Submit your work progress and tasks for the next working day.</p>
            </div>


            @if ($errors->any())
                <div class="alert error">{{ $errors->first() }}</div>
            @endif

            @if (session('error'))
                <div class="alert error">{{ session('error') }}</div>
            @endif


            <form id="daily-report-form" method="POST" action="{{ route('employee.daily-reports.store') }}">

                @csrf

                <div class="report-card">

                    <div class="card-header">
                        <h3>Daily Report Information</h3>
                        <span>Enter your work details for today.</span>
                    </div>

                    <div class="card-body">

                        {{-- Employee / Department / Date --}}
                        <div class="form-row" style="margin-bottom: 22px;">

                            <div class="info-box">
                                <label>Employee Name</label>
                                <strong>{{ $employee->name }}</strong>
                            </div>

                            <div class="info-box">
                                <label>Department</label>
                                <strong>{{ $employee->department->name ?? 'N/A' }}</strong>
                            </div>

                            <div class="info-box">
                                <label>Report Date</label>
                                <strong>{{ $reportDate->format('d M Y') }}</strong>
                            </div>

                        </div>


                        {{-- Pending Tasks --}}
                        <div class="pending-section" style="margin-bottom: 22px;">

                            <div class="pending-header">

                                <h3>
                                    <span class="task-icon">✓</span>
                                    Pending Tasks
                                </h3>

                                <p>
                                    Tick the tasks that were completed today.
                                    Unticked tasks remain pending for the next report.
                                </p>

                            </div>

                            @if($pendingTasks->count() > 0)

                                <div class="task-list">

                                    @foreach($pendingTasks as $task)

                                        <label class="pending-task">

                                            <input
                                                type="checkbox"
                                                name="completed_task_ids[]"
                                                value="{{ $task->id }}"
                                            >

                                            <div class="task-content">

                                                <div class="task-title">
                                                    {{ $task->task }}
                                                </div>

                                                <div class="task-meta">
                                                    Task Date: {{ $task->task_date->format('d/m/Y') }}
                                                </div>

                                            </div>

                                        </label>

                                    @endforeach

                                </div>

                            @else

                                <div class="no-pending">
                                    ✓ No pending tasks from previous reports.
                                </div>

                            @endif

                        </div>


                        @php
                            $department = strtolower(trim($employee->department->name ?? ''));
                        @endphp


                        {{-- FINANCE --}}
                        @if ($department === 'finance')

                            <div class="department-section">

                                <div class="section-heading">
                                    <div class="section-icon icon-finance">$</div>
                                    <div>
                                        <h3>Accounts &amp; Finance</h3>
                                        <p>Accounts and financial activities for today.</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Accounts &amp; Finance</label>
                                    <textarea
                                        name="accounts_finance"
                                        placeholder="Enter today's Accounts & Finance work..."
                                    >{{ old('accounts_finance') }}</textarea>
                                </div>

                            </div>

                        @endif


                        {{-- SALES --}}
                        @if ($department === 'sales')

                            <div class="department-section">

                                <div class="section-heading">
                                    <div class="section-icon icon-sales">S</div>
                                    <div>
                                        <h3>Sales Activities</h3>
                                        <p>Enter today's sales-related activities.</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Inquiry &amp; Proposals</label>
                                    <textarea
                                        name="inquiries_proposals"
                                        placeholder="Enter inquiries, proposals or quotations..."
                                    >{{ old('inquiries_proposals') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Orders</label>
                                    <textarea
                                        name="orders"
                                        placeholder="Enter today's orders..."
                                    >{{ old('orders') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Follow-ups</label>
                                    <textarea
                                        name="follow_ups"
                                        placeholder="Enter today's follow-ups..."
                                    >{{ old('follow_ups') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Visits</label>
                                    <textarea
                                        name="visit"
                                        placeholder="Enter today's visit details..."
                                    >{{ old('visit') }}</textarea>
                                </div>

                            </div>

                        @endif


                        {{-- PURCHASE --}}
                        @if ($department === 'purchase')

                            <div class="department-section">

                                <div class="section-heading">
                                    <div class="section-icon icon-purchase">P</div>
                                    <div>
                                        <h3>Purchase Activities</h3>
                                        <p>Vendor, procurement and order-related activities.</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Inquiry &amp; Proposals</label>
                                    <textarea
                                        name="inquiries_proposals"
                                        placeholder="Enter inquiries, proposals or quotations..."
                                    >{{ old('inquiries_proposals') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Orders</label>
                                    <textarea
                                        name="orders"
                                        placeholder="Enter today's purchase orders..."
                                    >{{ old('orders') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Follow-ups</label>
                                    <textarea
                                        name="follow_ups"
                                        placeholder="Enter today's vendor follow-ups..."
                                    >{{ old('follow_ups') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Shipments</label>
                                    <textarea
                                        name="shipment"
                                        placeholder="Enter today's shipment details..."
                                    >{{ old('shipment') }}</textarea>
                                </div>

                            </div>

                        @endif


                        {{-- PROJECT-SLW --}}
                        @if ($department === 'project-slw')

                            <div class="department-section">

                                <div class="section-heading">
                                    <div class="section-icon icon-project">P</div>
                                    <div>
                                        <h3>Project Activities</h3>
                                        <p>Enter today's project progress and site visits.</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Projects</label>
                                    <textarea
                                        name="projects"
                                        placeholder="Enter today's project activities/progress..."
                                    >{{ old('projects') }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Visits</label>
                                    <textarea
                                        name="visit"
                                        placeholder="Enter today's visit details..."
                                    >{{ old('visit') }}</textarea>
                                </div>

                            </div>

                        @endif


                        {{-- HR --}}
                        @if ($department === 'hr')

                            <div class="department-section">

                                <div class="section-heading">
                                    <div class="section-icon icon-hr">H</div>
                                    <div>
                                        <h3>HR / Staff</h3>
                                        <p>Enter today's HR and staff-related activities.</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>HR / Staff</label>
                                    <textarea
                                        name="hr_staff"
                                        placeholder="Enter today's HR / Staff activities..."
                                    >{{ old('hr_staff') }}</textarea>
                                </div>

                            </div>

                        @endif


                        {{-- MISC --}}
                        <div class="department-section">

                            <div class="section-heading">
                                <div class="section-icon icon-misc">M</div>
                                <div>
                                    <h3>Miscellaneous</h3>
                                    <p>Any other information not covered above.</p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Misc</label>
                                <textarea
                                    name="misc"
                                    placeholder="Any other information (optional)..."
                                >{{ old('misc') }}</textarea>
                            </div>

                        </div>


                        {{-- TOMORROW'S TASKS --}}
                        <div class="department-section">

                            <div class="section-heading">
                                <div class="section-icon icon-tomorrow">T</div>
                                <div>
                                    <h3>Tomorrow's Tasks</h3>
                                    <p>Plan tasks for the next working day.</p>
                                </div>
                            </div>

                            <div class="form-group">
                                <textarea
                                    name="tomorrow_tasks"
                                    placeholder="Enter one task per line..."
                                >{{ old('tomorrow_tasks') }}</textarea>

                                <div class="field-help">
                                    💡 Enter each task on a separate line. These tasks
                                    will automatically appear as pending tasks on the next report.
                                </div>
                            </div>

                        </div>

                    </div>


                    <div class="form-footer">
                        <button type="submit" class="submit-btn">
                            ✓ Submit Daily Report
                        </button>
                    </div>

                </div>

            </form>

        </section>

    </main>

</div>

</body>

</html>