<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Reporting System</title>

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #1e293b;
        }

        .layout { min-height: 100vh; display: flex; }

        .sidebar {
            width: 250px;
            background: #0f172a;
            color: white;
            position: fixed;
            top: 0; bottom: 0; left: 0;
        }

        .brand { padding: 25px 22px; border-bottom: 1px solid rgba(255,255,255,.08); }
        .brand-title { font-size: 20px; font-weight: 700; }
        .brand-subtitle { color: #94a3b8; font-size: 12px; margin-top: 5px; }

        .nav { padding: 20px 14px; }
        .nav-label {
            color: #64748b; font-size: 11px; text-transform: uppercase;
            letter-spacing: 1px; padding: 0 12px; margin-bottom: 10px; font-weight: 700;
        }

        .nav-link {
            display: flex; gap: 12px; align-items: center; padding: 12px 13px;
            margin-bottom: 5px; color: #cbd5e1; text-decoration: none;
            border-radius: 8px; font-size: 14px;
        }

        .nav-link:hover, .nav-link.active { background: #1e293b; color: white; }

        .sidebar-bottom {
            position: absolute; bottom: 0; left: 0; right: 0;
            padding: 18px 14px; border-top: 1px solid rgba(255,255,255,.08);
        }

        .logout {
            width: 100%; padding: 10px; background: transparent;
            border: 1px solid rgba(255,255,255,.1); border-radius: 7px;
            color: #cbd5e1; cursor: pointer;
        }

        .logout:hover { background: #1e293b; color: white; }

        .main { margin-left: 250px; width: calc(100% - 250px); }

        .topbar {
            height: 72px; background: white; border-bottom: 1px solid #e2e8f0;
            display: flex; align-items: center; padding: 0 32px;
        }

        .topbar-title { font-size: 18px; font-weight: 700; color: #0f172a; }

        .content { padding: 32px; max-width: 900px; }

        .page-header { margin-bottom: 25px; }
        .page-header h1 { font-size: 25px; margin-bottom: 7px; }
        .page-header p { color: #64748b; font-size: 14px; }

        .alert {
            padding: 13px 15px; border-radius: 8px; margin-bottom: 20px; font-size: 13px;
        }

        .success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; }
        .error { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }

        .card {
            background: white; border: 1px solid #e2e8f0; border-radius: 12px;
            padding: 25px; margin-bottom: 22px; box-shadow: 0 2px 7px rgba(15,23,42,.03);
        }

        .card-title { font-size: 16px; font-weight: 700; margin-bottom: 5px; color: #0f172a; }
        .card-subtitle { color: #94a3b8; font-size: 12px; margin-bottom: 22px; }

        /* PHOTO */
        .photo-row {
            display: flex;
            align-items: center;
            gap: 22px;
        }

        .avatar-wrap {
            width: 92px;
            height: 92px;
            border-radius: 50%;
            overflow: hidden;
            flex-shrink: 0;
            border: 3px solid #e2e8f0;
        }

        .avatar-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .avatar-fallback {
            width: 100%;
            height: 100%;
            background: #3498DB;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 700;
        }

        .photo-actions { flex: 1; }

        .photo-name {
            font-size: 16px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 3px;
        }

        .photo-role {
            font-size: 12px;
            color: #94a3b8;
            margin-bottom: 14px;
        }

        .file-label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #0f172a;
            color: white;
            padding: 9px 16px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }

        .file-label:hover { background: #1e293b; }

        .file-label input[type="file"] {
            display: none;
        }

        .file-hint {
            font-size: 11px;
            color: #94a3b8;
            margin-top: 8px;
        }

        .upload-btn {
            margin-left: 10px;
            background: #3498DB;
            color: white;
            border: none;
            border-radius: 7px;
            padding: 9px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            display: none;
        }

        .upload-btn:hover { background: #2980B9; }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .info-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 15px;
            border-radius: 8px;
        }

        .info-label { color: #64748b; font-size: 11px; margin-bottom: 6px; }
        .info-value { color: #334155; font-size: 14px; font-weight: 600; }

        .form-group { margin-bottom: 18px; }

        label.field-label {
            display: block; color: #334155; font-size: 13px;
            font-weight: 600; margin-bottom: 8px;
        }

        input[type="password"] {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
            outline: none;
        }

        input[type="password"]:focus {
            border-color: #64748b;
            box-shadow: 0 0 0 3px rgba(100,116,139,.1);
        }

        .field-error {
            color: #b91c1c;
            font-size: 11px;
            margin-top: 6px;
        }

        .form-footer {
            display: flex;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .submit-btn {
            background: #0f172a; color: white; border: none;
            border-radius: 8px; padding: 13px 24px; font-size: 14px;
            font-weight: 600; cursor: pointer;
        }

        .submit-btn:hover { background: #1e293b; }

        @media (max-width: 850px) {
            .info-grid { grid-template-columns: 1fr; }
            .photo-row { flex-direction: column; align-items: flex-start; }
            .sidebar { width: 70px; }
            .brand-title, .brand-subtitle, .nav-label,
            .nav-link span:not(.nav-icon) { display: none; }
            .main { margin-left: 70px; width: calc(100% - 70px); }
            .content { padding: 20px; }
        }
    </style>
</head>

<body>

<div class="layout">

    <aside class="sidebar">

        <div class="brand">
            <div class="brand-title">Reporting System</div>
            <div class="brand-subtitle">Employee Management</div>
        </div>

        <nav class="nav">

            <div class="nav-label">Employee Portal</div>

            <a href="{{ route('employee.dashboard') }}" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a href="{{ route('employee.daily-reports.create') }}" class="nav-link">
                <span class="nav-icon">▤</span>
                <span>Daily Report</span>
            </a>

            <a href="{{ route('employee.tasks.index') }}" class="nav-link">
                <span class="nav-icon">☑</span>
                <span>My Tasks</span>
            </a>

            <div class="nav-label" style="margin-top: 20px;">Account</div>

            <a href="{{ route('employee.profile.index') }}" class="nav-link active">
                <span class="nav-icon">👤</span>
                <span>My Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">
            <form method="POST" action="{{ route('employee.logout') }}">
                @csrf
                <button type="submit" class="logout">Logout</button>
            </form>
        </div>

    </aside>


    <main class="main">

        <header class="topbar">
            <div class="topbar-title">My Profile</div>
        </header>

        <section class="content">

            <div class="page-header">
                <h1>My Profile</h1>
                <p>View your information, update your photo and password.</p>
            </div>

            @if (session('success'))
                <div class="alert success">
                    {{ session('success') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="alert error">
                    {{ $errors->first() }}
                </div>
            @endif


            <!-- PROFILE PHOTO -->
            <div class="card">

                <div class="card-title">Profile Photo</div>
                <div class="card-subtitle">A clear photo helps your team recognize you.</div>

                <form
                    method="POST"
                    action="{{ route('employee.profile.photo.update') }}"
                    enctype="multipart/form-data"
                    id="photo-form"
                >
                    @csrf

                    <div class="photo-row">

                        <div class="avatar-wrap">

                            @if ($employee->photo)

                                <img
                                    src="{{ asset('storage/' . $employee->photo) }}"
                                    alt="{{ $employee->name }}"
                                    class="avatar-img"
                                    id="photo-preview"
                                >

                            @else

                                <div class="avatar-fallback" id="photo-fallback">
                                    {{ strtoupper(substr($employee->name, 0, 1)) }}
                                </div>

                                <img
                                    src=""
                                    alt="{{ $employee->name }}"
                                    class="avatar-img"
                                    id="photo-preview"
                                    style="display:none;"
                                >

                            @endif

                        </div>

                        <div class="photo-actions">

                            <div class="photo-name">{{ $employee->name }}</div>
                            <div class="photo-role">{{ $employee->department->name ?? 'Employee' }}</div>

                            <label class="file-label">
                                📷 Choose Photo
                                <input
                                    type="file"
                                    name="photo"
                                    id="photo-input"
                                    accept="image/png, image/jpeg, image/jpg, image/webp"
                                    onchange="previewPhoto(event)"
                                >
                            </label>

                            <button type="submit" class="upload-btn" id="upload-btn">
                                Save Photo
                            </button>

                            <div class="file-hint">
                                JPG, PNG or WEBP. Max size 2MB.
                            </div>

                            @error('photo')
                                <div class="field-error">{{ $message }}</div>
                            @enderror

                        </div>

                    </div>

                </form>

            </div>


            <!-- PROFILE INFO -->
            <div class="card">

                <div class="card-title">Employee Information</div>
                <div class="card-subtitle">Your profile details.</div>

                <div class="info-grid">

                    <div class="info-box">
                        <div class="info-label">Employee Name</div>
                        <div class="info-value">{{ $employee->name }}</div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">Department</div>
                        <div class="info-value">{{ $employee->department->name ?? 'N/A' }}</div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">Report Section Head</div>
                        <div class="info-value">{{ $employee->report_section_head ?? 'N/A' }}</div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">Email</div>
                        <div class="info-value">{{ $employee->email ?? 'N/A' }}</div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">Cell Number</div>
                        <div class="info-value">{{ $employee->cell_number ?? 'N/A' }}</div>
                    </div>

                </div>

            </div>


            <!-- CHANGE PASSWORD -->
            <div class="card">

                <div class="card-title">Change Password</div>
                <div class="card-subtitle">Update your account password.</div>

                <form method="POST" action="{{ route('employee.profile.password.update') }}">

                    @csrf
                    @method('PUT')

                    <div class="form-group">
                        <label class="field-label">Current Password</label>
                        <input type="password" name="current_password" required>
                        @error('current_password')
                            <div class="field-error">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="field-label">New Password</label>
                        <input type="password" name="new_password" required minlength="6">
                        @error('new_password')
                            <div class="field-error">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="field-label">Confirm New Password</label>
                        <input type="password" name="new_password_confirmation" required minlength="6">
                    </div>

                    <div class="form-footer">
                        <button type="submit" class="submit-btn">Update Password</button>
                    </div>

                </form>

            </div>

        </section>

    </main>

</div>


<script>

    function previewPhoto(event) {

        const file = event.target.files[0];

        if (!file) {
            return;
        }

        const preview = document.getElementById('photo-preview');
        const fallback = document.getElementById('photo-fallback');
        const uploadBtn = document.getElementById('upload-btn');

        const reader = new FileReader();

        reader.onload = function (e) {

            preview.src = e.target.result;
            preview.style.display = 'block';

            if (fallback) {
                fallback.style.display = 'none';
            }

            uploadBtn.style.display = 'inline-block';
        };

        reader.readAsDataURL(file);
    }

</script>

</body>

</html>