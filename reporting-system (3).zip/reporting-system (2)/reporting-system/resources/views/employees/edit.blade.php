@extends('layouts.app')

@section('content')

<div class="page-header">
    <div>
        <h1>Edit Employee</h1>
        <p>Update employee information.</p>
    </div>

    <a href="{{ route('employees.index') }}" class="btn btn-secondary">
        ← Back to Employees
    </a>
</div>

@if($errors->any())
    <div class="alert alert-danger">
        <strong>Please fix the following errors:</strong>
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="form-card">

    <form action="{{ route('employees.update', $employee->id) }}" method="POST">

        @csrf
        @method('PUT')

        <div class="section-title">
            <div class="section-icon">
                <svg width="20" height="20" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 20h9"></path>
                    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"></path>
                </svg>
            </div>

            <div>
                <h3>Employee Information</h3>
                <p>Update the employee's profile information.</p>
            </div>
        </div>

        <div class="form-grid">

            <!-- Name -->
            <div class="form-group">
                <label>
                    Employee Name <span>*</span>
                </label>

                <input
                    type="text"
                    name="name"
                    value="{{ old('name', $employee->name) }}"
                    required
                >
            </div>

            <!-- Department -->
            <div class="form-group">
                <label>
                    Department <span>*</span>
                </label>

                <select name="department_id" required>

                    <option value="">Select Department</option>

                    @foreach($departments as $department)

                        <option
                            value="{{ $department->id }}"
                            {{ old('department_id', $employee->department_id) == $department->id ? 'selected' : '' }}
                        >
                            {{ $department->name }}
                        </option>

                    @endforeach

                </select>
            </div>

            <!-- Report Section Head -->
            <div class="form-group">
                <label>
                    Report Section Head <span>*</span>
                </label>

                <input
                    type="text"
                    name="report_section_head"
                    value="{{ old('report_section_head', $employee->report_section_head) }}"
                    required
                >
            </div>

            <!-- Email -->
            <div class="form-group">
                <label>
                    Email Address <span>*</span>
                </label>

                <input
                    type="email"
                    name="email"
                    value="{{ old('email', $employee->email) }}"
                    required
                >
            </div>

            <!-- Cell -->
            <div class="form-group">
                <label>
                    Cell Number <span>*</span>
                </label>

                <input
                    type="text"
                    name="cell_number"
                    value="{{ old('cell_number', $employee->cell_number) }}"
                    required
                >
            </div>

            <!-- Password -->
            <div class="form-group">
                <label>
                    New Password
                </label>

                <input
                    type="password"
                    name="password"
                    placeholder="Leave blank to keep current password"
                >

                <small>
                    Leave blank if you don't want to change the password.
                </small>
            </div>

        </div>

        <div class="form-footer">

            <a href="{{ route('employees.index') }}"
               class="btn btn-secondary">
                Cancel
            </a>

            <button type="submit" class="btn btn-primary">

                <svg width="18" height="18" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                    <polyline points="17 21 17 13 7 13 7 21"/>
                    <polyline points="7 3 7 8 15 8"/>
                </svg>

                Update Employee
            </button>

        </div>

    </form>

</div>

<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.page-header h1 {
    margin: 0 0 6px;
    color: #2C3E50;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #5D6D7E;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 11px 18px;
    border-radius: 7px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
}

.btn-primary {
    background: #3498DB;
    color: white;
}

.btn-secondary {
    background: #ECF0F1;
    color: #2C3E50;
}

.form-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    padding: 28px;
}

.section-title {
    display: flex;
    align-items: center;
    gap: 12px;
    padding-bottom: 20px;
    margin-bottom: 25px;
    border-bottom: 1px solid #EAECEE;
}

.section-icon {
    width: 42px;
    height: 42px;
    border-radius: 8px;
    background: #EBF5FB;
    color: #3498DB;
    display: flex;
    align-items: center;
    justify-content: center;
}

.section-title h3 {
    margin: 0 0 4px;
    color: #2C3E50;
}

.section-title p {
    margin: 0;
    color: #5D6D7E;
    font-size: 13px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 22px;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group label {
    color: #2C3E50;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
}

.form-group label span {
    color: #E74C3C;
}

.form-group input,
.form-group select {
    width: 100%;
    box-sizing: border-box;
    padding: 12px 13px;
    border: 1px solid #D5DBDB;
    border-radius: 7px;
    color: #2C3E50;
    background: white;
    font-size: 14px;
    outline: none;
}

.form-group input:focus,
.form-group select:focus {
    border-color: #3498DB;
    box-shadow: 0 0 0 3px rgba(52,152,219,0.10);
}

.form-group small {
    margin-top: 6px;
    color: #7F8C8D;
    font-size: 12px;
}

.form-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #EAECEE;
}

.alert-danger {
    background: #FDEDEC;
    color: #E74C3C;
    padding: 14px 18px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.alert-danger ul {
    margin: 8px 0 0 20px;
}

@media (max-width: 768px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-card {
        padding: 20px;
    }

    .form-footer {
        flex-direction: column-reverse;
    }

    .form-footer .btn {
        width: 100%;
    }
}

</style>

@endsection