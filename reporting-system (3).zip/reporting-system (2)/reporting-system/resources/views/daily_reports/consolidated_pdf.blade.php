<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daily Report {{ $reportDate->format('d-m-Y') }}</title>

    <style>
        @page { margin: 30px 45px; }

        body {
            font-family: DejaVu Sans, Arial, sans-serif;
            font-size: 11px;
            color: #111;
        }

        .header { margin-bottom: 14px; }
        .header table { width: 100%; border-collapse: collapse; }
        .logo img { height: 55px; }
        .company-name { font-size: 20px; font-weight: bold; color: #a3141b; }
        .company-tag { font-size: 9px; color: #1f3a6e; }

        .title {
            text-align: center;
            font-size: 13px;
            font-weight: bold;
            text-decoration: underline;
            margin: 14px 0 22px;
        }

        /* ===== EMPLOYEE CARD ===== */

        .employee-card {
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 14px;
            page-break-inside: avoid;
        }

        .employee-card-header {
            background: #1f3a6e;
            color: #fff;
            padding: 8.5px 10px;
        }

        .employee-name {
            font-size: 12px;
            font-weight: bold;
        }

        .employee-dept {
            font-size: 9px;
            color: #dbe3f0;
        }

        .employee-card-body {
            padding: 8px 10px;
        }

        .field-row {
            margin-bottom: 7px;
        }

        .field-label {
            font-size: 10px;
            font-weight: bold;
            text-decoration: underline;
        }

        .field-value {
            font-size: 10px;
            line-height: 1.5;
            margin-top: 2px;
        }

        .not-submitted {
            color: #b91c1c;
            font-style: italic;
            font-size: 10px;
        }

        /* ===== TASKS ===== */

        .tasks-wrapper {
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px dashed #ccc;
        }

        .tasks-title {
            font-size: 10px;
            font-weight: bold;
            margin-bottom: 4px;
        }

        .task-counts {
            font-size: 9px;
            color: #444;
            margin-bottom: 5px;
        }

        .count-pill {
            display: inline-block;
            padding: 1px 7px;
            border-radius: 3px;
            font-weight: bold;
            margin-right: 6px;
        }

        .count-pending { color: #b35c00; background: #fdf1e4; }
        .count-submitted { color: #1e5fa8; background: #e9f1fb; }
        .count-completed { color: #1a7a3c; background: #e9f7ee; }

        .task-list { margin: 0; }

        .task-item {
            font-size: 9.5px;
            margin: 2px 0 2px 10px;
        }

        .task-item .label {
            font-weight: bold;
        }

        .task-item.pending .label { color: #b35c00; }
        .task-item.submitted .label { color: #1e5fa8; }
        .task-item.completed .label { color: #1a7a3c; }

        .task-date {
            color: #777;
            font-size: 8.5px;
        }

        .no-tasks {
            font-size: 9.5px;
            color: #999;
            font-style: italic;
        }
    </style>
</head>
<body>

@php
    $sections = [
        'accounts_finance'    => 'Accounts & Finance',
        'inquiries_proposals' => 'Inquiry & Proposals',
        'orders'              => 'Orders',
        'shipment'            => 'Shipments',
        'visit'               => 'Visits',
        'projects'            => 'Projects',
        'follow_ups'          => 'Follow-ups',
        'hr_staff'            => 'HR / Staff',
        'misc'                => 'Misc',
    ];

    // Flatten: one entry per employee with their report, department & tasks
    $rows = [];
    foreach ($departmentBoxes as $deptName => $box) {
        foreach ($box['employees'] as $row) {
            $rows[] = [
                'employee'   => $row['employee'],
                'report'     => $row['report'],
                'department' => $deptName,
                'fieldKeys'  => collect($box['fields'])->pluck('key')->all(),
                'pending'    => $row['pending']   ?? collect(),
                'submitted'  => $row['submitted'] ?? collect(),
                'completed'  => $row['completed'] ?? collect(),
            ];
        }
    }

  $logoPath = public_path('images/logo.jpg');
    $logoData = file_exists($logoPath)
        ? 'data:image/jpeg;base64,' . base64_encode(file_get_contents($logoPath))
        : null;
@endphp

<div class="header">
    <table>
        <tr>
            <td class="logo">
                @if($logoData)
                    <img src="{{ $logoData }}" alt="Star Automation">
                @else
                    <div class="company-name">STAR AUTOMATION</div>
                    <div class="company-tag">Your Partner in Production Efficiency</div>
                @endif
            </td>
        </tr>
    </table>
</div>

<div class="title">Daily Report Dated: {{ $reportDate->format('d/m/y') }}</div>


@foreach($rows as $row)

    <div class="employee-card">

        <div class="employee-card-header">
            <span class="employee-name">{{ $row['employee']->name }}</span>
            <span class="employee-dept"> — {{ $row['department'] }}</span>
        </div>

        <div class="employee-card-body">

            {{-- Report fields relevant to this employee's department --}}
            @php $hasAnyField = false; @endphp

            @foreach($sections as $key => $label)

                @php
                    $applies = $key === 'misc' || in_array($key, $row['fieldKeys']);
                    $text = $row['report']->{$key} ?? null;
                @endphp

                @if($applies)

                    @php $hasAnyField = true; @endphp

                    <div class="field-row">
                        <div class="field-label">{{ $label }}</div>

                        @if($row['report'] && filled($text))
                            <div class="field-value">{!! nl2br(e($text)) !!}</div>
                        @else
                            <div class="not-submitted">Not Submitted</div>
                        @endif
                    </div>

                @endif

            @endforeach

            @if(!$hasAnyField)
                <div class="not-submitted">Not Submitted</div>
            @endif


            {{-- Tasks --}}
            <div class="tasks-wrapper">

                <div class="tasks-title">Tasks</div>

                <div class="task-counts">
                    <span class="count-pill count-pending">Pending: {{ $row['pending']->count() }}</span>
                    <span class="count-pill count-submitted">Awaiting Approval: {{ $row['submitted']->count() }}</span>
                    <span class="count-pill count-completed">Completed: {{ $row['completed']->count() }}</span>
                </div>

                @php
                    $totalTasks = $row['pending']->count() + $row['submitted']->count() + $row['completed']->count();
                @endphp

                @if($totalTasks === 0)

                    <div class="no-tasks">No tasks assigned.</div>

                @else

                    <div class="task-list">

                        @foreach($row['pending'] as $task)
                            <div class="task-item pending">
                                <span class="label">Pending:</span>
                                {{ $task->task }}
                                <span class="task-date">({{ \Carbon\Carbon::parse($task->task_date)->format('d/m/y') }})</span>
                            </div>
                        @endforeach

                        @foreach($row['submitted'] as $task)
                            <div class="task-item submitted">
                                <span class="label">Awaiting Approval:</span>
                                {{ $task->task }}
                                <span class="task-date">({{ \Carbon\Carbon::parse($task->task_date)->format('d/m/y') }})</span>
                            </div>
                        @endforeach

                        @foreach($row['completed'] as $task)
                            <div class="task-item completed">
                                <span class="label">Completed:</span>
                                {{ $task->task }}
                                <span class="task-date">({{ \Carbon\Carbon::parse($task->task_date)->format('d/m/y') }})</span>
                            </div>
                        @endforeach

                    </div>

                @endif

            </div>

        </div>

    </div>

@endforeach

</body>
</html>