@extends('layouts.app')

@section('content')

<div class="page-header">
    <div>
        <h1>Create Daily Report</h1>
        <p>Submit today's employee daily report.</p>
    </div>

    <a href="{{ route('daily-reports.index') }}" class="back-btn">
        ← Back to Reports
    </a>
</div>


@if ($errors->any())
    <div class="error-alert">
        <strong>Please fix the following errors:</strong>

        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif


<form action="{{ route('daily-reports.store') }}" method="POST">
    @csrf

    <div class="report-card">

        <div class="card-header">
            <div>
                <h3>Daily Report Information</h3>
            </div>

            <span>
                Enter the employee's work details for today.
            </span>
        </div>


        <div class="card-body">

            {{-- Employee + Date --}}
            <div class="form-row">

                <div class="form-group">
                    <label>
                        Employee <span>*</span>
                    </label>

                    <select
                        name="employee_id"
                        id="employee_id"
                        onchange="loadEmployeeTasks()"
                        required
                    >
                        <option value="">Select Employee</option>

                        @foreach ($employees as $employee)
                            <option
                                value="{{ $employee->id }}"
                                {{ request('employee_id') == $employee->id ? 'selected' : '' }}
                            >
                                {{ $employee->name }}
                                @if($employee->department)
                                    - {{ $employee->department->name }}
                                @endif
                            </option>
                        @endforeach

                    </select>
                </div>


                <div class="form-group">
                    <label>
                        Report Date <span>*</span>
                    </label>

                    <input
                        type="date"
                        name="report_date"
                        id="report_date"
                        value="{{ old('report_date', $reportDate ?? now()->toDateString()) }}"
                        onchange="loadEmployeeTasks()"
                        required
                    >
                </div>

            </div>


            {{-- Pending Tasks --}}
            @if($selectedEmployee)

                <div class="pending-section">

                    <div class="pending-header">
                        <div>
                            <h3>
                                <span class="task-icon">✓</span>
                                Pending Tasks
                            </h3>

                            <p>
                                Tick the tasks that were completed today.
                                Unticked tasks will remain pending for the next report.
                            </p>
                        </div>
                    </div>


                    @if($pendingTasks->count() > 0)

                        <div class="task-list">

                            @foreach($pendingTasks as $task)

                                <label class="pending-task">

                                    <div class="task-checkbox">
                                        <input
                                            type="checkbox"
                                            name="completed_task_ids[]"
                                            value="{{ $task->id }}"
                                        >

                                        <span class="custom-checkbox"></span>
                                    </div>


                                    <div class="task-content">

                                        <div class="task-title">
                                            {{ $task->task }}
                                        </div>

                                        <div class="task-meta">

                                            <span>
                                                Task Date:
                                                {{ $task->task_date->format('d/m/Y') }}
                                            </span>

                                            @if($task->due_date)
                                                <span>
                                                    Due:
                                                    {{ $task->due_date->format('d/m/Y') }}
                                                </span>
                                            @endif

                                        </div>

                                    </div>

                                </label>

                            @endforeach

                        </div>

                    @else

                        <div class="no-pending">
                            ✓ No pending tasks for this employee.
                        </div>

                    @endif

                </div>

            @endif


            {{-- Accounts / Finance --}}
            <div class="form-group">
                <label>Accounts / Finance</label>

                <textarea
                    name="accounts_finance"
                    rows="4"
                    placeholder="Enter Accounts / Finance activities..."
                >{{ old('accounts_finance') }}</textarea>
            </div>


            {{-- Inquiries / Proposals --}}
            <div class="form-group">
                <label>Inquiries / Proposals</label>

                <textarea
                    name="inquiries_proposals"
                    rows="4"
                    placeholder="Enter inquiries, proposals or quotations..."
                >{{ old('inquiries_proposals') }}</textarea>
            </div>


            {{-- Orders --}}
            <div class="form-group">
                <label>Orders</label>

                <textarea
                    name="orders"
                    rows="4"
                    placeholder="Enter today's orders..."
                >{{ old('orders') }}</textarea>
            </div>


            {{-- Follow Ups --}}
            <div class="form-group">
                <label>Follow-ups</label>

                <textarea
                    name="follow_ups"
                    rows="4"
                    placeholder="Enter today's follow-ups..."
                >{{ old('follow_ups') }}</textarea>
            </div>


            {{-- Shipment --}}
            <div class="form-group">
                <label>Shipment</label>

                <textarea
                    name="shipment"
                    rows="4"
                    placeholder="Enter shipment activities..."
                >{{ old('shipment') }}</textarea>
            </div>


            {{-- Projects --}}
            <div class="form-group">
                <label>Projects</label>

                <textarea
                    name="projects"
                    rows="4"
                    placeholder="Enter project activities..."
                >{{ old('projects') }}</textarea>
            </div>


            {{-- Visit --}}
            <div class="form-group">
                <label>Visit</label>

                <textarea
                    name="visit"
                    rows="4"
                    placeholder="Enter today's visits..."
                >{{ old('visit') }}</textarea>
            </div>


            {{-- Tomorrow Tasks --}}
            <div class="form-group tomorrow-group">

                <label>
                    Tomorrow's Tasks
                </label>

                <textarea
                    name="tomorrow_tasks"
                    rows="5"
                    placeholder="Enter tomorrow's tasks, one task per line..."
                >{{ old('tomorrow_tasks') }}</textarea>

                <div class="field-help">
                    💡 Enter each task on a separate line. These tasks will automatically
                    appear as pending tasks in the next day's report.
                </div>

            </div>

        </div>


        {{-- Footer --}}
        <div class="form-footer">

            <a
                href="{{ route('daily-reports.index') }}"
                class="cancel-btn"
            >
                Cancel
            </a>

            <button
                type="submit"
                class="save-btn"
            >
                ✓ Save Daily Report
            </button>

        </div>

    </div>

</form>


<style>

    * {
        box-sizing: border-box;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .page-header h1 {
        margin: 0;
        color: #2C3E50;
        font-size: 30px;
        font-weight: 700;
    }

    .page-header p {
        margin: 5px 0 0;
        color: #5D6D7E;
        font-size: 15px;
    }

    .back-btn {
        text-decoration: none;
        background: #E9ECEF;
        color: #2C3E50;
        padding: 11px 18px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
    }

    .back-btn:hover {
        background: #DDE2E6;
    }


    /* Error */
    .error-alert {
        background: #FDEDEC;
        color: #C0392B;
        border: 1px solid #F5B7B1;
        border-radius: 8px;
        padding: 14px 18px;
        margin-bottom: 20px;
    }

    .error-alert ul {
        margin: 8px 0 0 20px;
    }


    /* Card */
    .report-card {
        background: #FFFFFF;
        border: 1px solid #E1E5E8;
        border-radius: 10px;
        overflow: hidden;
    }

    .card-header {
        padding: 18px 24px;
        border-bottom: 1px solid #E5E7E9;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .card-header h3 {
        margin: 0;
        color: #2C3E50;
        font-size: 17px;
    }

    .card-header span {
        color: #5D6D7E;
        font-size: 13px;
    }

    .card-body {
        padding: 24px;
    }


    /* Form */
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 22px;
    }

    .form-group label {
        display: block;
        color: #2C3E50;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .form-group label span {
        color: #E74C3C;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        border: 1px solid #D5DADF;
        border-radius: 7px;
        padding: 11px 13px;
        font-size: 14px;
        color: #2C3E50;
        background: #FFFFFF;
        outline: none;
        font-family: inherit;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
        border-color: #3498DB;
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.10);
    }

    .form-group textarea {
        resize: vertical;
        min-height: 90px;
    }


    /* Pending Tasks */
    .pending-section {
        background: #F8FBFD;
        border: 1px solid #DCEAF3;
        border-radius: 9px;
        margin-bottom: 25px;
        overflow: hidden;
    }

    .pending-header {
        padding: 15px 18px;
        border-bottom: 1px solid #DCEAF3;
        background: #F1F8FC;
    }

    .pending-header h3 {
        margin: 0;
        color: #2C3E50;
        font-size: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .pending-header p {
        margin: 5px 0 0 27px;
        color: #5D6D7E;
        font-size: 12px;
    }

    .task-icon {
        width: 23px;
        height: 23px;
        border-radius: 50%;
        background: #3498DB;
        color: #FFFFFF;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
    }

    .task-list {
        padding: 10px;
    }

    .pending-task {
        display: flex;
        align-items: center;
        gap: 13px;
        padding: 13px 12px;
        border-bottom: 1px solid #E8EEF2;
        cursor: pointer;
        transition: background 0.2s;
    }

    .pending-task:last-child {
        border-bottom: none;
    }

    .pending-task:hover {
        background: #FFFFFF;
    }

    .task-checkbox {
        position: relative;
        width: 22px;
        height: 22px;
        flex-shrink: 0;
    }

    .task-checkbox input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }

    .custom-checkbox {
        position: absolute;
        width: 22px;
        height: 22px;
        border: 2px solid #3498DB;
        border-radius: 5px;
        background: #FFFFFF;
    }

    .task-checkbox input:checked + .custom-checkbox {
        background: #27AE60;
        border-color: #27AE60;
    }

    .task-checkbox input:checked + .custom-checkbox::after {
        content: "✓";
        color: #FFFFFF;
        font-size: 14px;
        font-weight: bold;
        position: absolute;
        left: 3px;
        top: -1px;
    }

    .task-content {
        flex: 1;
    }

    .task-title {
        color: #2C3E50;
        font-size: 14px;
        font-weight: 600;
    }

    .task-meta {
        display: flex;
        gap: 15px;
        margin-top: 4px;
        color: #7F8C8D;
        font-size: 11px;
    }

    .no-pending {
        padding: 14px 18px;
        color: #27AE60;
        background: #E8F8F0;
        font-size: 13px;
        font-weight: 600;
    }


    /* Tomorrow */
    .tomorrow-group {
        margin-top: 8px;
    }

    .field-help {
        margin-top: 7px;
        color: #7F8C8D;
        font-size: 12px;
    }


    /* Footer */
    .form-footer {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        padding: 18px 24px;
        border-top: 1px solid #E5E7E9;
        background: #FAFBFC;
    }

    .cancel-btn,
    .save-btn {
        border: none;
        border-radius: 7px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
    }

    .cancel-btn {
        background: #E9ECEF;
        color: #2C3E50;
    }

    .save-btn {
        background: #3498DB;
        color: #FFFFFF;
    }

    .save-btn:hover {
        background: #2980B9;
    }


    /* Responsive */
    @media (max-width: 768px) {

        .page-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }

        .form-row {
            grid-template-columns: 1fr;
            gap: 0;
        }

        .card-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 6px;
        }

        .card-body {
            padding: 16px;
        }

        .form-footer {
            padding: 15px;
        }
    }

</style>


<script>

    function loadEmployeeTasks() {

        const employeeId = document.getElementById('employee_id').value;
        const reportDate = document.getElementById('report_date').value;

        if (!employeeId) {

            window.location.href =
                "{{ route('daily-reports.create') }}";

            return;
        }

        window.location.href =
            "{{ route('daily-reports.create') }}" +
            "?employee_id=" +
            employeeId +
            "&report_date=" +
            reportDate;
    }

</script>

@endsection