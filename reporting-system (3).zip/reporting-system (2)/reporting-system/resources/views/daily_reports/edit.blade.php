@extends('layouts.app')

@section('content')

<div class="page-header">

    <div>
        <h1>Edit Daily Report</h1>
        <p>Update employee daily report.</p>
    </div>

    <a href="{{ route('daily-reports.index') }}" class="btn btn-secondary">
        ← Back to Reports
    </a>

</div>


@if($errors->any())

    <div class="alert alert-danger">

        <strong>Please fix the following errors:</strong>

        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>

    </div>

@endif


<div class="card">

    <div class="card-header">

        <div>
            <h3>Edit Report</h3>
            <p>Update the information below.</p>
        </div>

    </div>


    <form
        action="{{ route('daily-reports.update', $dailyReport->id) }}"
        method="POST"
    >

        @csrf
        @method('PUT')


        <div class="form-body">

            <!-- Employee -->

            <div class="form-group">

                <label for="employee_id">
                    Employee <span>*</span>
                </label>

                <select
                    name="employee_id"
                    id="employee_id"
                    required
                >

                    <option value="">
                        Select Employee
                    </option>

                    @foreach($employees as $employee)

                        <option
                            value="{{ $employee->id }}"
                            {{ old('employee_id', $dailyReport->employee_id) == $employee->id ? 'selected' : '' }}
                        >

                            {{ $employee->name }}

                            @if($employee->department)
                                — {{ $employee->department->name }}
                            @endif

                        </option>

                    @endforeach

                </select>

            </div>


            <!-- Report Date -->

            <div class="form-group">

                <label for="report_date">
                    Report Date <span>*</span>
                </label>

                <input
                    type="date"
                    name="report_date"
                    id="report_date"
                    value="{{ old('report_date', $dailyReport->report_date->format('Y-m-d')) }}"
                    required
                >

            </div>


            <!-- Report Content -->

            <div class="form-group">

                <label for="report_content">
                    {{ $dailyReport->employee->department->name ?? 'Work Report' }}
                    <span>*</span>
                </label>

                <textarea
                    name="report_content"
                    id="report_content"
                    rows="6"
                    placeholder="Enter today's work details..."
                    required
                >{{ old('report_content', $dailyReport->report_content) }}</textarea>

            </div>


            <!-- Tomorrow's Tasks -->

            <div class="form-group">

                <label for="tomorrow_tasks">
                    Tomorrow's Tasks
                </label>

                <textarea
                    name="tomorrow_tasks"
                    id="tomorrow_tasks"
                    rows="4"
                    placeholder="Enter tomorrow's planned tasks..."
                >{{ old('tomorrow_tasks', $dailyReport->tomorrow_tasks) }}</textarea>

            </div>

        </div>


        <!-- Form Footer -->

        <div class="form-footer">

            
                <a href="{{ route('daily-reports.index') }}"
                class="btn btn-secondary"
            >
                Cancel
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Daily Report
            </button>

        </div>

    </form>

</div>


<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.page-header h1 {
    margin: 0 0 6px;
    color: #2C3E50;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #5D6D7E;
}

.card {
    background: white;
    border-radius: 10px;
    border: 1px solid #E5E9ED;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}

.card-header {
    padding: 20px 24px;
    border-bottom: 1px solid #EAECEE;
}

.card-header h3 {
    margin: 0 0 5px;
    color: #2C3E50;
    font-size: 17px;
}

.card-header p {
    margin: 0;
    color: #8493A0;
    font-size: 12px;
}

.form-body {
    padding: 24px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 7px;
    color: #2C3E50;
    font-size: 13px;
    font-weight: 600;
}

.form-group label span {
    color: #E74C3C;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    border: 1px solid #D5DBDF;
    border-radius: 7px;
    padding: 11px 13px;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 13px;
    color: #2C3E50;
    background: white;
    outline: none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #3498DB;
    box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.10);
}

.form-group textarea {
    resize: vertical;
    min-height: 90px;
    line-height: 1.5;
}

.form-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 18px 24px;
    border-top: 1px solid #EAECEE;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 10px 16px;
    border-radius: 7px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.btn-primary {
    background: #3498DB;
    color: white;
}

.btn-secondary {
    background: #ECF0F1;
    color: #2C3E50;
}

.btn:hover {
    opacity: 0.85;
}

.alert {
    padding: 14px 18px;
    margin-bottom: 20px;
    border-radius: 7px;
    font-size: 13px;
}

.alert-danger {
    background: #FDEDEC;
    color: #C0392B;
    border: 1px solid #F5B7B1;
}

.alert-danger ul {
    margin: 8px 0 0 20px;
}

@media (max-width: 768px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .form-footer {
        justify-content: flex-start;
        flex-wrap: wrap;
    }

}

</style>

@endsection