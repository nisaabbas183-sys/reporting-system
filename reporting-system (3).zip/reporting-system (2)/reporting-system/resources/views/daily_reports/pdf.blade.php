<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <title>Daily Employee Report</title>

    <style>
        @page {
            size: A4 portrait;
            margin: 18px 25px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            color: #2C3E50;
            font-size: 9px;
            line-height: 1.25;
            margin: 0;
            padding: 0;
        }

        /* =========================
           HEADER
        ========================== */

        .header {
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 7px;
            margin-bottom: 10px;
        }

        .company-name {
            font-size: 17px;
            font-weight: bold;
            color: #2C3E50;
        }

        .report-title {
            font-size: 12px;
            font-weight: bold;
            margin-top: 2px;
            color: #3498DB;
        }

        .report-date {
            margin-top: 2px;
            color: #5D6D7E;
            font-size: 8.5px;
        }

        /* =========================
           EMPLOYEE INFORMATION
        ========================== */

        .employee-box {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 9px;
        }

        .employee-box td {
            border: 1px solid #D9E0E6;
            padding: 5px 7px;
            vertical-align: middle;
        }

        .label {
            background: #F4F6F8;
            font-weight: bold;
            width: 16%;
            color: #2C3E50;
            white-space: nowrap;
        }

        /* =========================
           REPORT SECTIONS
        ========================== */

        .section {
            margin-top: 7px;
            page-break-inside: avoid;
        }

        .section-title {
            background: #2C3E50;
            color: white;
            padding: 5px 7px;
            font-size: 9.5px;
            font-weight: bold;
        }

        .section-content {
            border: 1px solid #D9E0E6;
            border-top: none;
            padding: 5px 7px;
            min-height: 17px;
            color: #5D6D7E;
            white-space: pre-line;
        }

        .empty {
            color: #AAB4BC;
            font-style: italic;
        }

        /* =========================
           FOOTER
        ========================== */

        .footer {
            margin-top: 10px;
            padding-top: 5px;
            border-top: 1px solid #D9E0E6;
            text-align: center;
            font-size: 7.5px;
            color: #8493A0;
        }

    </style>
</head>

<body>

    <!-- =========================
         HEADER
    ========================== -->

    <div class="header">

        <div class="company-name">
            Reporting System
        </div>

        <div class="report-title">
            Daily Employee Report
        </div>

        <div class="report-date">
            Report Date:
            {{ $dailyReport->report_date->format('d M Y') }}
        </div>

    </div>


    <!-- =========================
         EMPLOYEE INFORMATION
    ========================== -->

    <table class="employee-box">

        <tr>

            <td class="label">
                Employee
            </td>

            <td>
                {{ $dailyReport->employee->name }}
            </td>

            <td class="label">
                Department
            </td>

            <td>
                {{ $dailyReport->employee->department->name ?? 'N/A' }}
            </td>

        </tr>

        <tr>

            <td class="label">
                Section Head
            </td>

            <td>
                {{ $dailyReport->employee->report_section_head ?? 'N/A' }}
            </td>

            <td class="label">
                Email
            </td>

            <td>
                {{ $dailyReport->employee->email ?? 'N/A' }}
            </td>

        </tr>

        <tr>

            <td class="label">
                Cell Number
            </td>

            <td colspan="3">
                {{ $dailyReport->employee->cell_number ?? 'N/A' }}
            </td>

        </tr>

    </table>


    <!-- =========================
         ACCOUNTS / FINANCE
    ========================== -->

    <div class="section">

        <div class="section-title">
            Accounts / Finance
        </div>

        <div class="section-content">

            @if($dailyReport->accounts_finance)

                {{ $dailyReport->accounts_finance }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         INQUIRIES / PROPOSALS
    ========================== -->

    <div class="section">

        <div class="section-title">
            Inquiries / Proposals
        </div>

        <div class="section-content">

            @if($dailyReport->inquiries_proposals)

                {{ $dailyReport->inquiries_proposals }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         ORDERS
    ========================== -->

    <div class="section">

        <div class="section-title">
            Orders
        </div>

        <div class="section-content">

            @if($dailyReport->orders)

                {{ $dailyReport->orders }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         FOLLOW UPS
    ========================== -->

    <div class="section">

        <div class="section-title">
            Follow-ups
        </div>

        <div class="section-content">

            @if($dailyReport->follow_ups)

                {{ $dailyReport->follow_ups }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         SHIPMENT
    ========================== -->

    <div class="section">

        <div class="section-title">
            Shipment
        </div>

        <div class="section-content">

            @if($dailyReport->shipment)

                {{ $dailyReport->shipment }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         PROJECTS
    ========================== -->

    <div class="section">

        <div class="section-title">
            Projects
        </div>

        <div class="section-content">

            @if($dailyReport->projects)

                {{ $dailyReport->projects }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         VISIT
    ========================== -->

    <div class="section">

        <div class="section-title">
            Visit
        </div>

        <div class="section-content">

            @if($dailyReport->visit)

                {{ $dailyReport->visit }}

            @else

                <span class="empty">
                    No activity reported.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         TOMORROW'S TASKS
    ========================== -->

    <div class="section">

        <div class="section-title">
            Tomorrow's Tasks
        </div>

        <div class="section-content">

            @if($dailyReport->tomorrow_tasks)

                {{ $dailyReport->tomorrow_tasks }}

            @else

                <span class="empty">
                    No tasks planned.
                </span>

            @endif

        </div>

    </div>


    <!-- =========================
         FOOTER
    ========================== -->

    <div class="footer">

        Generated by Reporting System
        |
        {{ now()->format('d M Y, h:i A') }}

    </div>

</body>
</html>