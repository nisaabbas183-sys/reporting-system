@extends('layouts.app')

@section('content')

<div class="page-header">

    <div>
        <h1>Daily Report Details</h1>
        <p>View complete employee daily report.</p>
    </div>

    <a href="{{ route('daily-reports.index') }}" class="btn btn-secondary">
        ← Back to Reports
    </a>

</div>


<div class="card">

    <div class="card-header">

        <div>
            <h3>Employee Report</h3>
            <p>Submitted daily report details</p>
        </div>

        <span class="status-badge">
            <span class="status-dot"></span>
            Submitted
        </span>

    </div>


    <div class="report-details">

        <!-- Employee -->

        <div class="detail-section">

            <h4>Employee Information</h4>

            <div class="detail-grid">

                <div class="detail-item">
                    <label>Employee</label>
                    <strong>
                        {{ $dailyReport->employee->name ?? 'N/A' }}
                    </strong>
                </div>

                <div class="detail-item">
                    <label>Email</label>
                    <strong>
                        {{ $dailyReport->employee->email ?? 'N/A' }}
                    </strong>
                </div>

                <div class="detail-item">
                    <label>Department</label>
                    <strong>
                        {{ $dailyReport->employee->department->name ?? 'N/A' }}
                    </strong>
                </div>

                <div class="detail-item">
                    <label>Report Date</label>
                    <strong>
                        {{ $dailyReport->report_date->format('d-m-Y') }}
                    </strong>
                </div>

            </div>

        </div>


        <!-- Daily Report -->

        <div class="detail-section">

            <h4>Daily Report</h4>

            <div class="report-field">

                <label>
                    {{ $dailyReport->employee->department->name ?? 'Work Report' }}
                </label>

                <div class="report-text">
                    {{ $dailyReport->report_content ?: 'No information provided.' }}
                </div>

            </div>


            <div class="report-field">

                <label>Tomorrow's Tasks</label>

                <div class="report-text">
                    {{ $dailyReport->tomorrow_tasks ?: 'No information provided.' }}
                </div>

            </div>

        </div>

    </div>


    <!-- Footer Actions -->

    <div class="report-footer">

        
           <a href="{{ route('daily-reports.edit', $dailyReport->id) }}"
            class="btn btn-edit"
        >
            Edit Report
        </a>

        <form
            action="{{ route('daily-reports.destroy', $dailyReport->id) }}"
            method="POST"
            onsubmit="return confirm('Are you sure you want to delete this report?');"
        >

            @csrf
            @method('DELETE')

            <button type="submit" class="btn btn-delete">
                Delete Report
            </button>

        </form>

    </div>

</div>


<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.page-header h1 {
    margin: 0 0 6px;
    color: #2C3E50;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #5D6D7E;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 10px 16px;
    border-radius: 7px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.btn-secondary {
    background: #ECF0F1;
    color: #2C3E50;
}

.btn-edit {
    background: #FEF5E7;
    color: #F39C12;
}

.btn-delete {
    background: #FDEDEC;
    color: #E74C3C;
}

.btn:hover {
    opacity: 0.85;
}

.card {
    background: white;
    border-radius: 10px;
    border: 1px solid #E5E9ED;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}

.card-header {
    padding: 20px 24px;
    border-bottom: 1px solid #EAECEE;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header h3 {
    margin: 0 0 5px;
    color: #2C3E50;
    font-size: 17px;
}

.card-header p {
    margin: 0;
    color: #8493A0;
    font-size: 12px;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 12px;
    border-radius: 20px;
    background: #E8F8F0;
    color: #27AE60;
    font-size: 12px;
    font-weight: 600;
}

.status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: currentColor;
}

.report-details {
    padding: 24px;
}

.detail-section {
    margin-bottom: 30px;
}

.detail-section:last-child {
    margin-bottom: 0;
}

.detail-section h4 {
    color: #2C3E50;
    font-size: 15px;
    margin-bottom: 18px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EAECEE;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.detail-item {
    background: #F8F9FA;
    padding: 15px;
    border-radius: 7px;
}

.detail-item label,
.report-field label {
    display: block;
    color: #8493A0;
    font-size: 11px;
    font-weight: 600;
    margin-bottom: 6px;
    text-transform: uppercase;
}

.detail-item strong {
    color: #2C3E50;
    font-size: 14px;
}

.report-field {
    margin-bottom: 18px;
}

.report-text {
    background: #F8F9FA;
    border: 1px solid #EAECEE;
    border-radius: 7px;
    padding: 14px;
    color: #5D6D7E;
    font-size: 13px;
    line-height: 1.6;
    min-height: 45px;
    white-space: pre-line;
}

.report-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 18px 24px;
    border-top: 1px solid #EAECEE;
}

.report-footer form {
    display: inline;
}

@media (max-width: 768px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .detail-grid {
        grid-template-columns: 1fr;
    }

    .card-header {
        align-items: flex-start;
        gap: 15px;
        flex-direction: column;
    }

    .report-footer {
        justify-content: flex-start;
    }

}

</style>

@endsection