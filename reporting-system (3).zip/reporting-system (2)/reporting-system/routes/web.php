<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\DailyReportController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\DailyReportPdfController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\EmployeeLoginController;
use App\Http\Controllers\EmployeeDashboardController;
use App\Http\Controllers\EmployeeTaskController;
use App\Http\Controllers\EmployeeProfileController;
use App\Http\Controllers\EmailSettingController;


/*
|--------------------------------------------------------------------------
| Starting Page
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('landing');
})->name('home');


/*
|--------------------------------------------------------------------------
| Employee Login
|--------------------------------------------------------------------------
*/

Route::get('/employee/login', [
    EmployeeLoginController::class,
    'showLogin'
])->name('employee.login');

Route::post('/employee/login', [
    EmployeeLoginController::class,
    'login'
])->name('employee.login.submit');


/*
|--------------------------------------------------------------------------
| Employee Protected Area
|--------------------------------------------------------------------------
*/

Route::middleware('employee.auth')
    ->prefix('employee')
    ->group(function () {

        /*
        | Employee Dashboard
        */

        Route::get('/dashboard', [
            EmployeeDashboardController::class,
            'index'
        ])->name('employee.dashboard');


        /*
        | Submit Daily Report - Show Form
        */

        Route::get('/daily-report/create', [
            DailyReportController::class,
            'employeeCreate'
        ])->name('employee.daily-reports.create');


        /*
        | Submit Daily Report - Save Report
        */

        Route::post('/daily-report/store', [
            DailyReportController::class,
            'employeeStore'
        ])->name('employee.daily-reports.store');


        /*
        | My Tasks
        */

        Route::get('/my-tasks', [
            EmployeeTaskController::class,
            'index'
        ])->name('employee.tasks.index');
        

        Route::post('/my-tasks/{task}/submit', [
            EmployeeTaskController::class,
            'submit'
        ])->name('employee.tasks.submit');


        /*
        | My Profile
        */

        Route::get('/my-profile', [
            EmployeeProfileController::class,
            'index'
        ])->name('employee.profile.index');

        Route::post('/my-profile/photo', [
            EmployeeProfileController::class,
            'updatePhoto'
        ])->name('employee.profile.photo.update');

        Route::put('/my-profile/password', [
            EmployeeProfileController::class,
            'updatePassword'
        ])->name('employee.profile.password.update');


        /*
        | Employee Logout
        */

        Route::post('/logout', [
            EmployeeLoginController::class,
            'logout'
        ])->name('employee.logout');

    });


/*
|--------------------------------------------------------------------------
| Admin Login
|--------------------------------------------------------------------------
*/

Route::get('/login', [
    LoginController::class,
    'showLogin'
])->name('login');

Route::post('/login', [
    LoginController::class,
    'login'
])->name('login.submit');


/*
|--------------------------------------------------------------------------
| Protected Admin Area
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Admin Dashboard
    |--------------------------------------------------------------------------
    */

    Route::get('/dashboard', [
        \App\Http\Controllers\DashboardController::class,
        'index'
    ])->name('dashboard');


    /*
    |--------------------------------------------------------------------------
    | Departments
    |--------------------------------------------------------------------------
    */

    Route::resource(
        'departments',
        DepartmentController::class
    );


    /*
    |--------------------------------------------------------------------------
    | Employees
    |--------------------------------------------------------------------------
    */

    Route::resource(
        'employees',
        EmployeeController::class
    );

    Route::patch(
        '/employees/{employee}/toggle-status',
        [EmployeeController::class, 'toggleStatus']
    )->name('employees.toggle-status');


    /*
    |--------------------------------------------------------------------------
    | Admin Daily Reports
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/daily-reports/consolidated/pdf',
        [DailyReportPdfController::class, 'consolidated']
    )->name('daily-reports.consolidated-pdf');

    Route::resource(
        'daily-reports',
        DailyReportController::class
    );

    Route::get(
        '/daily-reports/{dailyReport}/pdf',
        [DailyReportPdfController::class, 'download']
    )->name('daily-reports.pdf');


    /*
    |--------------------------------------------------------------------------
    | Tasks
    |--------------------------------------------------------------------------
    */

    Route::resource(
        'tasks',
        TaskController::class
    );

    Route::post(
        '/tasks/{task}/approve',
        [TaskController::class, 'approve']
    )->name('tasks.approve');


    /*
    |--------------------------------------------------------------------------
    | Settings
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/settings',
        [SettingsController::class, 'index']
    )->name('settings.index');

    Route::post(
        '/settings',
        [SettingsController::class, 'update']
    )->name('settings.update');
        Route::get('/email-settings', [EmailSettingController::class, 'edit'])
        ->name('email-settings.edit');

    Route::put('/email-settings', [EmailSettingController::class, 'update'])
        ->name('email-settings.update');

    Route::post('/email-settings/test', [EmailSettingController::class, 'test'])
        ->name('email-settings.test');

    /*
    |--------------------------------------------------------------------------
    | Admin Logout
    |--------------------------------------------------------------------------
    */

    Route::post('/logout', [
        LoginController::class,
        'logout'
    ])->name('logout');

});