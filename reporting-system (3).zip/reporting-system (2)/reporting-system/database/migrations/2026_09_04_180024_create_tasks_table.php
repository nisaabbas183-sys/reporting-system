<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();

            // Employee assigned to this task
            $table->foreignId('employee_id')
                ->constrained('employees')
                ->cascadeOnDelete();

            // Task description
            $table->text('task');

            // Date when task was created
            $table->date('task_date');

            // Date when task is expected to be completed
            $table->date('due_date')->nullable();

            // Pending or completed
            $table->enum('status', ['pending', 'completed'])
                ->default('pending');

            // If this task was carried forward from a previous report
            $table->foreignId('carried_from_task_id')
                ->nullable()
                ->constrained('tasks')
                ->nullOnDelete();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tasks');
    }
};