<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('employees', function (Blueprint $table) {

            if (!Schema::hasColumn('employees', 'department_id')) {
                $table->foreignId('department_id')
                    ->after('name')
                    ->constrained('departments')
                    ->onDelete('cascade');
            }

            if (!Schema::hasColumn('employees', 'report_section_head')) {
                $table->string('report_section_head')
                    ->after('department_id');
            }

            if (!Schema::hasColumn('employees', 'email')) {
                $table->string('email')
                    ->unique()
                    ->after('report_section_head');
            }

        });
    }

    public function down(): void
    {
        Schema::table('employees', function (Blueprint $table) {

            if (Schema::hasColumn('employees', 'department_id')) {
                $table->dropForeign(['department_id']);
                $table->dropColumn('department_id');
            }

            if (Schema::hasColumn('employees', 'report_section_head')) {
                $table->dropColumn('report_section_head');
            }

            if (Schema::hasColumn('employees', 'email')) {
                $table->dropColumn('email');
            }

        });
    }
};