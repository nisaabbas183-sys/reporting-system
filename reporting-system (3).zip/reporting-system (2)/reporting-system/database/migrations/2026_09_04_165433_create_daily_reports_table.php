<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('daily_reports', function (Blueprint $table) {
            $table->id();

            // Employee who submitted the report
            $table->foreignId('employee_id')
                ->constrained('employees')
                ->cascadeOnDelete();

            // Date of the report
            $table->date('report_date');

            // Daily report sections
            $table->text('accounts_finance')->nullable();
            $table->text('inquiries_proposals')->nullable();
            $table->text('orders')->nullable();
            $table->text('follow_ups')->nullable();
            $table->text('shipment')->nullable();
            $table->text('projects')->nullable();
            $table->text('visit')->nullable();

            // Tomorrow's tasks
            $table->text('tomorrow_tasks')->nullable();

            $table->timestamps();

            // One report per employee per day
            $table->unique(['employee_id', 'report_date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('daily_reports');
    }
};