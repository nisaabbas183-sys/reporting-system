<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('email_settings', function (Blueprint $table) {
            $table->id();
            $table->boolean('is_enabled')->default(false);
            $table->string('smtp_host')->nullable();
            $table->unsignedInteger('smtp_port')->default(587);
            $table->string('smtp_username')->nullable();
            $table->text('smtp_password')->nullable();   // encrypted
            $table->string('smtp_encryption')->default('tls'); // tls | ssl | none
            $table->string('from_email')->nullable();
            $table->string('from_name')->nullable();
            $table->text('recipients')->nullable();      // comma separated
            $table->string('send_time')->default('18:00'); // H:i
            $table->date('last_sent_date')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('email_settings');
    }
};