

<?php $__env->startSection('content'); ?>

<div class="dashboard-page">

    
    <div class="stats-grid">

        <div class="stat-card">
            <div class="stat-icon employees-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </div>

            <div class="stat-info">
                <span>Total Employees</span>
                <strong><?php echo e($totalEmployees); ?></strong>
            </div>
        </div>


        <div class="stat-card">
            <div class="stat-icon active-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 6L9 17l-5-5"></path>
                </svg>
            </div>

            <div class="stat-info">
                <span>Active Employees</span>
                <strong><?php echo e($activeEmployees); ?></strong>
            </div>
        </div>


        <div class="stat-card">
            <div class="stat-icon department-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2"></rect>
                    <path d="M9 3v18"></path>
                    <path d="M3 9h6"></path>
                    <path d="M3 15h6"></path>
                </svg>
            </div>

            <div class="stat-info">
                <span>Departments</span>
                <strong><?php echo e($totalDepartments); ?></strong>
            </div>
        </div>


        <div class="stat-card">
            <div class="stat-icon report-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="8" y1="13" x2="16" y2="13"></line>
                    <line x1="8" y1="17" x2="16" y2="17"></line>
                </svg>
            </div>

            <div class="stat-info">
                <span>Today's Reports</span>
                <strong><?php echo e($todayReports); ?></strong>
            </div>
        </div>


        <div class="stat-card">
            <div class="stat-icon pending-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="9"></circle>
                    <polyline points="12 7 12 12 15 14"></polyline>
                </svg>
            </div>

            <div class="stat-info">
                <span>Pending Tasks</span>
                <strong><?php echo e($pendingTasks); ?></strong>
            </div>
        </div>


        <div class="stat-card">
            <div class="stat-icon completed-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="9"></circle>
                    <polyline points="8 12 11 15 16 9"></polyline>
                </svg>
            </div>

            <div class="stat-info">
                <span>Completed Tasks</span>
                <strong><?php echo e($completedTasks); ?></strong>
            </div>
        </div>

    </div>


    
    <div class="section-card">

        <div class="section-header">
            <div>
                <h2>Quick Actions</h2>
                <p>Quickly access frequently used features.</p>
            </div>
        </div>

        <div class="quick-actions">

            <a href="<?php echo e(route('employees.create')); ?>" class="quick-action">
                <div class="quick-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <line x1="19" y1="8" x2="19" y2="14"></line>
                        <line x1="16" y1="11" x2="22" y2="11"></line>
                    </svg>
                </div>

                <div>
                    <strong>Add Employee</strong>
                    <span>Create a new employee profile</span>
                </div>
            </a>


            <a href="<?php echo e(route('daily-reports.create')); ?>" class="quick-action">
                <div class="quick-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="12" y1="18" x2="12" y2="12"></line>
                        <line x1="9" y1="15" x2="15" y2="15"></line>
                    </svg>
                </div>

                <div>
                    <strong>Create Daily Report</strong>
                    <span>Submit today's employee report</span>
                </div>
            </a>


            <a href="<?php echo e(route('tasks.create')); ?>" class="quick-action">
                <div class="quick-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                </div>

                <div>
                    <strong>Add Task</strong>
                    <span>Create a task for an employee</span>
                </div>
            </a>

        </div>

    </div>


    
    <div class="section-card">

        <div class="section-header">
            <div>
                <h2>Recently Added Employees</h2>
                <p>Employees most recently added to the system.</p>
            </div>

            <a href="<?php echo e(route('employees.index')); ?>" class="view-all">
                View All
            </a>
        </div>


        <?php if($recentEmployees->count() > 0): ?>

            <div class="table-wrapper">

                <table class="dashboard-table">

                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Department</th>
                            <th>Email</th>
                            <th>Added On</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $recentEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>
                                    <div class="employee-name">
                                        <?php echo e($emp->name); ?>

                                    </div>
                                </td>

                                <td>
                                    <?php echo e($emp->department->name ?? 'N/A'); ?>

                                </td>

                                <td>
                                    <?php echo e($emp->email); ?>

                                </td>

                                <td>
                                    <?php echo e($emp->created_at->format('d M Y')); ?>

                                </td>

                                <td>

                                    <?php if($emp->status): ?>

                                        <span class="status-badge status-today">
                                            Active
                                        </span>

                                    <?php else: ?>

                                        <span class="status-badge status-previous">
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="empty-state">

                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">

                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>

                </svg>

                <h3>No Employees Yet</h3>

                <p>No employees have been added to the system.</p>

            </div>

        <?php endif; ?>

    </div>


    
    <div class="section-card">

        <div class="section-header">
            <div>
                <h2>Recent Daily Reports</h2>
                <p>Latest employee reports submitted in the system.</p>
            </div>

            <a href="<?php echo e(route('daily-reports.index')); ?>" class="view-all">
                View All
            </a>
        </div>


        <?php if($recentReports->count() > 0): ?>

            <div class="table-wrapper">

                <table class="dashboard-table">

                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Department</th>
                            <th>Report Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $recentReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>
                                    <div class="employee-name">
                                        <?php echo e($report->employee->name); ?>

                                    </div>
                                </td>

                                <td>
                                    <?php echo e($report->employee->department->name ?? 'N/A'); ?>

                                </td>

                                <td>
                                    <?php echo e($report->report_date->format('d M Y')); ?>

                                </td>

                                <td>

                                    <?php if($report->report_date->isToday()): ?>

                                        <span class="status-badge status-today">
                                            Today
                                        </span>

                                    <?php else: ?>

                                        <span class="status-badge status-previous">
                                            Previous
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    
                                        <a href="<?php echo e(route('daily-reports.show', $report)); ?>"
                                        class="view-btn"
                                    >
                                        View
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="empty-state">

                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">

                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>

                    <polyline points="14 2 14 8 20 8"></polyline>

                </svg>

                <h3>No Reports Yet</h3>

                <p>No daily reports have been submitted yet.</p>

            </div>

        <?php endif; ?>

    </div>

</div>


<style>

.dashboard-page {
    width: 100%;
}


/* =========================
   STATISTICS
========================= */

.stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 22px;
}

.stat-card {
    background: #ffffff;
    border: 1px solid #E1E6EA;
    border-radius: 10px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(44, 62, 80, 0.04);
}

.stat-icon {
    width: 52px;
    height: 52px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.stat-icon svg {
    width: 25px;
    height: 25px;
}

.employees-icon {
    background: #EBF5FB;
    color: #3498DB;
}

.active-icon {
    background: #EAF7EE;
    color: #27AE60;
}

.department-icon {
    background: #F4ECF7;
    color: #8E44AD;
}

.report-icon {
    background: #EBF5FB;
    color: #3498DB;
}

.pending-icon {
    background: #FEF5E7;
    color: #F39C12;
}

.completed-icon {
    background: #EAF7EE;
    color: #27AE60;
}

.stat-info {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.stat-info span {
    font-size: 13px;
    color: #5D6D7E;
}

.stat-info strong {
    font-size: 26px;
    color: #2C3E50;
}


/* =========================
   SECTION CARD
========================= */

.section-card {
    background: #ffffff;
    border: 1px solid #E1E6EA;
    border-radius: 10px;
    margin-bottom: 22px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(44, 62, 80, 0.04);
}

.section-header {
    padding: 18px 20px;
    border-bottom: 1px solid #E1E6EA;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.section-header h2 {
    margin: 0 0 5px;
    font-size: 17px;
    color: #2C3E50;
}

.section-header p {
    margin: 0;
    font-size: 13px;
    color: #5D6D7E;
}

.view-all {
    text-decoration: none;
    color: #3498DB;
    font-size: 13px;
    font-weight: 600;
}


/* =========================
   QUICK ACTIONS
========================= */

.quick-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
    padding: 18px 20px 20px;
}

.quick-action {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 15px;
    border: 1px solid #E1E6EA;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.2s ease;
}

.quick-action:hover {
    border-color: #3498DB;
    transform: translateY(-2px);
}

.quick-icon {
    width: 42px;
    height: 42px;
    background: #EBF5FB;
    color: #3498DB;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.quick-icon svg {
    width: 21px;
    height: 21px;
}

.quick-action strong {
    display: block;
    color: #2C3E50;
    font-size: 14px;
    margin-bottom: 4px;
}

.quick-action span {
    display: block;
    color: #5D6D7E;
    font-size: 11px;
}


/* =========================
   TABLE
========================= */

.table-wrapper {
    overflow-x: auto;
}

.dashboard-table {
    width: 100%;
    border-collapse: collapse;
}

.dashboard-table th {
    background: #F4F6F8;
    color: #2C3E50;
    font-size: 12px;
    font-weight: 600;
    text-align: left;
    padding: 13px 20px;
    border-bottom: 1px solid #E1E6EA;
}

.dashboard-table td {
    padding: 14px 20px;
    color: #5D6D7E;
    font-size: 13px;
    border-bottom: 1px solid #EDF0F2;
}

.dashboard-table tbody tr:last-child td {
    border-bottom: none;
}

.employee-name {
    color: #2C3E50;
    font-weight: 600;
}

.status-badge {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-today {
    background: #EAF7EE;
    color: #27AE60;
}

.status-previous {
    background: #EBF5FB;
    color: #3498DB;
}

.view-btn {
    display: inline-block;
    padding: 6px 11px;
    background: #EBF5FB;
    color: #3498DB;
    border-radius: 6px;
    text-decoration: none;
    font-size: 11px;
    font-weight: 600;
}


/* =========================
   EMPTY STATE
========================= */

.empty-state {
    padding: 45px 20px;
    text-align: center;
}

.empty-state svg {
    width: 45px;
    height: 45px;
    color: #AAB4BC;
    margin-bottom: 10px;
}

.empty-state h3 {
    margin: 0 0 5px;
    color: #2C3E50;
    font-size: 16px;
}

.empty-state p {
    margin: 0;
    color: #5D6D7E;
    font-size: 13px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1100px) {

    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .quick-actions {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 650px) {

    .stats-grid {
        grid-template-columns: 1fr;
    }

    .section-header {
        align-items: flex-start;
        gap: 10px;
    }

    .dashboard-table th,
    .dashboard-table td {
        padding: 11px 12px;
    }

}

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\reporting-system\resources\views/dashboard.blade.php ENDPATH**/ ?>