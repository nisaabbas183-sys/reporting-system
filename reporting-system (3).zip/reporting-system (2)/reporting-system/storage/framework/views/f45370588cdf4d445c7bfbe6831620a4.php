

<?php $__env->startSection('content'); ?>

<div class="page-header">

    <div>
        <h1>Daily Reports</h1>
        <p>Consolidated employee reports by department.</p>
    </div>

    
       <a href="<?php echo e(route('daily-reports.consolidated-pdf', ['report_date' => $reportDate])); ?>"
        class="btn btn-primary"
    >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
        Download PDF
    </a>

</div>


<?php if(session('success')): ?>
    <div class="alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


<!-- DATE FILTER -->

<div class="filter-card">

    <form method="GET" action="<?php echo e(route('daily-reports.index')); ?>" class="filter-form">

        <div class="filter-group">

            <label>Report Date</label>

            <input
                type="date"
                name="report_date"
                value="<?php echo e($reportDate); ?>"
                onchange="this.form.submit()"
            >

        </div>

        <button type="submit" class="btn btn-secondary">
            View
        </button>

    </form>

</div>


<!-- DEPARTMENT BOXES -->

<?php $__currentLoopData = $departmentBoxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentName => $box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="dept-card">

        <div class="dept-header">
            <h3><?php echo e($departmentName); ?></h3>
            <span><?php echo e(count($box['employees'])); ?> employee(s)</span>
        </div>

        <?php if(count($box['employees']) === 0): ?>

            <div class="dept-empty">
                No employees found in this department.
            </div>

        <?php else: ?>

            <div class="table-wrapper">

                <table class="dept-table">

                    <thead>
                        <tr>
                            <th>Employee</th>

                            <?php $__currentLoopData = $box['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($field['label']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $box['employees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td class="employee-name">
                                    <?php echo e($row['employee']->name); ?>

                                </td>

                                <?php $__currentLoopData = $box['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <td>

                                        <?php if($row['report'] && $row['report']->{$field['key']}): ?>

                                            <?php echo e($row['report']->{$field['key']}); ?>


                                        <?php else: ?>

                                            <span class="not-submitted">—</span>

                                        <?php endif; ?>

                                    </td>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td>

                                    <?php if($row['report']): ?>

                                        <span class="status-badge status-submitted">
                                            Submitted
                                        </span>

                                    <?php else: ?>

                                        <span class="status-badge status-not-submitted">
                                            Not Submitted
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.page-header h1 {
    margin: 0 0 6px;
    color: #2C3E50;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #5D6D7E;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 18px;
    border-radius: 7px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
}

.btn-primary {
    background: #3498DB;
    color: white;
}

.btn-primary:hover {
    opacity: 0.9;
}

.btn-secondary {
    background: #ECF0F1;
    color: #2C3E50;
}

.alert-success {
    background: #E8F8F0;
    color: #27AE60;
    padding: 12px 15px;
    border-radius: 7px;
    margin-bottom: 20px;
    font-size: 14px;
}

.filter-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    padding: 18px 20px;
    margin-bottom: 22px;
}

.filter-form {
    display: flex;
    align-items: flex-end;
    gap: 14px;
}

.filter-group label {
    display: block;
    color: #2C3E50;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 7px;
}

.filter-group input {
    border: 1px solid #D5DBDB;
    border-radius: 7px;
    padding: 10px 12px;
    font-size: 14px;
    color: #2C3E50;
}

.dept-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
    margin-bottom: 22px;
}

.dept-header {
    padding: 16px 20px;
    border-bottom: 1px solid #EAECEE;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.dept-header h3 {
    margin: 0;
    color: #2C3E50;
    font-size: 16px;
}

.dept-header span {
    color: #8493A0;
    font-size: 12px;
    font-weight: 600;
}

.dept-empty {
    padding: 24px 20px;
    color: #94a3b8;
    font-size: 13px;
    text-align: center;
}

.table-wrapper {
    overflow-x: auto;
}

.dept-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 700px;
}

.dept-table th {
    background: #F4F6F8;
    color: #2C3E50;
    text-align: left;
    padding: 12px 16px;
    font-size: 12px;
    font-weight: 700;
    white-space: nowrap;
}

.dept-table td {
    padding: 12px 16px;
    border-top: 1px solid #ECF0F1;
    color: #5D6D7E;
    font-size: 13px;
    max-width: 220px;
}

.employee-name {
    color: #2C3E50;
    font-weight: 600;
    white-space: nowrap;
}

.not-submitted {
    color: #cbd5e1;
}

.status-badge {
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

.status-submitted {
    background: #E8F8F0;
    color: #27AE60;
}

.status-not-submitted {
    background: #FDEDEC;
    color: #E74C3C;
}

@media (max-width: 768px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .filter-form {
        flex-direction: column;
        align-items: stretch;
    }

}

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\reporting-system\resources\views/daily_reports/index.blade.php ENDPATH**/ ?>