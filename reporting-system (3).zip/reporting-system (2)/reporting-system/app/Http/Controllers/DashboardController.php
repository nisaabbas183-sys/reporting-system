<?php

namespace App\Http\Controllers;

use App\Models\DailyReport;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Task;

class DashboardController extends Controller
{
    public function index()
    {
        $totalEmployees = Employee::count();

        $activeEmployees = Employee::where('status', 1)->count();

        $totalDepartments = Department::count();

        $pendingTasks = Task::where('status', 'pending')->count();

        $completedTasks = Task::where('status', 'completed')->count();

        $todayReports = DailyReport::whereDate(
            'report_date',
            today()
        )->count();

        $recentReports = DailyReport::with([
            'employee.department',
        ])
            ->latest('report_date')
            ->latest()
            ->take(5)
            ->get();

        $recentEmployees = Employee::with('department')
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact(
            'totalEmployees',
            'activeEmployees',
            'totalDepartments',
            'pendingTasks',
            'completedTasks',
            'todayReports',
            'recentReports',
            'recentEmployees'
        ))
            ->with('pageTitle', 'Dashboard')
            ->with(
                'pageSubtitle',
                'Overview of employee reports, tasks and departments.'
            );
    }
}