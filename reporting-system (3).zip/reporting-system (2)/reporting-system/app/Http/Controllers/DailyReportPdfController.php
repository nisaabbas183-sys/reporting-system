<?php

namespace App\Http\Controllers;

use App\Models\DailyReport;
use App\Models\Employee;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

class DailyReportPdfController extends Controller
{
    /**
     * Department field configuration.
     * Same mapping used in DailyReportController@index.
     */
    protected function departmentFieldMap(): array
    {
        return [
            'Finance' => [
                ['key' => 'accounts_finance', 'label' => 'Accounts & Finance'],
            ],
            'Sales' => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'Purchase' => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'shipment', 'label' => 'Shipments'],
            ],
            'Project-SLW' => [
                ['key' => 'projects', 'label' => 'Projects'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'HR' => [
                ['key' => 'hr_staff', 'label' => 'HR / Staff'],
            ],
        ];
    }


    /**
     * ADMIN — Individual employee report PDF.
     * (existing single-report download — used from daily_reports.show)
     */
    public function download(DailyReport $dailyReport)
    {
        $dailyReport->load(['employee.department']);

        $pdf = Pdf::loadView(
            'daily_reports.pdf',
            compact('dailyReport')
        )->setPaper('a4', 'portrait');

        return $pdf->download(
            'daily-report-' . $dailyReport->id . '.pdf'
        );
    }


       /**
     * ADMIN — Consolidated PDF for a selected date.
     */
    public function consolidated(Request $request)
    {
        $request->validate([
            'report_date' => 'nullable|date',
        ]);

        $reportDate = $request->input('report_date', now()->toDateString());

        $departmentFieldMap = $this->departmentFieldMap();

        $departmentNames = array_keys($departmentFieldMap);

        $employeesByDepartment = Employee::with('department')
            ->where('status', 1)
            ->whereHas('department', function ($q) use ($departmentNames) {
                $q->whereIn('name', $departmentNames);
            })
            ->orderBy('name')
            ->get()
            ->groupBy(fn ($employee) => $employee->department->name ?? '');

        $reportsForDate = DailyReport::with('employee.department')
            ->whereDate('report_date', $reportDate)
            ->get()
            ->keyBy('employee_id');

        /*
        |--------------------------------------------------------------------------
        | Get all employee IDs to fetch their tasks in one query
        |--------------------------------------------------------------------------
        */
        $allEmployeeIds = $employeesByDepartment
            ->flatten()
            ->pluck('id');

        $tasksByEmployee = \App\Models\Task::whereIn('employee_id', $allEmployeeIds)
            ->whereDate('task_date', '<=', $reportDate)
            ->orderBy('task_date')
            ->get()
            ->groupBy('employee_id');

        $departmentBoxes = [];

        foreach ($departmentFieldMap as $departmentName => $fields) {

            $employeesInDept = $employeesByDepartment->get($departmentName, collect());

            $rows = $employeesInDept->map(function ($employee) use ($reportsForDate, $tasksByEmployee) {

                $tasks = $tasksByEmployee->get($employee->id, collect());

                return [
                    'employee'  => $employee,
                    'report'    => $reportsForDate->get($employee->id),
                    'pending'   => $tasks->where('status', 'pending')->values(),
                    'submitted' => $tasks->where('status', 'submitted')->values(),
                    'completed' => $tasks->whereIn('status', ['completed', 'approved'])->values(),
                ];
            })->values();

            $departmentBoxes[$departmentName] = [
                'fields'    => $fields,
                'employees' => $rows,
            ];
        }

        $pdf = Pdf::loadView(
            'daily_reports.consolidated_pdf',
            [
                'reportDate'      => Carbon::parse($reportDate),
                'departmentBoxes' => $departmentBoxes,
            ]
        )->setPaper('a4', 'portrait');

        return $pdf->download(
            'daily-reports-' . Carbon::parse($reportDate)->format('Y-m-d') . '.pdf'
        );
    }
}