<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Task;
use Illuminate\Http\Request;

class EmployeeTaskController extends Controller
{
    /**
     * Show the logged-in employee's tasks
     * (pending + submitted + approved).
     */
    public function index(Request $request)
    {
        $employeeId = $request->session()->get(
            'employee_id'
        );

        $employee = Employee::with('department')
            ->findOrFail($employeeId);


        /*
        |--------------------------------------------------------------------------
        | Pending Tasks
        |--------------------------------------------------------------------------
        */

        $pendingTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where(
                'status',
                'pending'
            )
            ->orderBy('task_date')
            ->orderBy('created_at')
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Submitted Tasks (awaiting admin approval)
        |--------------------------------------------------------------------------
        */

        $submittedTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where(
                'status',
                'submitted'
            )
            ->orderByDesc('created_at')
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Approved Tasks (most recent first)
        |--------------------------------------------------------------------------
        */

        $approvedTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where(
                'status',
                'approved'
            )
            ->orderByDesc('completed_at')
            ->get();


        return view(
            'employees.tasks.index',
            compact(
                'employee',
                'pendingTasks',
                'submittedTasks',
                'approvedTasks'
            )
        );
    }


    /**
     * Submit a pending task for admin approval.
     */
    public function submit(Request $request, Task $task)
    {
        $employeeId = $request->session()->get(
            'employee_id'
        );

        // Security check: employee can only submit their own task
        if ($task->employee_id !== $employeeId) {
            abort(403);
        }

        if ($task->status !== 'pending') {
            return redirect()
                ->back()
                ->with(
                    'error',
                    'Only pending tasks can be submitted for approval.'
                );
        }

        $task->update([
            'status' => 'submitted',
        ]);

        return redirect()
            ->back()
            ->with(
                'success',
                'Task submitted for approval.'
            );
    }
}