<?php

namespace App\Http\Controllers;

use App\Models\DailyReport;
use App\Models\Employee;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DailyReportController extends Controller
{
    /**
     * Department field configuration.
     * Used to build the consolidated admin view.
     */
    protected function departmentFieldMap(): array
    {
        return [
            'Finance' => [
                ['key' => 'accounts_finance', 'label' => 'Accounts & Finance'],
            ],
            'Sales' => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'Purchase' => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'shipment', 'label' => 'Shipments'],
            ],
            'Project-SLW' => [
                ['key' => 'projects', 'label' => 'Projects'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'HR' => [
                ['key' => 'hr_staff', 'label' => 'HR / Staff'],
            ],
        ];
    }


    /**
     * Display all daily reports with filters.
     * ADMIN ONLY — consolidated department view for a selected date.
     */
    public function index(Request $request)
    {
        $request->validate([
            'report_date' => 'nullable|date',
        ]);

        $reportDate = $request->input('report_date', now()->toDateString());

        $departmentFieldMap = $this->departmentFieldMap();

        $departmentNames = array_keys($departmentFieldMap);

        /*
        |--------------------------------------------------------------------------
        | Get all active employees, grouped by department
        |--------------------------------------------------------------------------
        */
        $employeesByDepartment = Employee::with('department')
            ->where('status', 1)
            ->whereHas('department', function ($q) use ($departmentNames) {
                $q->whereIn('name', $departmentNames);
            })
            ->orderBy('name')
            ->get()
            ->groupBy(fn ($employee) => $employee->department->name ?? '');

        /*
        |--------------------------------------------------------------------------
        | Get all reports submitted on the selected date
        |--------------------------------------------------------------------------
        */
        $reportsForDate = DailyReport::with('employee.department')
            ->whereDate('report_date', $reportDate)
            ->get()
            ->keyBy('employee_id');

        /*
        |--------------------------------------------------------------------------
        | Build consolidated structure:
        | departmentBoxes[departmentName] = [
        |     'fields' => [...],
        |     'employees' => [
        |         ['employee' => Employee, 'report' => DailyReport|null],
        |         ...
        |     ]
        | ]
        |--------------------------------------------------------------------------
        */
        $departmentBoxes = [];

        foreach ($departmentFieldMap as $departmentName => $fields) {

            $employeesInDept = $employeesByDepartment->get($departmentName, collect());

            $rows = $employeesInDept->map(function ($employee) use ($reportsForDate) {

                return [
                    'employee' => $employee,
                    'report'   => $reportsForDate->get($employee->id),
                ];
            })->values();

            $departmentBoxes[$departmentName] = [
                'fields'    => $fields,
                'employees' => $rows,
            ];
        }

        return view(
            'daily_reports.index',
            compact('departmentBoxes', 'reportDate')
        )
            ->with('pageTitle', 'Daily Reports')
            ->with('pageSubtitle', 'Consolidated employee reports by department.');
    }


    /**
     * Show admin form for creating a daily report.
     * ADMIN ONLY
     */
    public function create()
    {
        $employees = Employee::where('status', 1)
            ->orderBy('name')
            ->get();

        $selectedEmployee = null;
        $pendingTasks = collect();

        $reportDate = request('report_date', now()->toDateString());

        if (request()->filled('employee_id')) {

            $selectedEmployee = Employee::with('department')->find(
                request('employee_id')
            );

            if ($selectedEmployee) {

                $pendingTasks = Task::where('employee_id', $selectedEmployee->id)
                    ->where('status', 'pending')
                    ->whereDate('task_date', '<=', $reportDate)
                    ->orderBy('task_date')
                    ->orderBy('created_at')
                    ->get();
            }
        }

        return view(
            'daily_reports.create',
            compact('employees', 'selectedEmployee', 'pendingTasks', 'reportDate')
        )
            ->with('pageTitle', 'Create Daily Report')
            ->with('pageSubtitle', "Submit today's employee daily report.");
    }


    /**
     * Employee: Show daily report form.
     */
    public function employeeCreate(Request $request)
    {
        $employeeId = $request->session()->get('employee_id');

        $employee = Employee::with('department')->findOrFail($employeeId);

        $reportDate = today();

        $pendingTasks = Task::where('employee_id', $employee->id)
            ->where('status', 'pending')
            ->whereDate('task_date', '<=', $reportDate)
            ->orderBy('task_date')
            ->orderBy('created_at')
            ->get();

        $todayReport = DailyReport::where('employee_id', $employee->id)
            ->whereDate('report_date', $reportDate)
            ->first();

        return view(
            'employees.daily_reports.create',
            compact('employee', 'pendingTasks', 'todayReport', 'reportDate')
        );
    }


    /**
     * Employee: Store daily report.
     */
    public function employeeStore(Request $request)
    {
        $employeeId = $request->session()->get('employee_id');

        $employee = Employee::findOrFail($employeeId);

        $validated = $request->validate([

            'accounts_finance'    => 'nullable|string',
            'inquiries_proposals' => 'nullable|string',
            'orders'              => 'nullable|string',
            'follow_ups'          => 'nullable|string',
            'shipment'            => 'nullable|string',
            'projects'            => 'nullable|string',
            'visit'               => 'nullable|string',
            'hr_staff'            => 'nullable|string',
            'misc'                => 'nullable|string',
            'tomorrow_tasks'      => 'nullable|string',

            'completed_task_ids'   => 'nullable|array',
            'completed_task_ids.*' => 'integer|exists:tasks,id',
        ]);

        $reportDate = today();

        $existingReport = DailyReport::where('employee_id', $employee->id)
            ->whereDate('report_date', $reportDate)
            ->first();

        if ($existingReport) {

            return redirect()
                ->route('employee.daily-reports.create')
                ->with('error', "You have already submitted today's report.");
        }

        $dailyReport = DailyReport::create([

            'employee_id'          => $employee->id,
            'report_date'          => $reportDate,
            'accounts_finance'     => $validated['accounts_finance'] ?? null,
            'inquiries_proposals'  => $validated['inquiries_proposals'] ?? null,
            'orders'               => $validated['orders'] ?? null,
            'follow_ups'           => $validated['follow_ups'] ?? null,
            'shipment'             => $validated['shipment'] ?? null,
            'projects'             => $validated['projects'] ?? null,
            'visit'                => $validated['visit'] ?? null,
            'hr_staff'             => $validated['hr_staff'] ?? null,
            'misc'                 => $validated['misc'] ?? null,
            'tomorrow_tasks'       => $validated['tomorrow_tasks'] ?? null,
        ]);

        if (!empty($validated['completed_task_ids'])) {

            Task::where('employee_id', $employee->id)
                ->whereIn('id', $validated['completed_task_ids'])
                ->where('status', 'pending')
                ->update(['status' => 'completed']);
        }

        if (!empty($validated['tomorrow_tasks'])) {

            $tomorrow = Carbon::parse($reportDate)->addDay()->toDateString();

            $tasks = preg_split("/\r\n|\r|\n/", $validated['tomorrow_tasks']);

            foreach ($tasks as $taskText) {

                $taskText = trim($taskText);

                if ($taskText === '') {
                    continue;
                }

                Task::create([
                    'employee_id' => $employee->id,
                    'task'        => $taskText,
                    'task_date'   => $tomorrow,
                    'status'      => 'pending',
                ]);
            }
        }

        return redirect()
            ->route('employee.dashboard')
            ->with('success', 'Your daily report has been submitted successfully.');
    }


    /**
     * Admin: Store a new daily report.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([

            'employee_id'          => 'required|exists:employees,id',
            'report_date'          => 'required|date',
            'accounts_finance'     => 'nullable|string',
            'inquiries_proposals'  => 'nullable|string',
            'orders'               => 'nullable|string',
            'follow_ups'           => 'nullable|string',
            'shipment'             => 'nullable|string',
            'projects'             => 'nullable|string',
            'visit'                => 'nullable|string',
            'hr_staff'             => 'nullable|string',
            'misc'                 => 'nullable|string',
            'tomorrow_tasks'       => 'nullable|string',

            'completed_task_ids'   => 'nullable|array',
            'completed_task_ids.*' => 'integer|exists:tasks,id',
        ]);

        DB::transaction(function () use ($validated) {

            DailyReport::create([

                'employee_id'          => $validated['employee_id'],
                'report_date'          => $validated['report_date'],
                'accounts_finance'     => $validated['accounts_finance'] ?? null,
                'inquiries_proposals'  => $validated['inquiries_proposals'] ?? null,
                'orders'               => $validated['orders'] ?? null,
                'follow_ups'           => $validated['follow_ups'] ?? null,
                'shipment'             => $validated['shipment'] ?? null,
                'projects'             => $validated['projects'] ?? null,
                'visit'                => $validated['visit'] ?? null,
                'hr_staff'             => $validated['hr_staff'] ?? null,
                'misc'                 => $validated['misc'] ?? null,
                'tomorrow_tasks'       => $validated['tomorrow_tasks'] ?? null,
            ]);

            if (!empty($validated['completed_task_ids'])) {

                Task::where('employee_id', $validated['employee_id'])
                    ->whereIn('id', $validated['completed_task_ids'])
                    ->where('status', 'pending')
                    ->update(['status' => 'completed']);
            }

            if (!empty($validated['tomorrow_tasks'])) {

                $tomorrow = Carbon::parse($validated['report_date'])->addDay()->toDateString();

                $tasks = preg_split("/\r\n|\r|\n/", $validated['tomorrow_tasks']);

                foreach ($tasks as $taskText) {

                    $taskText = trim($taskText);

                    if ($taskText === '') {
                        continue;
                    }

                    Task::create([
                        'employee_id' => $validated['employee_id'],
                        'task'        => $taskText,
                        'task_date'   => $tomorrow,
                        'status'      => 'pending',
                    ]);
                }
            }
        });

        return redirect()
            ->route('daily-reports.index')
            ->with('success', 'Daily report submitted successfully.');
    }


    /**
     * Display a specific daily report.
     */
    public function show(DailyReport $dailyReport)
    {
        $dailyReport->load(['employee.department']);

        return view(
            'daily_reports.show',
            compact('dailyReport')
        )
            ->with('pageTitle', 'Daily Report Details')
            ->with('pageSubtitle', 'View complete employee daily report.');
    }


    /**
     * Show form for editing a daily report.
     */
    public function edit(DailyReport $dailyReport)
    {
        $employees = Employee::where('status', 1)
            ->orderBy('name')
            ->get();

        return view(
            'daily_reports.edit',
            compact('dailyReport', 'employees')
        )
            ->with('pageTitle', 'Edit Daily Report')
            ->with('pageSubtitle', 'Update employee daily report.');
    }


    /**
     * Update a daily report.
     */
    public function update(Request $request, DailyReport $dailyReport)
    {
        $validated = $request->validate([

            'employee_id'          => 'required|exists:employees,id',
            'report_date'          => 'required|date',
            'accounts_finance'     => 'nullable|string',
            'inquiries_proposals'  => 'nullable|string',
            'orders'               => 'nullable|string',
            'follow_ups'           => 'nullable|string',
            'shipment'             => 'nullable|string',
            'projects'             => 'nullable|string',
            'visit'                => 'nullable|string',
            'hr_staff'             => 'nullable|string',
            'misc'                 => 'nullable|string',
            'tomorrow_tasks'       => 'nullable|string',
        ]);

        $dailyReport->update($validated);

        return redirect()
            ->route('daily-reports.index')
            ->with('success', 'Daily report updated successfully.');
    }


    /**
     * Delete a daily report.
     */
    public function destroy(DailyReport $dailyReport)
    {
        $dailyReport->delete();

        return redirect()
            ->route('daily-reports.index')
            ->with('success', 'Daily report deleted successfully.');
    }
}