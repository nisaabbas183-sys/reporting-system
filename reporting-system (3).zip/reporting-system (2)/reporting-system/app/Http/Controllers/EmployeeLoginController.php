<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeLoginController extends Controller
{
    public function showLogin()
    {
        return view('employees.auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $employee = Employee::where(
            'email',
            $credentials['email']
        )
            ->where('status', 1)
            ->first();

        if (
            $employee &&
            Hash::check(
                $credentials['password'],
                $employee->password
            )
        ) {
            $request->session()->regenerate();

            $request->session()->put(
                'employee_id',
                $employee->id
            );

            return redirect()->route(
                'employee.dashboard'
            );
        }

        return back()
            ->withErrors([
                'email' => 'The provided credentials are incorrect.',
            ])
            ->onlyInput('email');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('employee_id');

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home');
    }
}