<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeController extends Controller
{
    /**
     * Display all employees.
     */
    public function index()
    {
        $employees = Employee::with('department')
            ->latest()
            ->get();

        return view('employees.index', compact('employees'))
            ->with('pageTitle', 'Employees')
            ->with('pageSubtitle', 'Manage employees and their information.');
    }

    /**
     * Show the form for creating a new employee.
     */
    public function create()
    {
        $departments = Department::where('status', 1)
            ->orderBy('name')
            ->get();

        return view('employees.create', compact('departments'))
            ->with('pageTitle', 'Add Employee')
            ->with('pageSubtitle', 'Create a new employee profile.');
    }

    /**
     * Store a new employee.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'department_id' => 'required|exists:departments,id',
            'report_section_head' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:employees,email',
            'cell_number' => 'required|string|max:255',
            'password' => 'required|string|min:6',
        ]);

        $validated['password'] = Hash::make($validated['password']);
        $validated['status'] = 1;

        Employee::create($validated);

        return redirect()
            ->route('employees.index')
            ->with('success', 'Employee added successfully.');
    }

    /**
     * Show the form for editing an employee.
     */
    public function edit(Employee $employee)
    {
        $departments = Department::where('status', 1)
            ->orderBy('name')
            ->get();

        return view('employees.edit', compact('employee', 'departments'))
            ->with('pageTitle', 'Edit Employee')
            ->with('pageSubtitle', 'Update employee information.');
    }

    /**
     * Update an employee.
     */
    public function update(Request $request, Employee $employee)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'department_id' => 'required|exists:departments,id',
            'report_section_head' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:employees,email,' . $employee->id,
            'cell_number' => 'required|string|max:255',
            'password' => 'nullable|string|min:6',
        ]);

        if (!empty($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $employee->update($validated);

        return redirect()
            ->route('employees.index')
            ->with('success', 'Employee updated successfully.');
    }

    /**
     * Toggle employee status.
     */
    public function toggleStatus(Employee $employee)
    {
        $employee->update([
            'status' => !$employee->status,
        ]);

        return redirect()
            ->route('employees.index')
            ->with('success', 'Employee status updated successfully.');
    }

    /**
     * Delete an employee.
     */
    public function destroy(Employee $employee)
    {
        $employee->delete();

        return redirect()
            ->route('employees.index')
            ->with('success', 'Employee deleted successfully.');
    }
}