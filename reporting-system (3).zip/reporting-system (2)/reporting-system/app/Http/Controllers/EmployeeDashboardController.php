<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Task;
use App\Models\DailyReport;
use Illuminate\Http\Request;

class EmployeeDashboardController extends Controller
{
    public function index(Request $request)
    {
        $employeeId = $request->session()->get('employee_id');

        $employee = Employee::with('department')
            ->findOrFail($employeeId);

        $today = today();

        // Today's report
        $todayReport = DailyReport::where(
            'employee_id',
            $employee->id
        )
            ->whereDate('report_date', $today)
            ->latest('id')
            ->first();

        // Pending tasks for this employee
        // These tasks will appear in the daily report
        $pendingTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where('status', 'pending')
            ->whereDate('task_date', '<=', $today)
            ->orderBy('task_date')
            ->orderBy('created_at')
            ->get();

        // Recently completed tasks for this employee
        $completedTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where('status', 'completed')
            ->latest('id')
            ->take(10)
            ->get();

        // Previous reports of this employee
        $recentReports = DailyReport::where(
            'employee_id',
            $employee->id
        )
            ->latest('report_date')
            ->latest('id')
            ->take(5)
            ->get();

        return view(
            'employees.dashboard',
            compact(
                'employee',
                'todayReport',
                'pendingTasks',
                'completedTasks',
                'recentReports'
            )
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Create Employee Daily Report
    |--------------------------------------------------------------------------
    */

    public function createReport(Request $request)
    {
        $employeeId = $request->session()->get('employee_id');

        $employee = Employee::with('department')
            ->findOrFail($employeeId);

        $reportDate = today();

        // Pending tasks of logged-in employee
        $pendingTasks = Task::where(
            'employee_id',
            $employee->id
        )
            ->where('status', 'pending')
            ->whereDate('task_date', '<=', $reportDate)
            ->orderBy('task_date')
            ->orderBy('created_at')
            ->get();

        return view(
            'employees.submit-report',
            compact(
                'employee',
                'reportDate',
                'pendingTasks'
            )
        );
    }
}