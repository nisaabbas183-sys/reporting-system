<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TaskController extends Controller
{
    /**
     * Display all tasks with filters.
     */
    public function index(Request $request)
    {
        $query = Task::with('employee.department');

        // Employee filter
        if ($request->filled('employee_id')) {
            $query->where(
                'employee_id',
                $request->employee_id
            );
        }

        // Status filter
        if ($request->filled('status')) {
            $query->where(
                'status',
                $request->status
            );
        }

        $tasks = $query
            ->orderBy('task_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $employees = Employee::where('status', 1)
            ->orderBy('name')
            ->get();

        return view(
            'tasks.index',
            compact(
                'tasks',
                'employees'
            )
        )
            ->with(
                'pageTitle',
                'Tasks'
            )
            ->with(
                'pageSubtitle',
                'Manage and track employee tasks.'
            );
    }


    /**
     * Show form for creating a new task.
     */
    public function create(Request $request)
    {
        $employees = Employee::where('status', 1)
            ->orderBy('name')
            ->get();

        $selectedEmployees = collect();

        if ($request->filled('employee_ids')) {
            $selectedEmployees = Employee::whereIn(
                'id',
                $request->input('employee_ids')
            )
                ->orderBy('name')
                ->get();
        }

        return view(
            'tasks.create',
            compact(
                'employees',
                'selectedEmployees'
            )
        )
            ->with(
                'pageTitle',
                'Create Task'
            )
            ->with(
                'pageSubtitle',
                'Assign a new task to an employee.'
            );
    }


    /**
     * Store a new task (individual or group).
     */
    public function store(Request $request)
    {
        $validated = $request->validate([

            'employee_ids' =>
                'required|array|min:1',

            'employee_ids.*' =>
                'exists:employees,id',

            'task' =>
                'required|string',

            'task_date' =>
                'required|date',

            'due_date' =>
                'nullable|date',
        ]);

        $isGroup = count($validated['employee_ids']) > 1;
        $batchId = $isGroup ? (string) Str::uuid() : null;

        DB::transaction(function () use ($validated, $batchId) {

            foreach ($validated['employee_ids'] as $employeeId) {

                Task::create([

                    'employee_id' =>
                        $employeeId,

                    'batch_id' =>
                        $batchId,

                    'task' =>
                        $validated['task'],

                    'task_date' =>
                        $validated['task_date'],

                    'due_date' =>
                        $validated['due_date'] ?? null,

                    'status' =>
                        'pending',

                    'completed_at' =>
                        null,
                ]);
            }
        });

        return redirect()
            ->route('tasks.index')
            ->with(
                'success',
                $isGroup
                    ? 'Task assigned to ' . count($validated['employee_ids']) . ' employees successfully.'
                    : 'Task assigned successfully.'
            );
    }


    /**
     * Display a specific task.
     */
    public function show(Task $task)
    {
        $task->load('employee.department');

        return view(
            'tasks.show',
            compact('task')
        )
            ->with(
                'pageTitle',
                'Task Details'
            )
            ->with(
                'pageSubtitle',
                'View task information.'
            );
    }


    /**
     * Show form for editing a task.
     */
    public function edit(Task $task)
    {
        $employees = Employee::where('status', 1)
            ->orderBy('name')
            ->get();

        return view(
            'tasks.edit',
            compact(
                'task',
                'employees'
            )
        )
            ->with(
                'pageTitle',
                'Edit Task'
            )
            ->with(
                'pageSubtitle',
                'Update task information.'
            );
    }


    /**
     * Update a task.
     */
    public function update(Request $request, Task $task)
    {
        $validated = $request->validate([

            'employee_id' =>
                'required|exists:employees,id',

            'task' =>
                'required|string',

            'task_date' =>
                'required|date',

            'due_date' =>
                'nullable|date',
        ]);

        $task->update([

            'employee_id' =>
                $validated['employee_id'],

            'task' =>
                $validated['task'],

            'task_date' =>
                $validated['task_date'],

            'due_date' =>
                $validated['due_date'] ?? null,
        ]);

        return redirect()
            ->route('tasks.index')
            ->with(
                'success',
                'Task updated successfully.'
            );
    }


    /**
     * Delete a task.
     */
    public function destroy(Task $task)
    {
        $task->delete();

        return redirect()
            ->route('tasks.index')
            ->with(
                'success',
                'Task deleted successfully.'
            );
    }


    /**
     * Approve a submitted task.
     */
    public function approve(Task $task)
    {
        if ($task->status !== 'submitted') {
            return redirect()
                ->back()
                ->with(
                    'error',
                    'Only submitted tasks can be approved.'
                );
        }

        $task->update([
            'status' => 'approved',
            'completed_at' => now(),
        ]);

        return redirect()
            ->back()
            ->with(
                'success',
                'Task approved successfully.'
            );
    }
}