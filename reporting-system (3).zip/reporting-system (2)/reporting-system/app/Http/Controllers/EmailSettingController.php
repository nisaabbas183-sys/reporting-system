<?php

namespace App\Http\Controllers;

use App\Models\EmailSetting;
use App\Services\DailyReportEmailService;
use Illuminate\Http\Request;

class EmailSettingController extends Controller
{
    public function edit()
    {
        return view('email_settings.edit', [
            'setting' => EmailSetting::current(),
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'smtp_host'       => 'required|string|max:255',
            'smtp_port'       => 'required|integer|min:1|max:65535',
            'smtp_username'   => 'required|string|max:255',
            'smtp_password'   => 'nullable|string|max:255',
            'smtp_encryption' => 'required|in:tls,ssl',
            'from_email'      => 'required|email|max:255',
            'from_name'       => 'required|string|max:255',
            'recipients'      => 'required|string',
            'send_time'       => ['required', 'regex:/^([01]\d|2[0-3]):[0-5]\d$/'],
        ]);

        $setting = EmailSetting::current();

        // Blank password = keep the old one
        if (empty($data['smtp_password'])) {
            unset($data['smtp_password']);
        }

        $data['is_enabled'] = $request->boolean('is_enabled');

        // Time changed -> allow sending again today
        if ($setting->send_time !== $data['send_time']) {
            $data['last_sent_date'] = null;
        }

        $setting->update($data);

        return redirect()
            ->route('email-settings.edit')
            ->with('success', 'Email settings saved successfully.');
    }

    public function test(DailyReportEmailService $service)
    {
        try {
            $service->send(EmailSetting::current());

            return back()->with('success', 'Test email sent. Please check the inbox.');
        } catch (\Throwable $e) {
            return back()->with('error', 'Failed: ' . $e->getMessage());
        }
    }
}