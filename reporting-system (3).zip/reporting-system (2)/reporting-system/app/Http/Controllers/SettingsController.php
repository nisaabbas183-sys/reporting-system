<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        $settings = Setting::pluck('value', 'key');

        return view('settings.index', compact('settings'))
            ->with('pageTitle', 'Settings')
            ->with(
                'pageSubtitle',
                'Manage reporting system settings.'
            );
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'report_time' => 'required|date_format:H:i',
        ]);

        $settings = [
            'report_time' => $validated['report_time'],
            'automatic_report_sending' =>
                $request->has('automatic_report_sending') ? '1' : '0',
            'pdf_report_generation' =>
                $request->has('pdf_report_generation') ? '1' : '0',
            'email_notifications' =>
                $request->has('email_notifications') ? '1' : '0',
            'whatsapp_notifications' =>
                $request->has('whatsapp_notifications') ? '1' : '0',
        ];

        foreach ($settings as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }

        return redirect()
            ->route('settings.index')
            ->with('success', 'Settings saved successfully.');
    }
}