<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class EmployeeProfileController extends Controller
{
    /**
     * Show the logged-in employee's profile.
     */
    public function index(Request $request)
    {
        $employeeId = $request->session()->get(
            'employee_id'
        );

        $employee = Employee::with('department')
            ->findOrFail($employeeId);


        return view(
            'employees.profile.index',
            compact('employee')
        );
    }


    /**
     * Update the logged-in employee's profile photo.
     */
    public function updatePhoto(Request $request)
    {
        $employeeId = $request->session()->get(
            'employee_id'
        );

        $employee = Employee::findOrFail(
            $employeeId
        );


        /*
        |--------------------------------------------------------------------------
        | Validate Uploaded Photo
        |--------------------------------------------------------------------------
        */

        $request->validate([

            'photo' =>
                'required|image|mimes:jpeg,jpg,png,webp|max:2048',
        ]);


        /*
        |--------------------------------------------------------------------------
        | Delete Old Photo (if exists)
        |--------------------------------------------------------------------------
        */

        if ($employee->photo) {

            Storage::disk('public')->delete(
                $employee->photo
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Store New Photo
        |--------------------------------------------------------------------------
        */

        $path = $request->file('photo')->store(
            'employee_photos',
            'public'
        );

        $employee->update([

            'photo' =>
                $path,
        ]);


        return redirect()
            ->route(
                'employee.profile.index'
            )
            ->with(
                'success',
                'Profile photo updated successfully.'
            );
    }


    /**
     * Update the logged-in employee's password.
     */
    public function updatePassword(Request $request)
    {
        $employeeId = $request->session()->get(
            'employee_id'
        );

        $employee = Employee::findOrFail(
            $employeeId
        );


        /*
        |--------------------------------------------------------------------------
        | Validate Input
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([

            'current_password' =>
                'required|string',

            'new_password' =>
                'required|string|min:6|confirmed',
        ]);


        /*
        |--------------------------------------------------------------------------
        | Check Current Password
        |--------------------------------------------------------------------------
        */

        if (!Hash::check(
            $validated['current_password'],
            $employee->password
        )) {

            return back()
                ->withErrors([
                    'current_password' =>
                        'The current password is incorrect.',
                ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Update Password
        |--------------------------------------------------------------------------
        */

        $employee->update([

            'password' =>
                Hash::make(
                    $validated['new_password']
                ),
        ]);


        return redirect()
            ->route(
                'employee.profile.index'
            )
            ->with(
                'success',
                'Password updated successfully.'
            );
    }
}