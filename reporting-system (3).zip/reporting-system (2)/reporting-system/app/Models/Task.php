<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    protected $fillable = [
        'employee_id',
        'task',
        'task_date',
        'due_date',
        'status',
        'completed_at',
        'carried_from_task_id',
    ];

    protected $casts = [
        'task_date' => 'date',
        'due_date' => 'date',
        'completed_at' => 'datetime',
    ];

    /**
     * Task belongs to an employee.
     */
    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    /**
     * This task was carried forward from another task.
     */
    public function carriedFrom(): BelongsTo
    {
        return $this->belongsTo(Task::class, 'carried_from_task_id');
    }

    /**
     * Tasks carried forward from this task.
     */
    public function carriedTasks()
    {
        return $this->hasMany(Task::class, 'carried_from_task_id');
    }
}