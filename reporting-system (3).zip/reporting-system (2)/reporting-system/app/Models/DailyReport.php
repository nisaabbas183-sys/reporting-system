<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DailyReport extends Model
{
    protected $fillable = [
        'employee_id',
        'report_date',
        'report_content',
        'accounts_finance',
        'inquiries_proposals',
        'orders',
        'follow_ups',
        'shipment',
        'projects',
        'report_sent_at',
        'visit',
        'hr_staff',
        'misc',
        'tomorrow_tasks',
    ];

    protected $casts = [
        'report_date' => 'date',
        'report_sent_at' => 'datetime',
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }
}