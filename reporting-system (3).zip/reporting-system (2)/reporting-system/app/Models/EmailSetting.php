<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailSetting extends Model
{
    protected $fillable = [
        'is_enabled', 'smtp_host', 'smtp_port', 'smtp_username',
        'smtp_password', 'smtp_encryption', 'from_email', 'from_name',
        'recipients', 'send_time', 'last_sent_date',
    ];

    protected $casts = [
        'is_enabled'     => 'boolean',
        'smtp_password'  => 'encrypted',
        'last_sent_date' => 'date',
    ];

    public static function current(): self
    {
        return static::first() ?? static::create([]);
    }

    public function recipientList(): array
    {
        return collect(explode(',', (string) $this->recipients))
            ->map(fn ($e) => trim($e))
            ->filter(fn ($e) => filter_var($e, FILTER_VALIDATE_EMAIL))
            ->values()
            ->all();
    }
}