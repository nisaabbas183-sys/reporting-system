<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\DailyReport;
use App\Models\Task;

class Employee extends Model
{
    protected $fillable = [
        'name',
        'department_id',
        'report_section_head',
        'email',
        'cell_number',
        'photo',
        'password',
        'status',
    ];

    protected $hidden = [
        'password',
    ];

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);

    }
    public function dailyReports()
{
    return $this->hasMany(DailyReport::class);
}
public function tasks()
{
    return $this->hasMany(Task::class);
}

}