<?php

namespace App\Console\Commands;

use App\Models\EmailSetting;
use App\Services\DailyReportEmailService;
use Illuminate\Console\Command;

class SendDailyReportEmail extends Command
{
    protected $signature = 'reports:send-daily {--force}';
    protected $description = 'Email the consolidated daily report PDF at the admin-selected time';

    public function handle(DailyReportEmailService $service): int
    {
        $s = EmailSetting::current();

        if (!$this->option('force')) {
            if (!$s->is_enabled) {
                return self::SUCCESS;
            }

            $alreadySent = $s->last_sent_date
                && $s->last_sent_date->isToday();

            // send once per day, at or after the chosen time
            if ($alreadySent || now()->format('H:i') < $s->send_time) {
                return self::SUCCESS;
            }
        }

        try {
            $service->send($s);
            $s->update(['last_sent_date' => now()->toDateString()]);
            $this->info('Daily report email sent.');
        } catch (\Throwable $e) {
            report($e);
            $this->error('Failed: ' . $e->getMessage());
            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}