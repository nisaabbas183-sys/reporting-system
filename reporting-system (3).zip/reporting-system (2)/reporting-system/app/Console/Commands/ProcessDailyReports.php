<?php

namespace App\Console\Commands;

use App\Mail\DailyReportMail;
use App\Models\DailyReport;
use App\Models\Setting;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;

class ProcessDailyReports extends Command
{
    protected $signature = 'app:process-daily-reports
                            {--force : Send reports now without checking the scheduled time}
                            {--date= : Process reports for a specific date (YYYY-MM-DD)}';

    protected $description = 'Process and send daily employee reports automatically';

    public function handle()
    {
        // Check automatic sending setting
        $automaticSending = Setting::where(
            'key',
            'automatic_report_sending'
        )->value('value');

        if ($automaticSending !== '1') {
            $this->info('Automatic report sending is disabled.');

            return self::SUCCESS;
        }

        // Check email notification setting
        $emailNotifications = Setting::where(
            'key',
            'email_notifications'
        )->value('value');

        if ($emailNotifications !== '1') {
            $this->info('Email notifications are disabled.');

            return self::SUCCESS;
        }

        // Check PDF generation setting
        $pdfGeneration = Setting::where(
            'key',
            'pdf_report_generation'
        )->value('value');

        $generatePdf = $pdfGeneration === '1';

        // Get configured report time
        $reportTime = Setting::where(
            'key',
            'report_time'
        )->value('value');

        if (!$reportTime) {
            $this->error('Report time is not configured.');

            return self::FAILURE;
        }

        // Check scheduled time unless --force is used
        $currentTime = Carbon::now()->format('H:i');

        if (!$this->option('force') && $currentTime !== $reportTime) {
            $this->info(
                "Not report time yet. Current: {$currentTime}, Scheduled: {$reportTime}"
            );

            return self::SUCCESS;
        }

        // Determine report date
        if ($this->option('date')) {
            try {
                $reportDate = Carbon::createFromFormat(
                    'Y-m-d',
                    $this->option('date')
                )->format('Y-m-d');
            } catch (\Throwable $e) {
                $this->error(
                    'Invalid date format. Please use YYYY-MM-DD.'
                );

                return self::FAILURE;
            }
        } else {
            $reportDate = today()->toDateString();
        }

        if ($this->option('force')) {
            $this->info('FORCE mode enabled. Sending reports now...');
        } else {
            $this->info("Report time reached: {$reportTime}");
        }

        $this->info("Processing reports for date: {$reportDate}");

        // Only get reports which have NOT been sent yet
        $reports = DailyReport::with([
            'employee.department',
        ])
            ->whereDate('report_date', $reportDate)
            ->whereNull('report_sent_at')
            ->get();

        if ($reports->isEmpty()) {
            $this->info(
                "No unsent daily reports found for {$reportDate}."
            );

            return self::SUCCESS;
        }

        $this->info(
            $reports->count() . ' unsent daily report(s) found.'
        );

        foreach ($reports as $report) {
            $employee = $report->employee;

            if (!$employee) {
                $this->warn(
                    "Report #{$report->id} has no employee."
                );

                continue;
            }

            if (!$employee->email) {
                $this->warn(
                    "No email found for {$employee->name}."
                );

                continue;
            }

            try {
                // Send email
                Mail::to($employee->email)
                    ->send(
                        new DailyReportMail(
                            $report,
                            $generatePdf
                        )
                    );

                // Mark as sent ONLY after successful email
                $report->update([
                    'report_sent_at' => now(),
                ]);

                $this->info(
                    "Report #{$report->id} sent successfully to {$employee->email}"
                );

            } catch (\Throwable $e) {
                $this->error(
                    "Failed to send report #{$report->id} to {$employee->email}: "
                    . $e->getMessage()
                );
            }
        }

        $this->info('Daily report processing completed.');

        return self::SUCCESS;
    }
}