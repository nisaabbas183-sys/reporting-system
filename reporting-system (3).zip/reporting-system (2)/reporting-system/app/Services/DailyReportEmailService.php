<?php

namespace App\Services;

use App\Mail\ConsolidatedReportMail;
use App\Models\DailyReport;
use App\Models\Employee;
use App\Models\EmailSetting;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class DailyReportEmailService
{
    protected function departmentFieldMap(): array
    {
        return [
            'Finance'     => [['key' => 'accounts_finance', 'label' => 'Accounts & Finance']],
            'Sales'       => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'Purchase'    => [
                ['key' => 'inquiries_proposals', 'label' => 'Inquiry & Proposals'],
                ['key' => 'orders', 'label' => 'Orders'],
                ['key' => 'follow_ups', 'label' => 'Follow-ups'],
                ['key' => 'shipment', 'label' => 'Shipments'],
            ],
            'Project-SLW' => [
                ['key' => 'projects', 'label' => 'Projects'],
                ['key' => 'visit', 'label' => 'Visits'],
            ],
            'HR'          => [['key' => 'hr_staff', 'label' => 'HR / Staff']],
        ];
    }

       public function buildPdf(string $date): string
    {
        $map   = $this->departmentFieldMap();
        $names = array_keys($map);

        $employeesByDept = Employee::with('department')
            ->where('status', 1)
            ->whereHas('department', fn ($q) => $q->whereIn('name', $names))
            ->orderBy('name')
            ->get()
            ->groupBy(fn ($e) => $e->department->name ?? '');

        $reports = DailyReport::whereDate('report_date', $date)
            ->get()
            ->keyBy('employee_id');

        $allEmployeeIds = $employeesByDept->flatten()->pluck('id');

        $tasksByEmployee = \App\Models\Task::whereIn('employee_id', $allEmployeeIds)
            ->whereDate('task_date', '<=', $date)
            ->orderBy('task_date')
            ->get()
            ->groupBy('employee_id');

        $boxes = [];

        foreach ($map as $dept => $fields) {

            $employeesInDept = $employeesByDept->get($dept, collect());

            $boxes[$dept] = [
                'fields'    => $fields,
                'employees' => $employeesInDept->map(function ($e) use ($reports, $tasksByEmployee) {

                    $tasks = $tasksByEmployee->get($e->id, collect());

                    return [
                        'employee'  => $e,
                        'report'    => $reports->get($e->id),
                        'pending'   => $tasks->where('status', 'pending')->values(),
                        'submitted' => $tasks->where('status', 'submitted')->values(),
                        'completed' => $tasks->whereIn('status', ['completed', 'approved'])->values(),
                    ];
                })->values(),
            ];
        }

        return Pdf::loadView('daily_reports.consolidated_pdf', [
            'reportDate'      => Carbon::parse($date),
            'departmentBoxes' => $boxes,
        ])->setPaper('a4', 'portrait')->output();
    }

    public function send(EmailSetting $s, ?string $date = null): void
    {
        $date       = $date ?? now()->toDateString();
        $recipients = $s->recipientList();

        if (empty($recipients)) {
            throw new \RuntimeException('No valid recipient email set.');
        }

        $mailer = Mail::build([
            'transport'  => 'smtp',
            'host'       => $s->smtp_host,
            'port'       => $s->smtp_port,
            'username'   => $s->smtp_username,
            'password'   => $s->smtp_password,
            'scheme'     => $s->smtp_encryption === 'ssl' ? 'smtps' : 'smtp',
            'timeout'    => 30,
        ]);

        $mail = new ConsolidatedReportMail(
            Carbon::parse($date),
            $this->buildPdf($date),
            $s->from_email ?: $s->smtp_username,
            $s->from_name ?: 'Star Automation'
        );

        $mailer->to($recipients)->send($mail);
    }
}