<?php

namespace App\Mail;

use App\Models\DailyReport;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class DailyReportMail extends Mailable
{
    use Queueable, SerializesModels;

    public DailyReport $dailyReport;

    public bool $generatePdf;

    public function __construct(
        DailyReport $dailyReport,
        bool $generatePdf = true
    ) {
        $this->dailyReport = $dailyReport;

        $this->generatePdf = $generatePdf;

        $this->dailyReport->load('employee.department');
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Daily Employee Report - '
                . $this->dailyReport->employee->name,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.daily-report',
        );
    }

    public function attachments(): array
    {
        if (!$this->generatePdf) {
            return [];
        }

        $pdf = Pdf::loadView(
            'daily_reports.pdf',
            [
                'dailyReport' => $this->dailyReport,
            ]
        )->output();

        return [
            Attachment::fromData(
                fn () => $pdf,
                'Daily-Report-'
                . $this->dailyReport->employee->name
                . '-'
                . $this->dailyReport->report_date->format('d-m-Y')
                . '.pdf'
            )->withMime('application/pdf'),
        ];
    }
}