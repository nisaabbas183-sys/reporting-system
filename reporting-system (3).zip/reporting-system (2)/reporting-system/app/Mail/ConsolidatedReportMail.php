<?php

namespace App\Mail;

use Carbon\Carbon;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

class ConsolidatedReportMail extends Mailable
{
    public function __construct(
        public Carbon $reportDate,
        public string $pdfData,
        public string $fromEmail,
        public string $fromName,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from: new Address($this->fromEmail, $this->fromName),
            subject: 'Daily Report - ' . $this->reportDate->format('d/m/Y'),
        );
    }

    public function content(): Content
    {
        return new Content(view: 'emails.consolidated-report');
    }

    public function attachments(): array
    {
        return [
            Attachment::fromData(
                fn () => $this->pdfData,
                'Daily-Report-' . $this->reportDate->format('d-m-Y') . '.pdf'
            )->withMime('application/pdf'),
        ];
    }
}